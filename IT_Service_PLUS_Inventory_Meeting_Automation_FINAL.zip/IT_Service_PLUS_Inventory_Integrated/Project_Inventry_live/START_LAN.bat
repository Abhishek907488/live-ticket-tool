@echo off
title Inventory Management System - LAN Server
echo Installing/checking dependencies...
py -m pip install -r requirements.txt
echo.
echo Starting Inventory Server...
echo Keep this window open while users access the system.
echo Server PC: http://127.0.0.1:5001
echo Other PCs: http://YOUR-SERVER-IP:5001
echo.
set INVENTORY_PORT=5001
py app.py
pause
