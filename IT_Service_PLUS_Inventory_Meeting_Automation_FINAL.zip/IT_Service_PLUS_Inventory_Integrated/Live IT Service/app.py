from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory, abort
import sqlite3, os, uuid, smtplib, threading, glob, shutil, csv, io, time, json, urllib.request, urllib.parse, urllib.error
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, date, timedelta
import calendar
from email.message import EmailMessage
import logging
import hashlib
import base64

try:
    from cryptography.fernet import Fernet, InvalidToken
except ImportError:
    Fernet = None
    InvalidToken = Exception

app = Flask(__name__)
# Inventory Panel runs separately so it does not conflict with the IT Service Desk port.
app.config['INVENTORY_PANEL_URL'] = os.environ.get('INVENTORY_PANEL_URL', 'http://127.0.0.1:5001/dashboard')
app.secret_key = os.getenv("APP_SECRET_KEY", "change-this-secret-key")

logging.basicConfig(filename="ticketing_errors.log", level=logging.ERROR, format="%(asctime)s | %(levelname)s | %(message)s")
DB = "ticketing.db"
BACKUP_FOLDER = os.getenv("BACKUP_FOLDER", "backups")
BACKUP_RETENTION_DAYS = int(os.getenv("BACKUP_RETENTION_DAYS", "30"))
_backup_lock = threading.Lock()
os.makedirs(BACKUP_FOLDER, exist_ok=True)
UPLOAD_FOLDER = os.path.join("static", "uploads")
ALLOWED_EXTENSIONS = {"png","jpg","jpeg","gif","pdf","txt","doc","docx","xls","xlsx","zip"}
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAIL_SIGNATURE_FOLDER"] = os.path.join(app.config["UPLOAD_FOLDER"], "mail_signature")
os.makedirs(app.config["MAIL_SIGNATURE_FOLDER"], exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Automatic logout after inactivity. Default: 30 minutes.
SESSION_TIMEOUT_MINUTES = int(os.getenv("SESSION_TIMEOUT_MINUTES", "5"))
app.permanent_session_lifetime = timedelta(minutes=SESSION_TIMEOUT_MINUTES)

# Phase 1 SLA targets (calendar hours). These can be changed later without changing ticket data.
SLA_HOURS = {"Critical": 4, "High": 8, "Medium": 48, "Low": 72}

# Phase 3 Login Security
MAX_LOGIN_ATTEMPTS = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))
LOGIN_LOCK_MINUTES = int(os.getenv("LOGIN_LOCK_MINUTES", "15"))

# Performance: run background maintenance at most once per minute so normal page
# requests (especially ticket creation) do not wait for SLA checks.
_sla_bg_lock = threading.Lock()
_last_sla_queue = 0.0

def _background_sla_check():
    try:
        with app.app_context():
            run_sla_escalation()
    except Exception:
        logging.exception("Background SLA escalation check failed")

def queue_sla_check():
    global _last_sla_queue
    now_mono = time.monotonic()
    if now_mono - _last_sla_queue < 60:
        return
    with _sla_bg_lock:
        now_mono = time.monotonic()
        if now_mono - _last_sla_queue < 60:
            return
        _last_sla_queue = now_mono
    threading.Thread(target=_background_sla_check, daemon=True, name="sla-check").start()

def _background_ticket_created_email(ticket_id):
    try:
        with app.app_context():
            ok, err = notify_ticket_created(ticket_id)
            if not ok:
                logging.error("Background ticket email failed for ticket %s: %s", ticket_id, err)
    except Exception:
        logging.exception("Background ticket-created email failed for ticket %s", ticket_id)



def create_database_backup(reason="automatic"):
    """Create a safe SQLite backup without interrupting the live application."""
    if not os.path.exists(DB):
        raise FileNotFoundError(f"Database file not found: {DB}")
    os.makedirs(BACKUP_FOLDER, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"ticketing_backup_{stamp}_{reason}.db"
    target = os.path.join(BACKUP_FOLDER, filename)
    with _backup_lock:
        source = sqlite3.connect(DB)
        destination = sqlite3.connect(target)
        try:
            source.backup(destination)
            destination.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            destination.commit()
        finally:
            destination.close()
            source.close()
    return target

def cleanup_old_backups():
    """Keep the configured number of recent days of backup files."""
    cutoff = datetime.now() - timedelta(days=max(1, BACKUP_RETENTION_DAYS))
    for path in glob.glob(os.path.join(BACKUP_FOLDER, "ticketing_backup_*.db")):
        try:
            if datetime.fromtimestamp(os.path.getmtime(path)) < cutoff:
                os.remove(path)
        except OSError:
            logging.exception("Could not remove old backup: %s", path)

def ensure_daily_backup():
    """Create one automatic backup per calendar day when the system is used."""
    if not os.path.exists(DB):
        return None
    today = date.today().strftime("%Y%m%d")
    pattern = os.path.join(BACKUP_FOLDER, f"ticketing_backup_{today}_*.db")
    if glob.glob(pattern):
        return None
    try:
        path = create_database_backup("automatic")
        cleanup_old_backups()
        logging.info("Automatic database backup created: %s", path)
        return path
    except Exception:
        logging.exception("Automatic database backup failed")
        return None

def calculate_due_at(priority, created_at=None):
    created_dt = datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S") if created_at else datetime.now()
    hours = SLA_HOURS.get(priority, SLA_HOURS["Medium"])
    return (created_dt + timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")

def sla_state(ticket):
    if ticket["status"] in ("Resolved", "Closed"):
        return "Completed"
    due = ticket["due_at"] if "due_at" in ticket.keys() else None
    if not due:
        return "No Due Date"
    try:
        due_dt = datetime.strptime(due, "%Y-%m-%d %H:%M:%S")
        return "SLA Breached" if datetime.now() > due_dt else "Within SLA"
    except ValueError:
        return "Invalid Due Date"

def run_sla_escalation():
    """Find open overdue tickets and notify active Main Admins once per ticket."""
    conn=get_db()
    overdue=conn.execute("""SELECT t.id,t.ticket_no,t.subject,t.priority,t.status,t.assigned_to,t.team,t.due_at,
        u.full_name AS requester FROM tickets t JOIN users u ON t.user_id=u.id
        WHERE t.status NOT IN ('Resolved','Closed') AND t.due_at IS NOT NULL
        AND datetime(t.due_at) < datetime('now','localtime') AND (t.escalation_notified_at IS NULL OR TRIM(t.escalation_notified_at)='')""").fetchall()
    admins=conn.execute("SELECT email FROM users WHERE active=1 AND role='admin' AND email IS NOT NULL AND TRIM(email)<>''").fetchall()
    admin_emails=[r['email'] for r in admins]
    for t in overdue:
        if admin_emails:
            team_name='ERP Team' if (t['team'] or 'IT').upper()=='ERP' else 'IT Team'
            body=f"""Dear Main Admin,\n\nSLA escalation alert: the following ticket has passed its SLA due time.\n\nTicket No: {t['ticket_no']}\nEmployee: {t['requester']}\nSupport Team: {team_name}\nPriority: {t['priority']}\nStatus: {t['status']}\nAssigned To: {t['assigned_to'] or 'Not Assigned'}\nSLA Due: {t['due_at']}\nSubject: {t['subject']}\n\nPlease review and take the necessary action.\n\nRegards,\nMedilux Laboratories Pvt. Ltd.\nIT Service Desk"""
            ok,_=send_email(admin_emails, f"SLA Breached - {t['ticket_no']}", body)
            if ok:
                conn.execute("UPDATE tickets SET escalation_notified_at=? WHERE id=?", (now(), t['id']))
                conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) SELECT ?,id,?,? FROM users WHERE role='admin' AND active=1 ORDER BY id LIMIT 1", (t['id'], 'SLA breached - Main Admin notified', now()))
        else:
            # Mark as escalated even when no admin email exists; avoids repeating work every request.
            conn.execute("UPDATE tickets SET escalation_notified_at=? WHERE id=?", (now(), t['id']))
    conn.commit(); conn.close()


@app.before_request
def auto_logout_inactive_user():
    # Do not apply timeout to login/setup or static files.
    if request.endpoint in {"login", "setup_admin", "static"} or "user_id" not in session:
        return
    last_activity = session.get("last_activity")
    now_dt = datetime.now()
    if last_activity:
        try:
            last_dt = datetime.fromisoformat(last_activity)
            if now_dt - last_dt > timedelta(minutes=SESSION_TIMEOUT_MINUTES):
                session.clear()
                flash("Your session expired due to inactivity. Please login again.", "error")
                return redirect(url_for("login"))
        except (TypeError, ValueError):
            session.clear()
            flash("Your session expired. Please login again.", "error")
            return redirect(url_for("login"))
    session["last_activity"] = now_dt.isoformat(timespec="seconds")
    session.permanent = True

@app.before_request
def phase3_daily_backup_check():
    if request.endpoint in {"static", "login", "setup_admin"}:
        return
    ensure_daily_backup()

@app.before_request
def phase1_sla_check():
    if request.endpoint in {"login", "setup_admin", "static"}:
        return
    # Do not block the page request on SLA DB checks/email notifications.
    queue_sla_check()

@app.errorhandler(403)
def error_403(e):
    return render_template("error.html", code=403, title="Access Denied", message="You are not authorized to perform this action."), 403

@app.errorhandler(404)
def error_404(e):
    return render_template("error.html", code=404, title="Page Not Found", message="The requested page or ticket was not found."), 404

@app.errorhandler(500)
def error_500(e):
    logging.exception("Unhandled server error")
    return render_template("error.html", code=500, title="Something Went Wrong", message="The system could not complete this request. Please try again or contact the IT Administrator."), 500

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def _mail_fernet():
    """Create a stable encryption key from the application's secret."""
    if Fernet is None:
        return None
    digest = hashlib.sha256(app.secret_key.encode("utf-8")).digest()
    return Fernet(base64.urlsafe_b64encode(digest))

def encrypt_mail_secret(value):
    if not value:
        return ""
    f = _mail_fernet()
    if f is None:
        raise RuntimeError("The cryptography package is required for secure mail password storage.")
    return f.encrypt(value.encode("utf-8")).decode("utf-8")

def decrypt_mail_secret(value):
    if not value:
        return ""
    f = _mail_fernet()
    if f is None:
        return ""
    try:
        return f.decrypt(value.encode("utf-8")).decode("utf-8")
    except (InvalidToken, ValueError, TypeError):
        logging.exception("Could not decrypt saved SMTP password")
        return ""

def get_mail_config():
    """Return saved SMTP configuration, falling back to environment variables for compatibility."""
    try:
        conn = get_db()
        row = conn.execute("SELECT * FROM mail_settings WHERE id=1").fetchone()
        conn.close()
    except Exception:
        row = None
    if row:
        return {
            "host": row["smtp_host"],
            "port": int(row["smtp_port"] or 587),
            "username": row["smtp_username"] or "",
            "password": decrypt_mail_secret(row["smtp_password"] or ""),
            "from_email": row["from_email"] or row["smtp_username"] or "",
            "from_name": row["from_name"] or "IT Service Desk",
            "security": row["security"] or "tls",
            "signature": row["signature"] or "",
            "signature_image": row["signature_image"] or "",
            "configured": bool(row["smtp_username"] and row["smtp_password"])
        }
    username = os.getenv("MAIL_USERNAME", "").strip()
    return {
        "host": os.getenv("MAIL_HOST", "smtp.gmail.com").strip(),
        "port": int(os.getenv("MAIL_PORT", "587")),
        "username": username,
        "password": os.getenv("MAIL_APP_PASSWORD", "").strip(),
        "from_email": os.getenv("MAIL_FROM", username).strip(),
        "from_name": "IT Service Desk",
        "security": "tls",
        "signature": "",
        "signature_image": "",
        "configured": bool(username and os.getenv("MAIL_APP_PASSWORD", "").strip())
    }


# ---------------- Meeting Center / Automatic Meeting Integrations ----------------
MEETING_TIMEZONE = os.environ.get("MEETING_TIMEZONE", "Asia/Kolkata")

def _meeting_fernet():
    if Fernet is None:
        return None
    digest = hashlib.sha256((app.secret_key + "|meeting-integrations").encode("utf-8")).digest()
    return Fernet(base64.urlsafe_b64encode(digest))

def encrypt_meeting_secret(value):
    if not value:
        return ""
    f=_meeting_fernet()
    return f.encrypt(value.encode("utf-8")).decode("utf-8") if f else value

def decrypt_meeting_secret(value):
    if not value:
        return ""
    f=_meeting_fernet()
    if not f:
        return value
    try:
        return f.decrypt(value.encode("utf-8")).decode("utf-8")
    except Exception:
        return value

def meeting_settings():
    c=get_db(); rows=c.execute("SELECT * FROM meeting_integrations ORDER BY provider").fetchall(); c.close()
    out={}
    for r in rows:
        d=dict(r)
        for k in ("client_secret","refresh_token"):
            d[k]=decrypt_meeting_secret(d.get(k) or "")
        out[d["provider"]]=d
    return out

def _http_json(url, method="GET", data=None, headers=None):
    payload=None
    hdr={"Accept":"application/json","User-Agent":"Medilux-IT-Service-Desk/MeetingCenter"}
    if headers: hdr.update(headers)
    if data is not None:
        payload=json.dumps(data).encode("utf-8")
        hdr.setdefault("Content-Type","application/json")
    req=urllib.request.Request(url, data=payload, headers=hdr, method=method)
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            raw=resp.read().decode("utf-8")
            return resp.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        raw=e.read().decode("utf-8", errors="replace")
        try: body=json.loads(raw)
        except Exception: body={"error":raw}
        raise RuntimeError(f"API {e.code}: {body.get('error_description') or body.get('message') or body.get('error') or raw[:300]}")
    except Exception as e:
        raise RuntimeError(str(e))

def _form_post(url, form, headers=None):
    hdr={"Accept":"application/json","User-Agent":"Medilux-IT-Service-Desk/MeetingCenter","Content-Type":"application/x-www-form-urlencoded"}
    if headers: hdr.update(headers)
    data=urllib.parse.urlencode(form).encode("utf-8")
    req=urllib.request.Request(url,data=data,headers=hdr,method="POST")
    try:
        with urllib.request.urlopen(req,timeout=25) as resp:
            raw=resp.read().decode("utf-8")
            return resp.status,(json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        raw=e.read().decode("utf-8",errors="replace")
        try: body=json.loads(raw)
        except Exception: body={"error":raw}
        raise RuntimeError(f"API {e.code}: {body.get('error_description') or body.get('message') or body.get('error') or raw[:300]}")

def _iso_local(date_s,time_s):
    return f"{date_s}T{time_s}:00+05:30"

def _zoom_link(settings, title, start_iso, end_iso, duration_minutes):
    import base64 as _b64
    basic=_b64.b64encode(f"{settings['client_id']}:{settings['client_secret']}".encode()).decode()
    _,tok=_form_post("https://zoom.us/oauth/token", {"grant_type":"account_credentials","account_id":settings["account_id"]}, {"Authorization":f"Basic {basic}"})
    access=tok.get("access_token")
    if not access: raise RuntimeError("Zoom did not return an access token.")
    start_utc=datetime.fromisoformat(start_iso).astimezone(__import__('datetime').timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    body={"topic":title,"type":2,"start_time":start_utc,"duration":duration_minutes,"timezone":MEETING_TIMEZONE,"settings":{"waiting_room":True,"join_before_host":False}}
    user=urllib.parse.quote(settings.get("organizer_email") or "me",safe="")
    _,data=_http_json(f"https://api.zoom.us/v2/users/{user}/meetings","POST",body,{"Authorization":f"Bearer {access}"})
    return data.get("join_url") or data.get("start_url"), data.get("id"), data

def _google_access_token(settings):
    _,tok=_form_post("https://oauth2.googleapis.com/token",{"client_id":settings["client_id"],"client_secret":settings["client_secret"],"refresh_token":settings["refresh_token"],"grant_type":"refresh_token"})
    if not tok.get("access_token"): raise RuntimeError("Google did not return an access token. Reconnect Google Meet/Calendar.")
    return tok["access_token"]

def _google_link(settings, title, start_iso, end_iso, emails):
    access=_google_access_token(settings)
    attendees=[{"email":e} for e in emails]
    body={"summary":title,"start":{"dateTime":start_iso,"timeZone":MEETING_TIMEZONE},"end":{"dateTime":end_iso,"timeZone":MEETING_TIMEZONE},"attendees":attendees,"conferenceData":{"createRequest":{"requestId":uuid.uuid4().hex,"conferenceSolutionKey":{"type":"hangoutsMeet"}}}}
    _,data=_http_json("https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1&sendUpdates=all","POST",body,{"Authorization":f"Bearer {access}"})
    link=data.get("hangoutLink")
    if not link:
        for ep in data.get("conferenceData",{}).get("entryPoints",[]):
            if ep.get("entryPointType")=="video": link=ep.get("uri"); break
    return link, data.get("id"), data

def _teams_token(settings):
    _,tok=_form_post(f"https://login.microsoftonline.com/{settings['tenant_id']}/oauth2/v2.0/token",{"client_id":settings["client_id"],"client_secret":settings["client_secret"],"scope":"https://graph.microsoft.com/.default","grant_type":"client_credentials"})
    if not tok.get("access_token"): raise RuntimeError("Microsoft did not return an access token. Check Entra app permissions/admin consent.")
    return tok["access_token"]

def _teams_link(settings, title, start_iso, end_iso, emails):
    access=_teams_token(settings)
    # Graph creates the online meeting; the existing SMTP layer sends the participant invitation emails.
    # This avoids requiring every invitee to be a Microsoft Graph user in the tenant.
    body={"startDateTime":start_iso,"endDateTime":end_iso,"subject":title}
    organizer=settings.get("organizer_email") or ""
    if not organizer: raise RuntimeError("Microsoft Teams organizer email is required.")
    user=urllib.parse.quote(organizer,safe="")
    _,data=_http_json(f"https://graph.microsoft.com/v1.0/users/{user}/onlineMeetings","POST",body,{"Authorization":f"Bearer {access}"})
    return data.get("joinWebUrl"), data.get("id"), data

def create_provider_meeting(provider, settings, title, start_iso, end_iso, emails):
    duration=max(1,int((datetime.fromisoformat(end_iso)-datetime.fromisoformat(start_iso)).total_seconds()/60))
    if provider=="zoom": return _zoom_link(settings,title,start_iso,end_iso,duration)
    if provider=="google": return _google_link(settings,title,start_iso,end_iso,emails)
    if provider=="teams": return _teams_link(settings,title,start_iso,end_iso,emails)
    raise RuntimeError("Unsupported meeting platform.")

def meeting_invitation_body(m, ticket):
    return f"""Dear Participant,\n\nYou are invited to the following IT Service Desk meeting.\n\nTicket: {ticket['ticket_no']}\nSubject: {ticket['subject']}\nPlatform: {m['provider'].title()}\nMeeting: {m['title']}\nDate: {m['start_at'][:10]}\nTime: {m['start_at'][11:16]} - {m['end_at'][11:16]}\nJoin Meeting: {m['join_url']}\n\nRegards,\nIT Service Desk"""

def init_db():
    conn=get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL, department TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'employee', password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_no TEXT UNIQUE,
      user_id INTEGER NOT NULL, subject TEXT NOT NULL, category TEXT NOT NULL,
      subcategory TEXT, priority TEXT NOT NULL DEFAULT 'Medium', description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'New', assigned_to TEXT, location TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL, due_at TEXT, escalation_notified_at TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
      comment TEXT NOT NULL, created_at TEXT NOT NULL,
      FOREIGN KEY(ticket_id) REFERENCES tickets(id), FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS attachments (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
      original_name TEXT NOT NULL, stored_name TEXT NOT NULL, created_at TEXT NOT NULL,
      FOREIGN KEY(ticket_id) REFERENCES tickets(id), FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS ticket_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
      action TEXT NOT NULL, created_at TEXT NOT NULL,
      FOREIGN KEY(ticket_id) REFERENCES tickets(id), FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL,
      entity_type TEXT, entity_id INTEGER, details TEXT, ip_address TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS ticket_feedback (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
      rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5), feedback TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(ticket_id) REFERENCES tickets(id), FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS daily_reports (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, report_date TEXT NOT NULL,
      work_summary TEXT NOT NULL DEFAULT '', tickets_worked TEXT DEFAULT '', pending_work TEXT DEFAULT '',
      issues TEXT DEFAULT '', next_day_plan TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      UNIQUE(user_id, report_date), FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS maintenance_notices (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
      start_at TEXT NOT NULL, end_at TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
      created_by INTEGER, created_at TEXT NOT NULL, FOREIGN KEY(created_by) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS it_announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, message TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Normal', active INTEGER NOT NULL DEFAULT 1,
      created_by INTEGER, created_at TEXT NOT NULL, FOREIGN KEY(created_by) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS login_security (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      failed_attempts INTEGER NOT NULL DEFAULT 0, locked_until TEXT, last_failed_at TEXT);
    CREATE TABLE IF NOT EXISTS departments (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, head_user_id INTEGER,
      created_at TEXT NOT NULL,
      FOREIGN KEY(head_user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS mail_settings (
      id INTEGER PRIMARY KEY CHECK(id=1), smtp_host TEXT NOT NULL DEFAULT 'smtp.gmail.com',
      smtp_port INTEGER NOT NULL DEFAULT 587, smtp_username TEXT, smtp_password TEXT,
      from_email TEXT, from_name TEXT DEFAULT 'IT Service Desk', security TEXT NOT NULL DEFAULT 'tls',
      signature TEXT DEFAULT '', signature_image TEXT DEFAULT '', updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS meeting_integrations (
      provider TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 0, client_id TEXT DEFAULT '', client_secret TEXT DEFAULT '',
      account_id TEXT DEFAULT '', tenant_id TEXT DEFAULT '', organizer_email TEXT DEFAULT '', refresh_token TEXT DEFAULT '', updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS saved_meeting_links (
      id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL, name TEXT NOT NULL, meeting_link TEXT NOT NULL,
      meeting_id TEXT DEFAULT '', passcode TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_by INTEGER, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS meeting_contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS meeting_groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS meeting_group_members (
      group_id INTEGER NOT NULL, contact_id INTEGER NOT NULL, PRIMARY KEY(group_id,contact_id),
      FOREIGN KEY(group_id) REFERENCES meeting_groups(id) ON DELETE CASCADE, FOREIGN KEY(contact_id) REFERENCES meeting_contacts(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS meetings (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, provider TEXT NOT NULL, title TEXT NOT NULL,
      start_at TEXT NOT NULL, end_at TEXT NOT NULL, join_url TEXT NOT NULL, provider_meeting_id TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Scheduled', created_by INTEGER, created_at TEXT NOT NULL, invitation_sent_at TEXT,
      saved_link_id INTEGER, participants TEXT DEFAULT '', FOREIGN KEY(ticket_id) REFERENCES tickets(id));
    """)
    # Live system: do not create demo accounts.
    # Add an active flag for existing databases created by earlier versions.
    cols = [r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if "active" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
    if "email" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN email TEXT")
    if "removed_at" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN removed_at TEXT")
    if "designation" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN designation TEXT")
    if "is_department_head" not in cols:
        conn.execute("ALTER TABLE users ADD COLUMN is_department_head INTEGER NOT NULL DEFAULT 0")
        conn.execute("INSERT OR IGNORE INTO departments(name,created_at) SELECT DISTINCT TRIM(department), ? FROM users WHERE department IS NOT NULL AND TRIM(department)<>''", (now(),))
    ticket_cols = [r[1] for r in conn.execute("PRAGMA table_info(tickets)").fetchall()]
    if "team" not in ticket_cols:
        conn.execute("ALTER TABLE tickets ADD COLUMN team TEXT NOT NULL DEFAULT 'IT'")
    if "due_at" not in ticket_cols:
        conn.execute("ALTER TABLE tickets ADD COLUMN due_at TEXT")
    if "escalation_notified_at" not in ticket_cols:
        conn.execute("ALTER TABLE tickets ADD COLUMN escalation_notified_at TEXT")
    if "resolved_by_user_id" not in ticket_cols:
        conn.execute("ALTER TABLE tickets ADD COLUMN resolved_by_user_id INTEGER")
    if "resolved_by_name" not in ticket_cols:
        conn.execute("ALTER TABLE tickets ADD COLUMN resolved_by_name TEXT")
    if "resolved_at" not in ticket_cols:
        conn.execute("ALTER TABLE tickets ADD COLUMN resolved_at TEXT")
    if "meeting_requested" not in ticket_cols:
        conn.execute("ALTER TABLE tickets ADD COLUMN meeting_requested INTEGER NOT NULL DEFAULT 0")
    if "meeting_platform_requested" not in ticket_cols:
        conn.execute("ALTER TABLE tickets ADD COLUMN meeting_platform_requested TEXT DEFAULT ''")
    mail_cols = [r[1] for r in conn.execute("PRAGMA table_info(mail_settings)").fetchall()]
    if "signature" not in mail_cols:
        conn.execute("ALTER TABLE mail_settings ADD COLUMN signature TEXT DEFAULT ''")
    if "signature_image" not in mail_cols:
        conn.execute("ALTER TABLE mail_settings ADD COLUMN signature_image TEXT DEFAULT ''")
    conn.execute("UPDATE tickets SET team='IT' WHERE team IS NULL OR TRIM(team)=''")
    for r in conn.execute("SELECT id,priority,created_at FROM tickets WHERE due_at IS NULL").fetchall():
        conn.execute("UPDATE tickets SET due_at=? WHERE id=?", (calculate_due_at(r['priority'], r['created_at']), r['id']))
    # Small SQLite indexes used by the dashboard, ticket queue and daily reports.
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tickets_status_created ON tickets(status, created_at DESC)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tickets_user_created ON tickets(user_id, created_at DESC)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tickets_team_status ON tickets(team, status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_daily_reports_user_date ON daily_reports(user_id, report_date DESC)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ticket_history_ticket ON ticket_history(ticket_id, id DESC)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_comments_ticket ON comments(ticket_id, id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_attachments_ticket ON attachments(ticket_id, id)")
    conn.commit(); conn.close()

def audit(action, entity_type=None, entity_id=None, details=None):
    try:
        conn=get_db()
        conn.execute("INSERT INTO audit_log(user_id,action,entity_type,entity_id,details,ip_address,created_at) VALUES(?,?,?,?,?,?,?)", (session.get("user_id"),action,entity_type,entity_id,details,request.remote_addr,now()))
        conn.commit(); conn.close()
    except Exception:
        logging.exception("Audit log failed")

def send_email(to_addresses, subject, body, attachments=None):
    cfg = get_mail_config()
    host = (cfg.get("host") or "").strip()
    port = int(cfg.get("port") or 587)
    username = (cfg.get("username") or "").strip()
    password = cfg.get("password") or ""
    from_email = (cfg.get("from_email") or username).strip()
    from_name = (cfg.get("from_name") or "IT Service Desk").strip()
    security = (cfg.get("security") or "tls").lower()
    if not host or not username or not password:
        return False, "SMTP mail is not configured. Open Admin > Mail Configuration and save the SMTP settings."
    recipients=[x.strip() for x in (to_addresses if isinstance(to_addresses,(list,tuple,set)) else str(to_addresses).split(",")) if x.strip()]
    if not recipients: return False, "No recipient email address."
    msg=EmailMessage(); msg["From"] = f"{from_name} <{from_email}>" if from_name else from_email; msg["To"]=", ".join(recipients); msg["Subject"]=subject; msg.set_content(body)
    signature_image = (cfg.get("signature_image") or "").strip()
    signature_path = os.path.join(app.config.get("MAIL_SIGNATURE_FOLDER", os.path.join(app.config["UPLOAD_FOLDER"], "mail_signature")), signature_image) if signature_image else ""
    if signature_path and os.path.exists(signature_path):
        try:
            import mimetypes
            with open(signature_path, "rb") as f: image_data=f.read()
            ctype,_=mimetypes.guess_type(signature_path)
            maintype,subtype=(ctype.split("/",1) if ctype and "/" in ctype else ("image","png"))
            signature_html = "<div style=\"margin-top:18px;padding-top:12px;border-top:1px solid #e5e7eb\"><img src=\"cid:mail-signature-image\" alt=\"Email Signature\" style=\"max-width:680px;height:auto;display:block\"></div>"
            html_body = "<div style=\"font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:#1f2937\">" + __import__('html').escape(body).replace("\n","<br>") + signature_html + "</div>"
            msg.add_alternative(html_body, subtype="html")
            msg.get_body("html").add_related(image_data, maintype=maintype, subtype=subtype, cid="<mail-signature-image>")
        except Exception:
            logging.exception("Could not embed mail signature image")
    for path, filename in attachments or []:
        try:
            with open(path,"rb") as f: data=f.read()
            import mimetypes; ctype,_=mimetypes.guess_type(filename); maintype,subtype=(ctype.split("/",1) if ctype and "/" in ctype else ("application","octet-stream"))
            msg.add_attachment(data,maintype=maintype,subtype=subtype,filename=filename)
        except Exception:
            logging.exception("Could not attach file %s", filename)
    try:
        if security == "ssl":
            with smtplib.SMTP_SSL(host, port, timeout=20) as smtp:
                smtp.ehlo(); smtp.login(username,password); smtp.send_message(msg)
        else:
            with smtplib.SMTP(host,port,timeout=20) as smtp:
                smtp.ehlo()
                if security == "tls":
                    smtp.starttls(); smtp.ehlo()
                smtp.login(username,password); smtp.send_message(msg)
        return True, ""
    except Exception as e:
        logging.exception("Email send failed to %s", recipients)
        return False, str(e)

def ticket_email_data(ticket_id):
    conn=get_db(); t=conn.execute("SELECT t.*,u.full_name as requester,u.email as requester_email,u.department as requester_department FROM tickets t JOIN users u ON t.user_id=u.id WHERE t.id=?",(ticket_id,)).fetchone()
    ats=conn.execute("SELECT * FROM attachments WHERE ticket_id=? ORDER BY id",(ticket_id,)).fetchall(); conn.close(); return t,ats

def active_team_emails(team):
    team=(team or "IT").strip().upper()
    if team=="ERP": roles=("erp_admin","erp_user"); dept="ERP"
    else: roles=("admin","it_user"); dept="IT"
    conn=get_db()
    rows=conn.execute("SELECT email FROM users WHERE active=1 AND role IN (?,?) AND LOWER(TRIM(department))=? AND email IS NOT NULL AND TRIM(email)<>''",(roles[0],roles[1],dept.lower())).fetchall()
    conn.close()
    return [r["email"] for r in rows]

def notify_ticket_created(ticket_id):
    t,ats=ticket_email_data(ticket_id)
    if not t: return True, ""
    team=(t["team"] or "IT").upper()
    recipients=active_team_emails(team)
    conn=get_db()
    mains=conn.execute("SELECT email FROM users WHERE active=1 AND role='admin' AND email IS NOT NULL AND TRIM(email)<>''").fetchall()
    conn.close()
    recipients=list(dict.fromkeys(recipients+[r["email"] for r in mains]))
    if not recipients: return True, ""
    team_name="ERP Team" if team=="ERP" else "IT Team"
    body=f"""Dear {team_name},

A new {team_name} support ticket has been created.

Ticket No: {t['ticket_no']}
Employee: {t['requester']}
Department: {t['requester_department']}
Support Team: {team_name}
Location: {t['location'] or '-'}
Subject: {t['subject']}
Category: {t['category']}
Priority: {t['priority']}

Description:
{t['description']}

Regards,
IT Service Desk"""
    files=[(os.path.join(app.config['UPLOAD_FOLDER'],a['stored_name']),a['original_name']) for a in ats]
    return send_email(recipients,f"New {team_name} Ticket - {t['ticket_no']}",body,files)

def notify_assignment(ticket_id,assigned_name):
    if not assigned_name: return True, ""
    t,ats=ticket_email_data(ticket_id)
    if not t: return True, ""
    team=(t["team"] or "IT").upper()
    if team=="ERP": roles=("erp_admin","erp_user"); dept="ERP"
    else: roles=("admin","it_user"); dept="IT"
    conn=get_db()
    u=conn.execute("SELECT email FROM users WHERE active=1 AND role IN (?,?) AND LOWER(TRIM(department))=? AND full_name=?",(roles[0],roles[1],dept.lower(),assigned_name)).fetchone()
    conn.close()
    if not u or not u["email"]: return True, ""
    team_name="ERP Team" if team=="ERP" else "IT Team"
    body=f"""Dear {assigned_name},

The following {team_name} ticket has been assigned to you.

Ticket No: {t['ticket_no']}
Employee: {t['requester']}
Support Team: {team_name}
Subject: {t['subject']}
Priority: {t['priority']}
Location: {t['location'] or '-'}

Description:
{t['description']}

Please check and take necessary action.

Regards,
IT Service Desk"""
    return send_email(u["email"],f"Ticket Assigned - {t['ticket_no']}",body)

def notify_resolved(ticket_id, resolved_by_name=None):
    t,ats=ticket_email_data(ticket_id)
    if not t: return False, "Ticket not found."
    if not t["requester_email"]: return False, "Employee email address is not configured."
    cfg=get_mail_config()
    resolver=(resolved_by_name or t["resolved_by_name"] or t["assigned_to"] or "IT Support Team").strip()
    signature=(cfg.get("signature") or "").strip()
    if signature:
        signature=signature.replace("{{resolved_by}}", resolver).replace("{{ticket_no}}", t["ticket_no"] or "")
    else:
        signature=f"Regards,\n{resolver}\nIT Service Desk"
    body=f"""Dear {t['requester']},

Your IT support ticket has been resolved.

Ticket No: {t['ticket_no']}
Subject: {t['subject']}
Resolved By: {resolver}
Resolved At: {t['resolved_at'] or now()}

If the issue is still not resolved, please reply to this email or reopen the ticket from the IT Service Desk.

{signature}"""
    files=[(os.path.join(app.config['UPLOAD_FOLDER'],a['stored_name']),a['original_name']) for a in ats if os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'],a['stored_name']))]
    return send_email(t["requester_email"],f"Ticket Resolved - {t['ticket_no']}",body,files)

def notify_comment(ticket_id,commenter_role):
    t,ats=ticket_email_data(ticket_id)
    if not t: return True, ""
    recipient=None; name=None
    if commenter_role in ("admin","erp_admin"):
        recipient=t["requester_email"]; name=t["requester"]
    else:
        team=(t["team"] or "IT").upper()
        if team=="ERP": roles=("erp_admin","erp_user"); dept="ERP"
        else: roles=("admin","it_user"); dept="IT"
        conn=get_db()
        u=conn.execute("SELECT email,full_name FROM users WHERE active=1 AND role IN (?,?) AND LOWER(TRIM(department))=? AND full_name=?",(roles[0],roles[1],dept.lower(),t["assigned_to"] or "")).fetchone()
        conn.close()
        if u: recipient=u["email"]; name=u["full_name"]
    if not recipient: return True, ""
    conn=get_db()
    c=conn.execute("SELECT c.comment,u.full_name FROM comments c JOIN users u ON c.user_id=u.id WHERE c.ticket_id=? ORDER BY c.id DESC LIMIT 1",(ticket_id,)).fetchone()
    conn.close()
    body=f"""Dear {name},

A new comment/reply was added to ticket {t['ticket_no']}.

From: {c['full_name']}

Comment:
{c['comment']}

Regards,
IT Service Desk"""
    return send_email(recipient,f"Ticket Comment - {t['ticket_no']}",body)

def login_required(f):
    @wraps(f)
    def w(*a,**k):
        if "user_id" not in session: return redirect(url_for("login"))
        return f(*a,**k)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a,**k):
        if session.get("role")!="admin": abort(403)
        return f(*a,**k)
    return w

def allowed(fn):
    return "." in fn and fn.rsplit(".",1)[1].lower() in ALLOWED_EXTENSIONS


STATUS_OPTIONS = ["New", "Assigned", "In Progress", "Pending", "Reopened", "Resolved", "Closed"]


def feedback_for_ticket(ticket_id):
    conn = get_db()
    row = conn.execute("""SELECT f.*, u.full_name FROM ticket_feedback f
                         JOIN users u ON f.user_id=u.id WHERE f.ticket_id=?
                         ORDER BY f.id DESC LIMIT 1""", (ticket_id,)).fetchone()
    conn.close()
    return row


def notify_reopened(ticket_id, reason):
    t, _ = ticket_email_data(ticket_id)
    if not t:
        return False, "Ticket not found."
    team = (t["team"] or "IT").upper()
    recipients = active_team_emails(team)
    conn = get_db()
    admins = conn.execute("SELECT email FROM users WHERE active=1 AND role='admin' AND email IS NOT NULL AND TRIM(email)<>''").fetchall()
    conn.close()
    recipients = list(dict.fromkeys(recipients + [r["email"] for r in admins]))
    if not recipients:
        return False, "No active team/admin email address is configured."
    team_name = "ERP Team" if team == "ERP" else "IT Team"
    body = f"""Dear {team_name},\n\nA ticket has been reopened by the employee.\n\nTicket No: {t['ticket_no']}\nEmployee: {t['requester']}\nDepartment: {t['requester_department']}\nSupport Team: {team_name}\nPriority: {t['priority']}\nAssigned To: {t['assigned_to'] or 'Not Assigned'}\nSubject: {t['subject']}\n\nReopen Reason:\n{reason}\n\nPlease review and take necessary action.\n\nRegards,\nIT Service Desk"""
    return send_email(recipients, f"Ticket Reopened - {t['ticket_no']}", body)


def build_report_data(start_date=None, end_date=None):
    conn = get_db()
    where=[]; params=[]
    if start_date:
        where.append("date(t.created_at) >= date(?)"); params.append(start_date)
    if end_date:
        where.append("date(t.created_at) <= date(?)"); params.append(end_date)
    clause = " WHERE " + " AND ".join(where) if where else ""
    rows = conn.execute(f"""SELECT t.*, u.full_name AS employee_name, u.department AS department,
                           u.designation AS designation
                           FROM tickets t JOIN users u ON t.user_id=u.id{clause}
                           ORDER BY t.id ASC""", params).fetchall()
    status_rows = conn.execute(f"SELECT t.status, COUNT(*) c FROM tickets t{clause} GROUP BY t.status", params).fetchall()
    priority_rows = conn.execute(f"SELECT t.priority, COUNT(*) c FROM tickets t{clause} GROUP BY t.priority", params).fetchall()
    team_rows = conn.execute(f"SELECT COALESCE(t.team,'IT') team, COUNT(*) c FROM tickets t{clause} GROUP BY COALESCE(t.team,'IT')", params).fetchall()
    dept_rows = conn.execute(f"""SELECT COALESCE(u.department,'-') department, COUNT(*) c
                               FROM tickets t JOIN users u ON t.user_id=u.id{clause}
                               GROUP BY COALESCE(u.department,'-') ORDER BY c DESC, department""", params).fetchall()
    tech_rows = conn.execute(f"""SELECT COALESCE(t.assigned_to,'Not Assigned') assigned_to, COUNT(*) c
                               FROM tickets t{clause}
                               GROUP BY COALESCE(t.assigned_to,'Not Assigned') ORDER BY c DESC, assigned_to""", params).fetchall()
    conn.close()
    status = {r['status']: r['c'] for r in status_rows}
    priority = {r['priority']: r['c'] for r in priority_rows}
    team = {('ERP Team' if r['team']=='ERP' else 'IT Team'): r['c'] for r in team_rows}
    breached = sum(1 for r in rows if sla_state(r) == 'SLA Breached')
    completed = sum(1 for r in rows if r['status'] in ('Resolved','Closed'))
    ratings_conn = get_db()
    if start_date or end_date:
        fwhere=[]; fparams=[]
        if start_date: fwhere.append("date(f.created_at) >= date(?)"); fparams.append(start_date)
        if end_date: fwhere.append("date(f.created_at) <= date(?)"); fparams.append(end_date)
        fclause=" WHERE "+" AND ".join(fwhere)
        feedback = ratings_conn.execute(f"SELECT COUNT(*) c, AVG(rating) avg_rating FROM ticket_feedback f{fclause}", fparams).fetchone()
    else:
        feedback = ratings_conn.execute("SELECT COUNT(*) c, AVG(rating) avg_rating FROM ticket_feedback").fetchone()
    ratings_conn.close()
    return dict(rows=rows, total=len(rows), status=status, priority=priority, team=team,
                departments=dept_rows, technicians=tech_rows, breached=breached,
                completed=completed, feedback_count=feedback['c'] or 0,
                avg_rating=round(feedback['avg_rating'],2) if feedback['avg_rating'] is not None else None)


def report_text(title, period_label, data):
    lines=["MEDILUX LABORATORIES PVT. LTD. - IT SERVICE DESK", title, "="*70,
           f"Period: {period_label}", "", f"Total Tickets: {data['total']}",
           f"Completed (Resolved/Closed): {data['completed']}", f"SLA Breached: {data['breached']}",
           f"Employee Feedback Count: {data['feedback_count']}",
           f"Average Rating: {data['avg_rating'] if data['avg_rating'] is not None else 'No ratings yet'}", "",
           "TEAM SUMMARY", "-"*70]
    for k in ("IT Team","ERP Team"): lines.append(f"{k}: {data['team'].get(k,0)}")
    lines += ["", "STATUS SUMMARY", "-"*70]
    for s in STATUS_OPTIONS: lines.append(f"{s}: {data['status'].get(s,0)}")
    lines += ["", "PRIORITY SUMMARY", "-"*70]
    for p in ("Critical","High","Medium","Low"): lines.append(f"{p}: {data['priority'].get(p,0)}")
    lines += ["", "DEPARTMENT SUMMARY", "-"*70]
    for r in data['departments']: lines.append(f"{r['department']}: {r['c']}")
    lines += ["", "TECHNICIAN WORKLOAD", "-"*70]
    for r in data['technicians']: lines.append(f"{r['assigned_to']}: {r['c']}")
    lines += ["", "TICKET DETAILS", "-"*70]
    if not data['rows']: lines.append("No tickets found for this period.")
    for i,r in enumerate(data['rows'],1):
        lines += ["", f"{i}. {r['ticket_no']}", f"   Employee: {r['employee_name']}",
                  f"   Department: {r['department']}", f"   Team: {'ERP Team' if r['team']=='ERP' else 'IT Team'}",
                  f"   Subject: {r['subject']}", f"   Priority: {r['priority']}", f"   Status: {r['status']}",
                  f"   SLA: {sla_state(r)}", f"   SLA Due: {r['due_at'] or '-'}",
                  f"   Assigned To: {r['assigned_to'] or 'Not Assigned'}", f"   Created: {r['created_at']}",
                  f"   Updated: {r['updated_at']}" ]
    lines += ["", "="*70, "Generated by Medilux Laboratories Pvt. Ltd. - IT Service Desk"]
    return "\n".join(lines)


def build_daily_report(report_date):
    data=build_report_data(report_date,report_date)
    return report_text("DAILY TICKET REPORT",report_date,data)


@app.context_processor
def global_admin_notices():
    """Expose IT announcements to dashboards. Maintenance Mode was removed."""
    try:
        conn=get_db()
        announcements=conn.execute("SELECT * FROM it_announcements WHERE active=1 ORDER BY id DESC LIMIT 5").fetchall()
        conn.close()
        return {"active_maintenance":[],"active_announcements":announcements}
    except Exception:
        return {"active_maintenance":[],"active_announcements":[]}

@app.route("/admin/announcements", methods=["GET","POST"])
@login_required
@admin_required
def announcements_center():
    conn=get_db()
    if request.method=="POST":
        title=request.form.get("title","").strip(); message=request.form.get("message","").strip(); priority=request.form.get("priority","Normal").strip() or "Normal"
        if not title or not message: flash("Title and message are required.","error")
        else:
            conn.execute("INSERT INTO it_announcements(title,message,priority,active,created_by,created_at) VALUES(?,?,?,1,?,?)",(title,message,priority,session.get("user_id"),datetime.now().strftime("%Y-%m-%d %H:%M:%S"))); conn.commit(); flash("IT announcement published.","success"); return redirect(url_for("announcements_center"))
    rows=conn.execute("SELECT * FROM it_announcements ORDER BY id DESC").fetchall(); conn.close()
    return render_template("announcements_center.html",rows=rows)

@app.post("/admin/announcements/<int:announcement_id>/toggle")
@login_required
@admin_required
def toggle_announcement(announcement_id):
    conn=get_db(); conn.execute("UPDATE it_announcements SET active=CASE WHEN active=1 THEN 0 ELSE 1 END WHERE id=?",(announcement_id,)); conn.commit(); conn.close(); return redirect(url_for("announcements_center"))

@app.route("/")
def index():
    if "user_id" not in session: return redirect(url_for("login"))
    role=session["role"]
    if session.get("is_department_head") and role != "admin": target="department_head_dashboard"
    elif role=="admin": target="admin_dashboard"
    elif role=="it_user": target="it_dashboard"
    elif role=="erp_admin": target="erp_admin_dashboard"
    elif role=="erp_user": target="erp_dashboard"
    else: target="employee_dashboard"
    return redirect(url_for(target))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=request.form.get("username", "").strip(); p=request.form.get("password", "")
        conn=get_db()
        user=conn.execute("SELECT * FROM users WHERE username=?",(u,)).fetchone()
        security=conn.execute("SELECT * FROM login_security WHERE username=?",(u,)).fetchone()
        now_dt=datetime.now()

        # Check temporary lock before validating the password.
        if security and security["locked_until"]:
            try:
                locked_until=datetime.strptime(security["locked_until"], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                locked_until=None
            if locked_until and now_dt < locked_until:
                remaining=max(1, int((locked_until-now_dt).total_seconds()/60 + 0.999))
                conn.close()
                if user:
                    audit("Login blocked - account temporarily locked", "user", user["id"], f"Username: {u}; Remaining minutes: {remaining}")
                flash(f"Too many failed login attempts. Please try again after {remaining} minute(s).", "error")
                return render_template("login.html")
            # Lock expired; clear the old lock so a new attempt window starts cleanly.
            conn.execute("UPDATE login_security SET failed_attempts=0, locked_until=NULL WHERE username=?", (u,))
            conn.commit()
            security=conn.execute("SELECT * FROM login_security WHERE username=?",(u,)).fetchone()

        if user and user["active"] and check_password_hash(user["password_hash"],p):
            conn.execute("DELETE FROM login_security WHERE username=?", (u,))
            conn.commit(); conn.close()
            session.permanent = True
            session["last_activity"] = datetime.now().isoformat(timespec="seconds")
            session.update(user_id=user["id"],full_name=user["full_name"],role=user["role"],department=user["department"],is_department_head=bool(user["is_department_head"]))
            audit("Login successful", "user", user["id"], f"Username: {user['username']}")
            return redirect(url_for("index"))

        # Track failed attempts for existing active users only.
        if user and user["active"]:
            current=security["failed_attempts"] if security else 0
            attempts=current+1
            if security:
                if attempts >= MAX_LOGIN_ATTEMPTS:
                    locked_until=(now_dt+timedelta(minutes=LOGIN_LOCK_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
                    conn.execute("UPDATE login_security SET failed_attempts=?, locked_until=?, last_failed_at=? WHERE username=?", (attempts, locked_until, now(), u))
                    detail=f"Username: {u}; Failed attempts: {attempts}; Locked for {LOGIN_LOCK_MINUTES} minutes"
                    action="Login failed - account locked"
                    message=f"Too many failed login attempts. Your account is locked for {LOGIN_LOCK_MINUTES} minutes."
                else:
                    conn.execute("UPDATE login_security SET failed_attempts=?, last_failed_at=? WHERE username=?", (attempts, now(), u))
                    detail=f"Username: {u}; Failed attempts: {attempts} of {MAX_LOGIN_ATTEMPTS}"
                    action="Login failed"
                    message="Invalid username or password."
            else:
                locked_until=None
                if attempts >= MAX_LOGIN_ATTEMPTS:
                    locked_until=(now_dt+timedelta(minutes=LOGIN_LOCK_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
                conn.execute("INSERT INTO login_security(username,failed_attempts,locked_until,last_failed_at) VALUES(?,?,?,?)", (u, attempts, locked_until, now()))
                if locked_until:
                    detail=f"Username: {u}; Failed attempts: {attempts}; Locked for {LOGIN_LOCK_MINUTES} minutes"
                    action="Login failed - account locked"
                    message=f"Too many failed login attempts. Your account is locked for {LOGIN_LOCK_MINUTES} minutes."
                else:
                    detail=f"Username: {u}; Failed attempts: {attempts} of {MAX_LOGIN_ATTEMPTS}"
                    action="Login failed"
                    message="Invalid username or password."
            conn.commit(); conn.close()
            # Log with the user's ID after the DB update.
            audit(action, "user", user["id"], detail)
            flash(message, "error")
        else:
            conn.close()
            audit("Login failed", "user", user["id"] if user else None, f"Username: {u or '[blank]'}; Invalid username, password, or inactive account")
            flash("Invalid username or password.","error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    if session.get("user_id"): audit("Logout", "user", session.get("user_id"), "User logged out")
    session.clear(); return redirect(url_for("login"))

@app.route("/setup", methods=["GET", "POST"])
def setup_admin():
    conn = get_db()
    user_count = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
    if user_count > 0:
        conn.close()
        return redirect(url_for("login"))
    if request.method == "POST":
        username = request.form["username"].strip()
        full_name = request.form["full_name"].strip()
        department = request.form["department"].strip() or "IT"
        password = request.form["password"]
        confirm = request.form["confirm_password"]
        email = request.form.get("email","").strip()
        if not username or not full_name or not password:
            flash("Username, name and password are required.", "error")
            conn.close(); return render_template("setup_admin.html")
        if password != confirm:
            flash("Passwords do not match.", "error")
            conn.close(); return render_template("setup_admin.html")
        if len(password) < 6:
            flash("Password must be at least 6 characters.", "error")
            conn.close(); return render_template("setup_admin.html")
        try:
            conn.execute("INSERT INTO users(username,full_name,department,role,password_hash,created_at,active,email) VALUES(?,?,?,?,?,?,1,?)",
                         (username, full_name, department, "admin", generate_password_hash(password), now(), email))
            conn.commit()
        except sqlite3.IntegrityError:
            flash("Username already exists.", "error")
            conn.close(); return render_template("setup_admin.html")
        conn.close()
        flash("First IT admin created. Please log in.", "success")
        return redirect(url_for("login"))
    conn.close()
    return render_template("setup_admin.html")

@app.route("/it")
@login_required
def it_dashboard():
    if session.get("role")!="it_user": abort(403)
    q=request.args.get("q","").strip(); status=request.args.get("status","").strip(); priority=request.args.get("priority","").strip()
    conn=get_db(); where=["(t.team='IT' OR t.team IS NULL)"]; params=[]
    if q:
        like=f"%{q}%"; where.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ? OR COALESCE(t.assigned_to,'') LIKE ?)"); params += [like]*5
    if status in ("New","Assigned","In Progress","Pending","Reopened","Resolved","Closed"): where.append("t.status=?"); params.append(status)
    if priority in ("Low","Medium","High","Critical"): where.append("t.priority=?"); params.append(priority)
    tickets=conn.execute(f"SELECT t.*,u.full_name,u.department FROM tickets t JOIN users u ON t.user_id=u.id WHERE {' AND '.join(where)} ORDER BY t.id DESC",params).fetchall()
    tickets=[dict(t, sla_state=sla_state(t)) for t in tickets]
    stats={"total":len(tickets),"open":sum(t["status"] in ("New","Assigned","In Progress","Pending","Reopened") for t in tickets),"progress":sum(t["status"]=="In Progress" for t in tickets),"resolved":sum(t["status"] in ("Resolved","Closed") for t in tickets),"breached":sum(t["sla_state"]=="SLA Breached" for t in tickets)}
    report=conn.execute("SELECT * FROM daily_reports WHERE user_id=? AND report_date=?",(session["user_id"],date.today().isoformat())).fetchone()
    conn.close()
    return render_template("it_dashboard.html",tickets=tickets,stats=stats,search=q,status_filter=status,priority_filter=priority,today_report=report)

@app.route("/erp")
@login_required
def erp_dashboard():
    if session.get("role")!="erp_user": abort(403)
    q=request.args.get("q","").strip(); status=request.args.get("status","").strip(); priority=request.args.get("priority","").strip()
    conn=get_db(); where=["t.team='ERP'"]; params=[]
    if q:
        like=f"%{q}%"; where.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ? OR COALESCE(t.assigned_to,'') LIKE ?)"); params += [like]*5
    if status in ("New","Assigned","In Progress","Pending","Reopened","Resolved","Closed"): where.append("t.status=?"); params.append(status)
    if priority in ("Low","Medium","High","Critical"): where.append("t.priority=?"); params.append(priority)
    tickets=conn.execute(f"SELECT t.*,u.full_name,u.department FROM tickets t JOIN users u ON t.user_id=u.id WHERE {' AND '.join(where)} ORDER BY t.id DESC",params).fetchall()
    tickets=[dict(t, sla_state=sla_state(t)) for t in tickets]
    stats={"total":len(tickets),"open":sum(t["status"] in ("New","Assigned","In Progress","Pending","Reopened") for t in tickets),"progress":sum(t["status"]=="In Progress" for t in tickets),"resolved":sum(t["status"] in ("Resolved","Closed") for t in tickets),"breached":sum(t["sla_state"]=="SLA Breached" for t in tickets)}
    conn.close()
    return render_template("erp_dashboard.html",tickets=tickets,stats=stats,search=q,status_filter=status,priority_filter=priority)

@app.route("/erp-admin")
@login_required
def erp_admin_dashboard():
    if session.get("role")!="erp_admin": abort(403)
    q=request.args.get("q","").strip(); status=request.args.get("status","").strip(); priority=request.args.get("priority","").strip()
    conn=get_db(); where=["t.team='ERP'"]; params=[]
    if q:
        like=f"%{q}%"; where.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ?)"); params += [like,like,like,like]
    if status in ("New","Assigned","In Progress","Pending","Reopened","Resolved","Closed"): where.append("t.status=?"); params.append(status)
    if priority in ("Low","Medium","High","Critical"): where.append("t.priority=?"); params.append(priority)
    tickets=conn.execute(f"SELECT t.*,u.full_name,u.department FROM tickets t JOIN users u ON t.user_id=u.id WHERE {' AND '.join(where)} ORDER BY t.id DESC",params).fetchall()
    tickets=[dict(t, sla_state=sla_state(t)) for t in tickets]
    stats={"total":len(tickets),"open":sum(t["status"] in ("New","Assigned","In Progress","Pending") for t in tickets),"resolved":sum(t["status"] in ("Resolved","Closed") for t in tickets)}
    conn.close()
    return render_template("erp_admin_dashboard.html",tickets=tickets,stats=stats,search=q,status_filter=status,priority_filter=priority)

@app.route("/department-head")
@login_required
def department_head_dashboard():
    if not session.get("is_department_head") or session.get("role")=="admin": abort(403)
    dept=session.get("department") or ""
    q=request.args.get("q","").strip(); status=request.args.get("status","").strip(); priority=request.args.get("priority","").strip()
    where=["LOWER(TRIM(u.department))=LOWER(TRIM(?))"]; params=[dept]
    if q:
        like=f"%{q}%"; where.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ? OR t.location LIKE ?)"); params += [like]*5
    if status in STATUS_OPTIONS: where.append("t.status=?"); params.append(status)
    if priority in ("Low","Medium","High","Critical"): where.append("t.priority=?"); params.append(priority)
    conn=get_db()
    tickets=conn.execute(f"SELECT t.*,u.full_name,u.department FROM tickets t JOIN users u ON t.user_id=u.id WHERE {' AND '.join(where)} ORDER BY t.id DESC",params).fetchall()
    tickets=[dict(t,sla_state=sla_state(t)) for t in tickets]
    stats={"total":len(tickets),"open":sum(t["status"] in ("New","Assigned","In Progress","Pending","Reopened") for t in tickets),"resolved":sum(t["status"] in ("Resolved","Closed") for t in tickets),"breached":sum(t["status"] not in ("Resolved","Closed") and t["due_at"] and datetime.strptime(t["due_at"],"%Y-%m-%d %H:%M:%S") < datetime.now() for t in tickets)}
    employees=conn.execute("SELECT COUNT(*) c FROM users WHERE active=1 AND LOWER(TRIM(department))=LOWER(TRIM(?))",(dept,)).fetchone()["c"]
    employee_rows=conn.execute("""
        SELECT u.id,u.username,u.full_name,u.email,u.designation,u.department,
               COUNT(t.id) AS total_tickets,
               SUM(CASE WHEN t.status IN ('New','Assigned','In Progress','Pending','Reopened') THEN 1 ELSE 0 END) AS open_tickets,
               SUM(CASE WHEN t.status IN ('Resolved','Closed') THEN 1 ELSE 0 END) AS completed_tickets,
               MAX(t.created_at) AS last_ticket
        FROM users u
        LEFT JOIN tickets t ON t.user_id=u.id
        WHERE u.active=1 AND LOWER(TRIM(u.department))=LOWER(TRIM(?))
        GROUP BY u.id,u.username,u.full_name,u.email,u.designation,u.department
        ORDER BY total_tickets DESC,u.full_name
    """,(dept,)).fetchall()
    conn.close()
    stats["employees"]=employees
    return render_template("department_head_dashboard.html",tickets=tickets,stats=stats,department=dept,search=q,status_filter=status,priority_filter=priority,employee_rows=employee_rows)

@app.route("/department-head/employee/<int:employee_id>")
@login_required
def department_head_employee_detail(employee_id):
    if not session.get("is_department_head") or session.get("role")=="admin": abort(403)
    dept=session.get("department") or ""
    conn=get_db()
    employee=conn.execute("SELECT id,username,full_name,email,designation,department FROM users WHERE id=? AND active=1",(employee_id,)).fetchone()
    if not employee or str(employee["department"] or "").strip().lower()!=str(dept).strip().lower():
        conn.close(); abort(403)
    tickets=conn.execute("SELECT t.*,u.full_name,u.department FROM tickets t JOIN users u ON t.user_id=u.id WHERE t.user_id=? ORDER BY t.id DESC",(employee_id,)).fetchall()
    tickets=[dict(t,sla_state=sla_state(t)) for t in tickets]
    stats={
        "total":len(tickets),
        "open":sum(t["status"] in ("New","Assigned","In Progress","Pending","Reopened") for t in tickets),
        "completed":sum(t["status"] in ("Resolved","Closed") for t in tickets),
        "breached":sum(t["status"] not in ("Resolved","Closed") and t["due_at"] and datetime.strptime(t["due_at"],"%Y-%m-%d %H:%M:%S") < datetime.now() for t in tickets)
    }
    conn.close()
    return render_template("department_head_employee.html",employee=employee,tickets=tickets,stats=stats,department=dept)

@app.route("/employee")
@login_required
def employee_dashboard():
    conn=get_db()
    all_tickets=conn.execute("SELECT * FROM tickets WHERE user_id=? ORDER BY id DESC",(session["user_id"],)).fetchall()
    q=request.args.get("q","").strip().lower()
    status_filter=request.args.get("status","").strip()
    team_filter=request.args.get("team","").strip().upper()
    tickets=[]
    for t in all_tickets:
        if status_filter:
            if status_filter=="Resolved / Closed":
                if t["status"] not in ("Resolved","Closed"):
                    continue
            elif t["status"] != status_filter:
                continue
        if team_filter and (t["team"] or "IT").upper() != team_filter:
            continue
        if q:
            hay=" ".join(str(t[k] or "") for k in ("ticket_no","subject","category","subcategory","priority","status","team","location")).lower()
            if q not in hay:
                continue
        tickets.append(t)
    stats={
        "total":len(all_tickets),
        "open":sum(t["status"] in ("New","Assigned","In Progress","Pending","Reopened") for t in all_tickets),
        "new":sum(t["status"]=="New" for t in all_tickets),
        "assigned":sum(t["status"]=="Assigned" for t in all_tickets),
        "in_progress":sum(t["status"]=="In Progress" for t in all_tickets),
        "pending":sum(t["status"]=="Pending" for t in all_tickets),
        "reopened":sum(t["status"]=="Reopened" for t in all_tickets),
        "resolved":sum(t["status"] in ("Resolved","Closed") for t in all_tickets),
        "it":sum((t["team"] or "IT")=="IT" for t in all_tickets),
        "erp":sum((t["team"] or "IT")=="ERP" for t in all_tickets),
    }
    conn.close()
    return render_template("employee_dashboard.html",tickets=tickets,stats=stats,search=q,status_filter=status_filter,team_filter=team_filter)
@app.route("/ticket/new", methods=["GET","POST"])
@login_required
def new_ticket():
    if request.method=="POST":
        subject=request.form.get("subject","").strip()
        category=request.form.get("category","").strip(); subcategory=request.form.get("subcategory","").strip()
        priority=request.form.get("priority","").strip(); location=request.form.get("location","").strip()
        description=request.form.get("description","").strip()
        meeting_requested=1 if request.form.get("meeting_requested") == "1" else 0
        meeting_platform_requested=request.form.get("meeting_platform_requested","").strip().lower() if meeting_requested else ""
        if meeting_platform_requested not in ("", "zoom", "teams", "google"):
            meeting_platform_requested=""
        team=request.form.get("team","").strip().upper()
        if team not in ("IT","ERP"):
            flash("Please select a valid Support Team: IT Team or ERP Team.", "error")
            return render_template("new_ticket.html")
        if category not in ("Hardware","Software","Network","Access","Email","ERP","Other"):
            flash("Please select a valid ticket category.", "error")
            return render_template("new_ticket.html")
        if priority not in ("Low","Medium","High","Critical"):
            flash("Please select a valid ticket priority.", "error")
            return render_template("new_ticket.html")
        if not subject or not description:
            flash("Subject and description are required.","error")
            return render_template("new_ticket.html")
        conn=get_db(); created=now()
        try:
            # Keep ticket creation compatible with the Phase 1 database.
            ticket_cols=[r[1] for r in conn.execute("PRAGMA table_info(tickets)").fetchall()]
            if "team" not in ticket_cols:
                conn.execute("ALTER TABLE tickets ADD COLUMN team TEXT NOT NULL DEFAULT 'IT'")
            if "due_at" not in ticket_cols:
                conn.execute("ALTER TABLE tickets ADD COLUMN due_at TEXT")
            if "escalation_notified_at" not in ticket_cols:
                conn.execute("ALTER TABLE tickets ADD COLUMN escalation_notified_at TEXT")
            cur=conn.execute(
                "INSERT INTO tickets(ticket_no,user_id,subject,category,subcategory,priority,description,status,assigned_to,location,team,created_at,updated_at,due_at,meeting_requested,meeting_platform_requested) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (None,session["user_id"],subject,category,subcategory,priority,description,"New",None,location,team,created,created,calculate_due_at(priority, created),meeting_requested,meeting_platform_requested))
            tid=cur.lastrowid; ticket_no=f"IT-{datetime.now().year}-{tid:05d}"
            conn.execute("UPDATE tickets SET ticket_no=? WHERE id=?",(ticket_no,tid))
            conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(tid,session["user_id"],f"Ticket created for {'ERP Team' if team=='ERP' else 'IT Team'}",created))
            if meeting_requested:
                conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(tid,session["user_id"],f"Meeting requested ({meeting_platform_requested or 'Any platform'})",created))
            conn.commit()
            audit("Ticket created", "ticket", tid, f"{ticket_no} | Team: {team} | Priority: {priority}")
            file=request.files.get("attachment")
            if file and file.filename and allowed(file.filename):
                safe=secure_filename(file.filename); stored=f"{uuid.uuid4().hex}_{safe}"
                file.save(os.path.join(app.config["UPLOAD_FOLDER"],stored))
                conn.execute("INSERT INTO attachments(ticket_id,user_id,original_name,stored_name,created_at) VALUES(?,?,?,?,?)",(tid,session["user_id"],safe,stored,now())); conn.commit()
            conn.close()
        except Exception as e:
            conn.rollback(); conn.close()
            logging.exception("Ticket creation failed")
            flash(f"Ticket could not be created: {e}", "error")
            return render_template("new_ticket.html")
        # Email notification is sent in the background so ticket creation does not
        # wait for the SMTP server, DNS, TLS handshake or attachment processing.
        threading.Thread(target=_background_ticket_created_email, args=(tid,), daemon=True, name=f"ticket-email-{tid}").start()
        flash(f"Ticket {ticket_no} created successfully.","success")
        return redirect(url_for("ticket_detail",ticket_id=tid))
    return render_template("new_ticket.html")


# ---- IT Desk ↔ Inventory Store integration ----
def inventory_db_path():
    # Keep the Inventory application/database separate so its existing data and
    # workflows remain untouched. The two project folders are distributed side-by-side.
    configured = os.environ.get("INVENTORY_DB_PATH")
    if configured:
        return os.path.abspath(configured)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "Project_Inventry_live", "inventory.db"))

def inventory_conn():
    path = inventory_db_path()
    if not os.path.exists(path):
        return None
    c = sqlite3.connect(path, timeout=10)
    c.row_factory = sqlite3.Row
    return c

def inventory_ticket_items(ticket_no):
    c = inventory_conn()
    if c is None:
        return [], []
    try:
        items = c.execute("SELECT * FROM consumable_items WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
        tx = c.execute("""SELECT t.*, i.name AS item_name, i.unit
                          FROM consumable_transactions t
                          JOIN consumable_items i ON i.id=t.item_id
                          WHERE t.ticket_no=?
                          ORDER BY t.changed_at DESC, t.id DESC""",(ticket_no,)).fetchall()
        outstanding = {}
        for r in tx:
            key = r["item_id"]
            delta = int(r["qty"] or 0) if r["txn_type"] in ("Issue","Stock Out") else -int(r["qty"] or 0) if r["txn_type"]=="Return" else 0
            outstanding[key] = outstanding.get(key,0) + delta
        open_items = []
        for r in items:
            q = outstanding.get(r["id"],0)
            if q > 0:
                open_items.append({"id":r["id"],"name":r["name"],"unit":r["unit"],"qty":q})
        return items, tx, open_items
    except Exception:
        logging.exception("Inventory read failed")
        return [], [], []
    finally:
        c.close()

@app.route("/ticket/<int:ticket_id>/inventory", methods=["POST"])
@login_required
def ticket_inventory_transaction(ticket_id):
    t,_,_,_,_=get_ticket(ticket_id)
    if not t: abort(404)
    role=session.get("role")
    team=(t["team"] or "IT").upper()
    # Inventory issue/return is an IT-team action only.
    if team != "IT" or role not in ("admin","it_user"):
        abort(403)
    c = inventory_conn()
    if c is None:
        flash("Inventory database is not connected. Keep both project folders together.", "error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    try:
        item_id=int(request.form.get("item_id") or 0)
        qty=max(1,int(request.form.get("qty") or 0))
        typ=request.form.get("txn_type","Issue")
        if typ not in ("Issue","Return"):
            typ="Issue"
        item=c.execute("SELECT * FROM consumable_items WHERE id=? AND active=1",(item_id,)).fetchone()
        if not item:
            flash("Inventory item not found.", "error")
            return redirect(url_for("ticket_detail",ticket_id=ticket_id))
        if typ=="Issue":
            available=int(item["available_qty"] or 0)
            if qty>available:
                flash(f"Only {available} {item['unit']} available for {item['name']}.", "error")
                return redirect(url_for("ticket_detail",ticket_id=ticket_id))
            new_avail=available-qty
            total=int(item["total_qty"] or 0)
            reason=(request.form.get("reason") or "Issued from IT Ticket").strip()
            condition=""
        else:
            # Return cannot exceed the quantity currently issued against this ticket/item.
            rows=c.execute("""SELECT txn_type, qty FROM consumable_transactions
                              WHERE ticket_no=? AND item_id=? ORDER BY id""",(t["ticket_no"],item_id)).fetchall()
            issued=sum(int(r["qty"] or 0) for r in rows if r["txn_type"] in ("Issue","Stock Out"))
            returned=sum(int(r["qty"] or 0) for r in rows if r["txn_type"]=="Return")
            outstanding=max(0,issued-returned)
            if qty>outstanding:
                flash(f"Only {outstanding} {item['unit']} currently issued against this ticket.", "error")
                return redirect(url_for("ticket_detail",ticket_id=ticket_id))
            available=int(item["available_qty"] or 0)
            reason=(request.form.get("reason") or "Returned from IT Ticket").strip()
            condition=(request.form.get("condition") or "").strip()
            # Only a Working return goes back into Available Stock.
            new_avail=available+qty if condition.lower()=="working" else available
            total=max(int(item["total_qty"] or 0),new_avail)
        c.execute("UPDATE consumable_items SET available_qty=?, total_qty=? WHERE id=?",(new_avail,total,item_id))
        c.execute("""INSERT INTO consumable_transactions
                     (item_id,txn_type,qty,issued_to,department,ticket_no,reason,condition,remarks,changed_by)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  (item_id,typ,qty,t["full_name"],t["department"] or "",t["ticket_no"],reason,condition,
                   (request.form.get("remarks") or "").strip(),session.get("full_name") or session.get("username") or "IT User"))
        c.commit()
        flash(f"{item['name']} × {qty} {'issued' if typ=='Issue' else 'returned'} successfully.", "success")
        audit("Inventory item issued" if typ=="Issue" else "Inventory item returned",
              "ticket",ticket_id,f"{item['name']} x {qty} | Ticket {t['ticket_no']}")
    except (ValueError,sqlite3.Error) as e:
        c.rollback()
        logging.exception("Ticket inventory transaction failed")
        flash("Inventory transaction could not be completed.", "error")
    finally:
        c.close()
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

def get_ticket(tid):
    conn=get_db()
    t=conn.execute("""SELECT t.*,u.full_name,u.department,u.designation,u.username FROM tickets t JOIN users u ON t.user_id=u.id WHERE t.id=?""",(tid,)).fetchone()
    comments=conn.execute("""SELECT c.*,u.full_name,u.role FROM comments c JOIN users u ON c.user_id=u.id WHERE c.ticket_id=? ORDER BY c.id""",(tid,)).fetchall()
    attachments=conn.execute("SELECT * FROM attachments WHERE ticket_id=? ORDER BY id",(tid,)).fetchall()
    history=conn.execute("""SELECT h.*,u.full_name FROM ticket_history h JOIN users u ON h.user_id=u.id WHERE h.ticket_id=? ORDER BY h.id DESC""",(tid,)).fetchall()
    feedback=conn.execute("""SELECT f.*,u.full_name FROM ticket_feedback f JOIN users u ON f.user_id=u.id WHERE f.ticket_id=? ORDER BY f.id DESC LIMIT 1""",(tid,)).fetchone()
    conn.close(); return t,comments,attachments,history,feedback

@app.route("/ticket/<int:ticket_id>")
@login_required
def ticket_detail(ticket_id):
    t,comments,attachments,history,feedback=get_ticket(ticket_id)
    if not t: abort(404)
    role=session["role"]; team=(t["team"] or "IT").upper()
    if role=="admin": allowed_view=True
    elif session.get("is_department_head"): allowed_view=(str(t["department"] or "").strip().lower()==str(session.get("department") or "").strip().lower())
    elif role=="employee": allowed_view=(t["user_id"]==session["user_id"])
    elif role=="it_user": allowed_view=(team=="IT")
    elif role=="erp_user": allowed_view=(team=="ERP")
    elif role=="erp_admin": allowed_view=(team=="ERP")
    else: allowed_view=False
    if not allowed_view: abort(403)
    conn=get_db()
    if role=="admin":
        team_users=conn.execute("SELECT id,full_name,username,role FROM users WHERE active=1 AND ((role IN ('admin','it_user') AND LOWER(TRIM(department))='it') OR (role IN ('erp_admin','erp_user') AND LOWER(TRIM(department))='erp')) ORDER BY full_name").fetchall()
    elif team=="ERP":
        team_users=conn.execute("SELECT id,full_name,username,role FROM users WHERE active=1 AND role IN ('erp_admin','erp_user') AND LOWER(TRIM(department))='erp' ORDER BY full_name").fetchall()
    else:
        team_users=conn.execute("SELECT id,full_name,username,role FROM users WHERE active=1 AND role IN ('admin','it_user') AND LOWER(TRIM(department))='it' ORDER BY full_name").fetchall()
    meetings=conn.execute("SELECT * FROM meetings WHERE ticket_id=? ORDER BY id DESC",(ticket_id,)).fetchall()
    contacts=conn.execute("SELECT * FROM meeting_contacts WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
    groups=conn.execute("SELECT g.id,g.name,COUNT(m.contact_id) member_count FROM meeting_groups g LEFT JOIN meeting_group_members m ON m.group_id=g.id WHERE g.active=1 GROUP BY g.id ORDER BY g.name COLLATE NOCASE").fetchall()
    group_rows=conn.execute("SELECT g.name,c.email FROM meeting_groups g JOIN meeting_group_members gm ON gm.group_id=g.id JOIN meeting_contacts c ON c.id=gm.contact_id WHERE g.active=1 AND c.active=1 ORDER BY g.name,c.email").fetchall()
    group_emails={}
    for gr in group_rows: group_emails.setdefault(gr['name'],[]).append(gr['email'])
    saved_links=conn.execute("SELECT * FROM saved_meeting_links WHERE active=1 ORDER BY provider,name").fetchall()
    conn.close()
    inventory_items, inventory_tx, inventory_open = inventory_ticket_items(t["ticket_no"]) if team=="IT" else ([], [], [])
    return render_template("ticket_detail.html",ticket=t,comments=comments,attachments=attachments,history=history,feedback=feedback,it_users=team_users,team_users=team_users,sla=sla_state(t),inventory_items=inventory_items,inventory_tx=inventory_tx,inventory_open=inventory_open,inventory_connected=os.path.exists(inventory_db_path()),meetings=meetings,meeting_contacts=contacts,meeting_groups=groups,saved_meeting_links=saved_links)

@app.route("/ticket/<int:ticket_id>/comment",methods=["POST"])
@login_required
def add_comment(ticket_id):
    t,_,_,_,_=get_ticket(ticket_id)
    if not t: abort(404)
    role=session["role"]; team=(t["team"] or "IT").upper()
    if role=="admin":
        pass
    elif role=="employee":
        if t["user_id"]!=session["user_id"]: abort(403)
    elif role=="it_user":
        if team!="IT": abort(403)
    elif role=="erp_user":
        if team!="ERP": abort(403)
    elif role=="erp_admin":
        if team!="ERP": abort(403)
    else:
        abort(403)
    text=request.form["comment"].strip()
    if not text:
        flash("Reply cannot be empty.", "error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    if text:
        conn=get_db(); conn.execute("INSERT INTO comments(ticket_id,user_id,comment,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],text,now()))
        conn.execute("UPDATE tickets SET updated_at=? WHERE id=?",(now(),ticket_id))
        conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],"Comment added",now()))
        conn.commit(); conn.close()
        ok, err = notify_comment(ticket_id, session.get("role"))
        if not ok: flash("Comment saved, but email notification could not be sent.", "error")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

@app.route("/ticket/<int:ticket_id>/attachment",methods=["POST"])
@login_required
def add_attachment(ticket_id):
    t,_,_,_,_=get_ticket(ticket_id)
    if not t: abort(404)
    role=session["role"]; team=(t["team"] or "IT").upper()
    if role=="admin":
        pass
    elif role=="employee":
        if t["user_id"]!=session["user_id"]: abort(403)
    elif role=="it_user":
        if team!="IT": abort(403)
    elif role=="erp_user":
        if team!="ERP": abort(403)
    elif role=="erp_admin":
        if team!="ERP": abort(403)
    else:
        abort(403)
    file=request.files.get("attachment")
    if file and file.filename and allowed(file.filename):
        safe=secure_filename(file.filename); stored=f"{uuid.uuid4().hex}_{safe}"
        file.save(os.path.join(app.config["UPLOAD_FOLDER"],stored))
        conn=get_db(); conn.execute("INSERT INTO attachments(ticket_id,user_id,original_name,stored_name,created_at) VALUES(?,?,?,?,?)",(ticket_id,session["user_id"],safe,stored,now()))
        conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],"Attachment added",now()))
        conn.commit(); conn.close()
        audit("Attachment added", "ticket", ticket_id, f"File: {safe}")
    else: flash("File type is not allowed. Please upload a supported file type.","error")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

@app.route("/uploads/<path:filename>")
@login_required
def download(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"],filename,as_attachment=True)

@app.route("/ticket/<int:ticket_id>/feedback", methods=["POST"])
@login_required
def submit_feedback(ticket_id):
    t,_,_,_,existing=get_ticket(ticket_id)
    if not t: abort(404)
    if t['user_id'] != session['user_id']: abort(403)
    if t['status'] not in ('Resolved','Closed'):
        flash("Feedback can be submitted only after the ticket is resolved or closed.", "error")
        return redirect(url_for("ticket_detail", ticket_id=ticket_id))
    try: rating=int(request.form.get('rating',''))
    except ValueError: rating=0
    text=request.form.get('feedback','').strip()
    if rating not in (1,2,3,4,5):
        flash("Please select a rating from 1 to 5.", "error")
        return redirect(url_for("ticket_detail", ticket_id=ticket_id))
    if len(text)>1000:
        flash("Feedback is too long. Please keep it within 1000 characters.", "error")
        return redirect(url_for("ticket_detail", ticket_id=ticket_id))
    conn=get_db()
    if existing:
        conn.execute("UPDATE ticket_feedback SET rating=?,feedback=?,created_at=? WHERE id=?",(rating,text,now(),existing['id']))
        action="Employee feedback updated"
    else:
        conn.execute("INSERT INTO ticket_feedback(ticket_id,user_id,rating,feedback,created_at) VALUES(?,?,?,?,?)",(ticket_id,session['user_id'],rating,text,now()))
        action="Employee feedback submitted"
    conn.commit(); conn.close()
    audit(action,"ticket",ticket_id,f"Rating: {rating}/5")
    flash("Thank you. Your feedback has been saved successfully.","success")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

@app.route("/ticket/<int:ticket_id>/reopen", methods=["POST"])
@login_required
def reopen_ticket(ticket_id):
    t,_,_,_,_=get_ticket(ticket_id)
    if not t: abort(404)
    if t['user_id'] != session['user_id']: abort(403)
    if t['status'] not in ('Resolved','Closed'):
        flash("Only resolved or closed tickets can be reopened.","error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    reason=request.form.get('reason','').strip()
    if not reason:
        flash("Please enter a reason for reopening the ticket.","error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    if len(reason)>1000:
        flash("Reopen reason is too long. Please keep it within 1000 characters.","error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    conn=get_db()
    conn.execute("UPDATE tickets SET status='Reopened', due_at=?, escalation_notified_at=NULL, updated_at=? WHERE id=?",(calculate_due_at(t['priority'], now()),now(),ticket_id))
    conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session['user_id'],f"Ticket reopened: {reason}",now()))
    conn.commit(); conn.close()
    audit("Ticket reopened","ticket",ticket_id,f"Reason: {reason}")
    ok,err=notify_reopened(ticket_id,reason)
    if not ok: flash("Ticket reopened, but team email notification could not be sent.","error")
    else: flash("Ticket reopened successfully. The support team has been notified.","success")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))


@app.route("/ticket/<int:ticket_id>/meeting/create", methods=["POST"])
@login_required
def create_ticket_meeting(ticket_id):
    role=session.get("role")
    if role not in ("admin","it_user"): abort(403)
    conn=get_db(); t=conn.execute("SELECT t.*,u.full_name requester,u.email requester_email FROM tickets t JOIN users u ON t.user_id=u.id WHERE t.id=?",(ticket_id,)).fetchone()
    if not t: conn.close(); abort(404)
    if (t["team"] or "IT").upper()!="IT": conn.close(); abort(403)
    provider=request.form.get("provider","zoom").strip().lower()
    title=request.form.get("title","").strip() or t["subject"]
    date_s=request.form.get("meeting_date","").strip(); start=request.form.get("start_time","").strip(); end=request.form.get("end_time","").strip()
    mode=request.form.get("meeting_mode","new").strip(); saved_link_id=request.form.get("saved_link_id","").strip()
    emails=[]
    for e in request.form.getlist("participants"):
        e=e.strip().lower()
        if e and e not in emails: emails.append(e)
    cc=[]
    for e in request.form.getlist("cc"):
        e=e.strip().lower()
        if e and e not in cc: cc.append(e)
    all_emails=list(dict.fromkeys(emails+cc))
    if t["requester_email"] and t["requester_email"].lower() not in all_emails: all_emails.insert(0,t["requester_email"].lower())
    if not date_s or not start or not end or not all_emails:
        conn.close(); flash("Meeting date, start/end time and at least one participant are required.","error"); return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    try:
        start_iso=_iso_local(date_s,start); end_iso=_iso_local(date_s,end)
        if datetime.fromisoformat(end_iso)<=datetime.fromisoformat(start_iso): raise ValueError("End time must be after start time.")
        join_url=""; provider_id=""; raw={}
        if mode=="saved":
            row=conn.execute("SELECT * FROM saved_meeting_links WHERE id=? AND provider=? AND active=1",(saved_link_id,provider)).fetchone()
            if not row: raise RuntimeError("Saved meeting link was not found or is inactive.")
            join_url=row["meeting_link"]; provider_id=row["meeting_id"] or ""
        else:
            settings=meeting_settings().get(provider)
            if not settings or not settings.get("enabled"): raise RuntimeError(f"{provider.title()} integration is not connected. Ask Admin to configure Meeting Integrations first.")
            join_url,provider_id,raw=create_provider_meeting(provider,settings,title,start_iso,end_iso,all_emails)
            if not join_url: raise RuntimeError(f"{provider.title()} did not return a meeting link.")
        participants=", ".join(all_emails)
        cur=conn.execute("INSERT INTO meetings(ticket_id,provider,title,start_at,end_at,join_url,provider_meeting_id,status,created_by,created_at,saved_link_id,participants) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(ticket_id,provider,title,start_iso,end_iso,join_url,provider_id,"Scheduled",session["user_id"],now(),int(saved_link_id) if saved_link_id else None,participants))
        mid=cur.lastrowid
        conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],f"Meeting created ({provider.title()})",now()))
        conn.commit()
        m=conn.execute("SELECT * FROM meetings WHERE id=?",(mid,)).fetchone()
        conn.close()
        ok,err=send_email(all_emails,f"Meeting Invitation - {t['ticket_no']}",meeting_invitation_body(m,t))
        conn=get_db()
        if ok:
            conn.execute("UPDATE meetings SET invitation_sent_at=? WHERE id=?",(now(),mid))
            conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],f"Meeting invitation sent to {len(all_emails)} participant(s)",now()))
        else:
            flash(f"Meeting created, but invitation email failed: {err}","error")
        if request.form.get("close_after")=="1" and ok and t["status"] not in ("Resolved","Closed"):
            conn.execute("UPDATE tickets SET status='Closed',resolved_by_user_id=?,resolved_by_name=?,resolved_at=?,updated_at=? WHERE id=?",(session["user_id"],session.get("full_name"),now(),now(),ticket_id))
            conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],"Ticket closed after meeting invitation was sent",now()))
            threading.Thread(target=lambda tid, name: notify_resolved(tid,name),args=(ticket_id,session.get("full_name")),daemon=True).start()
        conn.commit(); conn.close()
        audit("Meeting created","ticket",ticket_id,f"Platform: {provider} | Participants: {len(all_emails)} | Link: {join_url}")
        if ok: flash(f"{provider.title()} meeting created and invitation sent to {len(all_emails)} participant(s).","success")
    except Exception as e:
        try: conn.close()
        except Exception: pass
        logging.exception("Meeting creation failed")
        flash(f"Meeting could not be created: {e}","error")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

@app.route("/ticket/<int:ticket_id>/meeting/<int:meeting_id>/resend", methods=["POST"])
@login_required
def resend_meeting_invitation(ticket_id,meeting_id):
    if session.get("role") not in ("admin","it_user"): abort(403)
    conn=get_db(); m=conn.execute("SELECT * FROM meetings WHERE id=? AND ticket_id=?",(meeting_id,ticket_id)).fetchone(); t=conn.execute("SELECT t.*,u.email requester_email FROM tickets t JOIN users u ON t.user_id=u.id WHERE t.id=?",(ticket_id,)).fetchone()
    if not m or not t: conn.close(); abort(404)
    emails=[x.strip() for x in (m["participants"] or "").split(",") if x.strip()]
    conn.close(); ok,err=send_email(emails,f"Meeting Invitation - {t['ticket_no']}",meeting_invitation_body(m,t))
    if ok:
        conn=get_db(); conn.execute("UPDATE meetings SET invitation_sent_at=? WHERE id=?",(now(),meeting_id)); conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],"Meeting invitation resent",now())); conn.commit(); conn.close(); flash("Meeting invitation resent successfully.","success")
    else: flash(f"Invitation could not be sent: {err}","error")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

@app.route("/admin/meeting-center")
@login_required
@admin_required
def meeting_center():
    q=request.args.get("q","").strip(); provider=request.args.get("provider","").strip().lower(); status=request.args.get("status","").strip()
    conn=get_db(); where=[]; params=[]
    if q:
        like=f"%{q}%"; where.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR m.participants LIKE ?)"); params += [like,like,like,like]
    if provider in ("zoom","teams","google"): where.append("m.provider=?"); params.append(provider)
    if status: where.append("m.status=?"); params.append(status)
    clause=" WHERE "+" AND ".join(where) if where else ""
    rows=conn.execute(f"SELECT m.*,t.ticket_no,t.subject,u.full_name employee,cu.full_name created_by_name FROM meetings m JOIN tickets t ON t.id=m.ticket_id JOIN users u ON u.id=t.user_id LEFT JOIN users cu ON cu.id=m.created_by{clause} ORDER BY m.id DESC",params).fetchall()
    conn.close(); return render_template("meeting_center.html",meetings=rows,search=q,provider_filter=provider,status_filter=status)

@app.route("/admin/meeting-center/export")
@login_required
@admin_required
def meeting_center_export():
    conn=get_db(); rows=conn.execute("SELECT m.*,t.ticket_no,t.subject,u.full_name employee,cu.full_name created_by_name FROM meetings m JOIN tickets t ON t.id=m.ticket_id JOIN users u ON u.id=t.user_id LEFT JOIN users cu ON cu.id=m.created_by ORDER BY m.id DESC").fetchall(); conn.close()
    out=io.StringIO(); w=csv.writer(out); w.writerow(["Ticket","Employee","Platform","Meeting","Start","End","Status","Participants","Created By","Join Link"])
    for r in rows: w.writerow([r["ticket_no"],r["employee"],r["provider"].title(),r["title"],r["start_at"],r["end_at"],r["status"],r["participants"],r["created_by_name"] or "",r["join_url"]])
    from flask import Response
    return Response("\ufeff"+out.getvalue(),mimetype="text/csv",headers={"Content-Disposition":"attachment; filename=meeting_center_export.csv"})

@app.route("/admin/meeting-settings", methods=["GET","POST"])
@login_required
@admin_required
def meeting_settings_page():
    if request.method=="POST":
        provider=request.form.get("provider","").strip().lower()
        if provider not in ("zoom","teams","google"): abort(400)
        vals={k:request.form.get(k,"").strip() for k in ("client_id","client_secret","account_id","tenant_id","organizer_email","refresh_token")}
        enabled=1 if request.form.get("enabled")=="1" else 0
        conn=get_db(); old=conn.execute("SELECT * FROM meeting_integrations WHERE provider=?",(provider,)).fetchone()
        secret=encrypt_meeting_secret(vals["client_secret"]) if vals["client_secret"] else (old["client_secret"] if old else "")
        refresh=encrypt_meeting_secret(vals["refresh_token"]) if vals["refresh_token"] else (old["refresh_token"] if old else "")
        conn.execute("INSERT INTO meeting_integrations(provider,enabled,client_id,client_secret,account_id,tenant_id,organizer_email,refresh_token,updated_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(provider) DO UPDATE SET enabled=excluded.enabled,client_id=excluded.client_id,client_secret=excluded.client_secret,account_id=excluded.account_id,tenant_id=excluded.tenant_id,organizer_email=excluded.organizer_email,refresh_token=excluded.refresh_token,updated_at=excluded.updated_at",(provider,enabled,vals["client_id"],secret,vals["account_id"],vals["tenant_id"],vals["organizer_email"],refresh,now()))
        conn.commit(); conn.close(); flash(f"{provider.title()} integration settings saved.","success"); return redirect(url_for("meeting_settings_page"))
    conn=get_db(); links=conn.execute("SELECT * FROM saved_meeting_links WHERE active=1 ORDER BY provider,name").fetchall(); contacts=conn.execute("SELECT * FROM meeting_contacts WHERE active=1 ORDER BY name").fetchall(); groups=conn.execute("SELECT g.id,g.name,COUNT(m.contact_id) member_count FROM meeting_groups g LEFT JOIN meeting_group_members m ON m.group_id=g.id WHERE g.active=1 GROUP BY g.id ORDER BY g.name").fetchall(); conn.close()
    return render_template("meeting_settings.html",integrations=meeting_settings(),saved_links=links,contacts=contacts,groups=groups)

@app.route("/admin/meeting-settings/test/<provider>", methods=["POST"])
@login_required
@admin_required
def test_meeting_integration(provider):
    provider=provider.lower()
    try:
        st=meeting_settings().get(provider)
        if not st or not st.get("enabled"): raise RuntimeError("Integration is disabled or not configured.")
        if provider=="zoom":
            import base64 as _b64
            basic=_b64.b64encode(f"{st['client_id']}:{st['client_secret']}".encode()).decode()
            _,tok=_form_post("https://zoom.us/oauth/token", {"grant_type":"account_credentials","account_id":st["account_id"]}, {"Authorization":f"Basic {basic}"})
            if not tok.get("access_token"): raise RuntimeError("Zoom token test failed.")
        elif provider=="google":
            _google_access_token(st)
        elif provider=="teams":
            _teams_token(st)
        else: raise RuntimeError("Unsupported provider.")
        flash(f"{provider.title()} connection test successful.","success")
    except Exception as e:
        flash(f"{provider.title()} connection test failed: {e}","error")
    return redirect(url_for("meeting_settings_page"))

@app.route("/admin/meeting-links", methods=["POST"])
@login_required
@admin_required
def save_meeting_link():
    provider=request.form.get("provider","zoom").lower(); name=request.form.get("name","").strip(); link=request.form.get("meeting_link","").strip(); meeting_id=request.form.get("meeting_id","").strip(); passcode=request.form.get("passcode","").strip()
    if provider not in ("zoom","teams","google") or not name or not link: flash("Provider, name and meeting link are required.","error"); return redirect(url_for("meeting_settings_page"))
    conn=get_db(); conn.execute("INSERT INTO saved_meeting_links(provider,name,meeting_link,meeting_id,passcode,created_by,created_at) VALUES(?,?,?,?,?,?,?)",(provider,name,link,meeting_id,passcode,session["user_id"],now())); conn.commit(); conn.close(); flash("Saved meeting link added.","success"); return redirect(url_for("meeting_settings_page"))

@app.route("/admin/meeting-links/<int:link_id>/delete",methods=["POST"])
@login_required
@admin_required
def delete_meeting_link(link_id):
    conn=get_db(); conn.execute("UPDATE saved_meeting_links SET active=0 WHERE id=?",(link_id,)); conn.commit(); conn.close(); flash("Saved meeting link disabled.","success"); return redirect(url_for("meeting_settings_page"))

@app.route("/admin/meeting-contacts",methods=["POST"])
@login_required
@admin_required
def save_meeting_contact():
    name=request.form.get("name","").strip(); email=request.form.get("email","").strip().lower()
    if not name or "@" not in email: flash("Enter a contact name and valid email.","error"); return redirect(url_for("meeting_settings_page"))
    conn=get_db(); conn.execute("INSERT INTO meeting_contacts(name,email,created_at) VALUES(?,?,?) ON CONFLICT(email) DO UPDATE SET name=excluded.name,active=1",(name,email,now())); conn.commit(); conn.close(); flash("Meeting contact saved.","success"); return redirect(url_for("meeting_settings_page"))

@app.route("/admin/meeting-groups",methods=["POST"])
@login_required
@admin_required
def save_meeting_group():
    name=request.form.get("name","").strip()
    emails=[e.strip().lower() for raw in request.form.getlist("emails") for e in raw.split(",") if e.strip() and "@" in e]
    if not name or not emails:
        flash("Group name and at least one email are required.","error"); return redirect(url_for("meeting_settings_page"))
    conn=get_db(); conn.execute("INSERT INTO meeting_groups(name,created_at) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET active=1",(name,now())); gid=conn.execute("SELECT id FROM meeting_groups WHERE name=?",(name,)).fetchone()["id"]
    for email in emails:
        c=conn.execute("SELECT id FROM meeting_contacts WHERE email=?",(email,)).fetchone()
        if not c:
            conn.execute("INSERT INTO meeting_contacts(name,email,created_at) VALUES(?,?,?)",(email.split('@')[0],email,now())); c=conn.execute("SELECT id FROM meeting_contacts WHERE email=?",(email,)).fetchone()
        conn.execute("INSERT OR IGNORE INTO meeting_group_members(group_id,contact_id) VALUES(?,?)",(gid,c["id"]))
    conn.commit(); conn.close(); flash("Meeting group saved.","success"); return redirect(url_for("meeting_settings_page"))

@app.route("/admin/mail-config", methods=["GET", "POST"])
@login_required
@admin_required
def mail_configuration():
    conn = get_db()
    row = conn.execute("SELECT * FROM mail_settings WHERE id=1").fetchone()
    conn.close()
    cfg = get_mail_config()
    if request.method == "POST":
        action = request.form.get("action", "save")
        if action == "signature":
            signature = request.form.get("signature", "").strip()
            remove_image = request.form.get("remove_signature_image") == "1"
            uploaded = request.files.get("signature_image")
            conn = get_db()
            existing = conn.execute("SELECT * FROM mail_settings WHERE id=1").fetchone()
            if not existing:
                conn.close()
                flash("Please save SMTP configuration first, then save the email signature.", "error")
                return redirect(url_for("mail_configuration"))
            old_image = existing["signature_image"] if "signature_image" in existing.keys() else ""
            image_name = old_image or ""
            if remove_image and old_image:
                old_path = os.path.join(app.config.get("MAIL_SIGNATURE_FOLDER", os.path.join(app.config["UPLOAD_FOLDER"], "mail_signature")), old_image)
                try:
                    if os.path.exists(old_path): os.remove(old_path)
                except Exception: logging.exception("Could not remove old signature image")
                image_name = ""
            if uploaded and uploaded.filename:
                ext = os.path.splitext(uploaded.filename)[1].lower()
                allowed = {".png", ".jpg", ".jpeg"}
                if ext not in allowed:
                    conn.close(); flash("Signature image must be PNG, JPG or JPEG.", "error")
                    return redirect(url_for("mail_configuration"))
                image_name = f"signature_{int(__import__('time').time())}_{secure_filename(uploaded.filename)}"
                folder = app.config.get("MAIL_SIGNATURE_FOLDER", os.path.join(app.config["UPLOAD_FOLDER"], "mail_signature"))
                os.makedirs(folder, exist_ok=True)
                uploaded.save(os.path.join(folder, image_name))
                if old_image and old_image != image_name:
                    old_path = os.path.join(folder, old_image)
                    try:
                        if os.path.exists(old_path): os.remove(old_path)
                    except Exception: logging.exception("Could not remove previous signature image")
            conn.execute("UPDATE mail_settings SET signature=?, signature_image=?, updated_at=? WHERE id=1", (signature, image_name, now()))
            conn.commit(); conn.close()
            audit("Updated email signature", "mail_settings", 1, "Mail signature text/image updated")
            flash("Email signature saved successfully.", "success")
            return redirect(url_for("mail_configuration"))

        if action == "test":
            recipient = request.form.get("test_recipient", "").strip()
            if not recipient:
                flash("Enter a test recipient email address.", "error")
                return redirect(url_for("mail_configuration"))
            ok, err = send_email(recipient, "IT Service Desk - SMTP Test", "This is a test email from the IT Service Desk.\n\nSMTP configuration is working correctly.")
            if ok:
                flash(f"Test email sent successfully to {recipient}.", "success")
            else:
                flash(f"Test email failed: {err}", "error")
            return redirect(url_for("mail_configuration"))

        host = request.form.get("smtp_host", "").strip()
        try:
            port = int(request.form.get("smtp_port", "587").strip())
            if not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            flash("SMTP port must be a number between 1 and 65535.", "error")
            return redirect(url_for("mail_configuration"))
        username = request.form.get("smtp_username", "").strip()
        password = request.form.get("smtp_password", "")
        from_email = request.form.get("from_email", "").strip() or username
        from_name = request.form.get("from_name", "IT Service Desk").strip() or "IT Service Desk"
        security = request.form.get("security", "tls").lower()
        if security not in ("tls", "ssl", "none"):
            security = "tls"
        signature = request.form.get("signature", "").strip()
        existing_signature_image = (row["signature_image"] if row and "signature_image" in row.keys() else "") or ""
        if not host or not username:
            flash("SMTP Host and SMTP Username / Email are required.", "error")
            return redirect(url_for("mail_configuration"))
        # When editing an existing configuration, a blank password keeps the saved password.
        if not password and row and row["smtp_password"]:
            encrypted_password = row["smtp_password"]
        else:
            try:
                encrypted_password = encrypt_mail_secret(password)
            except RuntimeError as e:
                flash(str(e), "error")
                return redirect(url_for("mail_configuration"))
        conn = get_db()
        conn.execute("""INSERT INTO mail_settings
            (id,smtp_host,smtp_port,smtp_username,smtp_password,from_email,from_name,security,signature,signature_image,updated_at)
            VALUES(1,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET smtp_host=excluded.smtp_host,smtp_port=excluded.smtp_port,
            smtp_username=excluded.smtp_username,smtp_password=excluded.smtp_password,from_email=excluded.from_email,
            from_name=excluded.from_name,security=excluded.security,signature=excluded.signature,signature_image=excluded.signature_image,updated_at=excluded.updated_at""",
            (host,port,username,encrypted_password,from_email,from_name,security,signature,existing_signature_image,now()))
        conn.commit(); conn.close()
        audit("Updated SMTP mail configuration", "mail_settings", 1, f"SMTP host: {host}:{port}; security: {security}")
        flash("Mail configuration saved successfully. Use Test Email to verify it.", "success")
        return redirect(url_for("mail_configuration"))
    return render_template("mail_configuration.html", config=cfg, saved=bool(row))


@app.route("/admin")
@login_required
@admin_required
def admin_dashboard():
    run_sla_escalation()
    q=request.args.get("q","").strip(); team=request.args.get("team","").strip().upper(); status=request.args.get("status","").strip(); priority=request.args.get("priority","").strip(); assigned=request.args.get("assigned"," ").strip()
    assigned=request.args.get("assigned","").strip()
    conn=get_db()
    where=[]; params=[]
    if q:
        like=f"%{q}%"; where.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ? OR t.location LIKE ?)"); params += [like,like,like,like,like]
    if team in ("IT","ERP"): where.append("COALESCE(t.team,'IT')=?"); params.append(team)
    if status in ("New","Assigned","In Progress","Pending","Reopened","Resolved","Closed"): where.append("t.status=?"); params.append(status)
    if priority in ("Low","Medium","High","Critical"): where.append("t.priority=?"); params.append(priority)
    if assigned: where.append("t.assigned_to=?"); params.append(assigned)
    clause=" WHERE "+" AND ".join(where) if where else ""
    tickets=conn.execute(f"SELECT t.*,u.full_name,u.department FROM tickets t JOIN users u ON t.user_id=u.id{clause} ORDER BY t.id DESC",params).fetchall()
    tickets=[dict(t, sla_state=sla_state(t)) for t in tickets]
    stats={"total":conn.execute("SELECT COUNT(*) c FROM tickets").fetchone()["c"],
           "daily":conn.execute("SELECT COUNT(*) c FROM tickets WHERE date(created_at)=date('now','localtime')").fetchone()["c"],
           "monthly":conn.execute("SELECT COUNT(*) c FROM tickets WHERE strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime')").fetchone()["c"],
           "new":conn.execute("SELECT COUNT(*) c FROM tickets WHERE status='New'").fetchone()["c"],
           "progress":conn.execute("SELECT COUNT(*) c FROM tickets WHERE status='In Progress'").fetchone()["c"],
           "pending":conn.execute("SELECT COUNT(*) c FROM tickets WHERE status='Pending'").fetchone()["c"],
           "resolved":conn.execute("SELECT COUNT(*) c FROM tickets WHERE status IN ('Resolved','Closed')").fetchone()["c"],
           "breached":conn.execute("SELECT COUNT(*) c FROM tickets WHERE status NOT IN ('Resolved','Closed') AND due_at IS NOT NULL AND datetime(due_at)<datetime('now','localtime')").fetchone()["c"]}
    assignees=conn.execute("SELECT DISTINCT assigned_to FROM tickets WHERE assigned_to IS NOT NULL AND TRIM(assigned_to)<>'' ORDER BY assigned_to").fetchall()
    analytics={
        "team": {r["team"]: r["c"] for r in conn.execute("SELECT CASE WHEN COALESCE(team,'IT')='ERP' THEN 'ERP Team' ELSE 'IT Team' END team, COUNT(*) c FROM tickets GROUP BY CASE WHEN COALESCE(team,'IT')='ERP' THEN 'ERP Team' ELSE 'IT Team' END")},
        "status": {r["status"]: r["c"] for r in conn.execute("SELECT status, COUNT(*) c FROM tickets GROUP BY status")},
        "priority": {r["priority"]: r["c"] for r in conn.execute("SELECT priority, COUNT(*) c FROM tickets GROUP BY priority")},
        "department": conn.execute("SELECT COALESCE(u.department,'-') department, COUNT(*) c FROM tickets t JOIN users u ON t.user_id=u.id GROUP BY COALESCE(u.department,'-') ORDER BY c DESC").fetchall(),
        "technician": conn.execute("SELECT COALESCE(assigned_to,'Not Assigned') assigned_to, COUNT(*) c FROM tickets GROUP BY COALESCE(assigned_to,'Not Assigned') ORDER BY c DESC LIMIT 15").fetchall(),
        "avg_rating": conn.execute("SELECT AVG(rating) x FROM ticket_feedback").fetchone()["x"]
    }
    analytics["avg_rating"] = round(analytics["avg_rating"],2) if analytics["avg_rating"] is not None else None
    # Dashboard trend data for the polished Phase 2 UI.
    trend_rows = {r["day"]: r["c"] for r in conn.execute("SELECT date(created_at) day, COUNT(*) c FROM tickets WHERE date(created_at) >= date('now','localtime','-6 days') GROUP BY date(created_at)").fetchall()}
    trend=[]
    for offset in range(6,-1,-1):
        d=(datetime.now()-timedelta(days=offset)).date()
        trend.append({"label": d.strftime("%d %b"), "day": d.isoformat(), "count": trend_rows.get(d.isoformat(),0)})
    trend_max=max([x["count"] for x in trend] + [1])
    trend_max=max(4, trend_max)
    points=[]
    for i,x in enumerate(trend):
        px=round(i*(700/(len(trend)-1)),1)
        py=round(210-(x["count"]/trend_max)*180,1)
        points.append({"x":px,"y":py})
    trend_points=" ".join(f"{p['x']},{p['y']}" for p in points)
    trend_fill=f"M {points[0]['x']} {points[0]['y']} " + " ".join(f"L {p['x']} {p['y']}" for p in points[1:]) + f" L {points[-1]['x']} 220 L {points[0]['x']} 220 Z"
    total=max(1,stats["total"])
    priority_pct={k:round((analytics["priority"].get(k,0)/total)*100) for k in ["Critical","High","Medium","Low"]}
    conn.close()
    return render_template("admin_dashboard.html",tickets=tickets,stats=stats,analytics=analytics,search=q,team_filter=team,status_filter=status,priority_filter=priority,assigned_filter=assigned,assignees=assignees,trend=trend,trend_max=trend_max,trend_points=trend_points,trend_fill=trend_fill,trend_point_list=points,priority_pct=priority_pct,dashboard_date=datetime.now().strftime("%A, %d %b %Y"),dashboard_time=datetime.now().strftime("%I:%M %p"))


@app.route("/admin/employee-360")
@login_required
@admin_required
def employee_360():
    q = request.args.get("q", "").strip()
    conn = get_db()
    users = conn.execute("""SELECT id, username, full_name, department, designation, email, role, active
                           FROM users WHERE active=1 ORDER BY full_name COLLATE NOCASE""").fetchall()
    selected = None
    if q:
        like = f"%{q}%"
        selected = conn.execute("""SELECT id, username, full_name, department, designation, email, role, active
                                  FROM users WHERE active=1 AND (full_name LIKE ? OR username LIKE ? OR email LIKE ?)
                                  ORDER BY CASE WHEN full_name LIKE ? THEN 0 ELSE 1 END, full_name COLLATE NOCASE LIMIT 1""",
                               (like, like, like, like)).fetchone()
    data = {"tickets": [], "daily_reports": [], "inventory": [], "assets": [], "software": [], "stats": {}}
    if selected:
        uid = selected["id"]; name = selected["full_name"]
        data["tickets"] = conn.execute("""SELECT id, ticket_no, subject, status, priority, category, assigned_to, created_at, updated_at
                                           FROM tickets WHERE user_id=? ORDER BY id DESC""", (uid,)).fetchall()
        data["daily_reports"] = conn.execute("""SELECT report_date, work_summary, tickets_worked, pending_work, issues, next_day_plan
                                                  FROM daily_reports WHERE user_id=? ORDER BY report_date DESC""", (uid,)).fetchall()
        inv_rows = []
        try:
            ic = inventory_conn()
            if ic:
                inv_rows = ic.execute("""SELECT t.*, i.name AS item_name, i.unit
                                       FROM consumable_transactions t
                                       JOIN consumable_items i ON i.id=t.item_id
                                       WHERE lower(trim(t.issued_to))=lower(trim(?))
                                       ORDER BY t.changed_at DESC, t.id DESC""", (name,)).fetchall()
                ic.close()
        except Exception:
            logging.exception("Employee 360 inventory lookup failed")
        data["inventory"] = inv_rows
        # Pull assigned assets/software from the standalone inventory database when available.
        try:
            ic = inventory_conn()
            if ic:
                cols = [r[1] for r in ic.execute("PRAGMA table_info(asset_assignments)").fetchall()]
                if cols:
                    data["assets"] = ic.execute("""SELECT a.entry_id, a.assigned_to, a.department, a.location, a.action, a.changed_at,
                                                        ie.status, df.name AS folder_name
                                                   FROM asset_assignments a
                                                   JOIN inventory_entries ie ON ie.id=a.entry_id
                                                   LEFT JOIN dashboard_folders df ON df.id=ie.folder_id
                                                   WHERE lower(trim(a.assigned_to))=lower(trim(?))
                                                   ORDER BY a.changed_at DESC""", (name,)).fetchall()
                try:
                    data["software"] = ic.execute("""SELECT software_name, version, vendor, quantity, department, asset_reference, status, expiry_date
                                                      FROM it_software WHERE lower(trim(assigned_to))=lower(trim(?))
                                                      ORDER BY software_name COLLATE NOCASE""", (name,)).fetchall()
                except Exception:
                    data["software"] = []
                ic.close()
        except Exception:
            logging.exception("Employee 360 asset lookup failed")
        data["stats"] = {
            "tickets": len(data["tickets"]),
            "open_tickets": sum(1 for r in data["tickets"] if r["status"] not in ("Resolved", "Closed")),
            "daily_reports": len(data["daily_reports"]),
            "inventory": sum((1 if r["txn_type"] in ("Issue", "Stock Out") else 0) for r in data["inventory"]),
            "assets": len(data["assets"]),
            "software": len(data["software"]),
        }
    conn.close()
    return render_template("employee_360.html", users=users, selected=selected, data=data, search=q)


@app.route("/admin/feedback-center")
@login_required
@admin_required
def feedback_center():
    """Professional employee feedback and rating center for Main Admin."""
    q = request.args.get("q", "").strip()
    rating = request.args.get("rating", "").strip()
    team = request.args.get("team", "").strip().upper()
    period = request.args.get("period", "all").strip()
    conditions = []
    params = []
    if q:
        like = f"%{q}%"
        conditions.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ? OR COALESCE(f.feedback,'') LIKE ?)")
        params += [like] * 5
    if rating in ("1", "2", "3", "4", "5"):
        conditions.append("f.rating=?")
        params.append(int(rating))
    if team in ("IT", "ERP"):
        conditions.append("COALESCE(t.team,'IT')=?")
        params.append(team)
    if period == "30":
        conditions.append("datetime(f.created_at) >= datetime('now','localtime','-30 days')")
    elif period == "90":
        conditions.append("datetime(f.created_at) >= datetime('now','localtime','-90 days')")
    where = " WHERE " + " AND ".join(conditions) if conditions else ""
    conn = get_db()
    rows = conn.execute(f"""
        SELECT f.*, t.ticket_no, t.subject, t.priority, t.status, t.team,
               u.full_name AS employee_name, u.department
        FROM ticket_feedback f
        JOIN tickets t ON f.ticket_id=t.id
        JOIN users u ON f.user_id=u.id
        {where}
        ORDER BY datetime(f.created_at) DESC, f.id DESC
    """, params).fetchall()
    total = conn.execute("SELECT COUNT(*) c FROM ticket_feedback").fetchone()["c"]
    avg = conn.execute("SELECT AVG(rating) x FROM ticket_feedback").fetchone()["x"]
    five = conn.execute("SELECT COUNT(*) c FROM ticket_feedback WHERE rating=5").fetchone()["c"]
    low = conn.execute("SELECT COUNT(*) c FROM ticket_feedback WHERE rating IN (1,2)").fetchone()["c"]
    today = conn.execute("SELECT COUNT(*) c FROM ticket_feedback WHERE date(created_at)=date('now','localtime')").fetchone()["c"]
    distribution = {r["rating"]: r["c"] for r in conn.execute("SELECT rating,COUNT(*) c FROM ticket_feedback GROUP BY rating").fetchall()}
    team_rows = conn.execute("""
        SELECT CASE WHEN COALESCE(t.team,'IT')='ERP' THEN 'ERP Team' ELSE 'IT Team' END team,
               COUNT(*) c, ROUND(AVG(f.rating),2) avg_rating
        FROM ticket_feedback f JOIN tickets t ON f.ticket_id=t.id
        GROUP BY CASE WHEN COALESCE(t.team,'IT')='ERP' THEN 'ERP Team' ELSE 'IT Team' END
    """).fetchall()
    conn.close()
    stats = {
        "total": total,
        "avg": round(avg,2) if avg is not None else None,
        "five": five,
        "low": low,
        "today": today,
    }
    return render_template("feedback_center.html", feedback_rows=rows, stats=stats,
                           distribution=distribution, team_rows=team_rows,
                           q=q, rating_filter=rating, team_filter=team, period_filter=period)

@app.route("/admin/sla-center")
@login_required
@admin_required
def sla_center():
    """Professional SLA management center for Main Admin."""
    run_sla_escalation()
    q=request.args.get("q","").strip(); team=request.args.get("team","").strip().upper(); priority=request.args.get("priority","").strip(); state=request.args.get("state","").strip(); assigned=request.args.get("assigned","").strip()
    conditions=[]; params=[]
    if q:
        like=f"%{q}%"; conditions.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ? OR COALESCE(t.assigned_to,'') LIKE ?)"); params += [like]*5
    if team in ('IT','ERP'): conditions.append("COALESCE(t.team,'IT')=?"); params.append(team)
    if priority in ('Low','Medium','High','Critical'): conditions.append("t.priority=?"); params.append(priority)
    if assigned: conditions.append("t.assigned_to=?"); params.append(assigned)
    if state=='breached': conditions += ["t.status NOT IN ('Resolved','Closed')","t.due_at IS NOT NULL","datetime(t.due_at)<datetime('now','localtime')"]
    elif state=='due-soon': conditions += ["t.status NOT IN ('Resolved','Closed')","t.due_at IS NOT NULL","datetime(t.due_at)>=datetime('now','localtime')","datetime(t.due_at)<=datetime('now','localtime','+4 hours')"]
    elif state=='within': conditions += ["t.status NOT IN ('Resolved','Closed')","(t.due_at IS NULL OR datetime(t.due_at)>datetime('now','localtime','+4 hours'))"]
    elif state=='completed': conditions.append("t.status IN ('Resolved','Closed')")
    where=' WHERE '+' AND '.join(conditions) if conditions else ''
    conn=get_db()
    rows=conn.execute(f"SELECT t.*,u.full_name AS employee_name,u.department AS employee_department FROM tickets t JOIN users u ON t.user_id=u.id{where} ORDER BY CASE WHEN t.status NOT IN ('Resolved','Closed') AND t.due_at IS NOT NULL AND datetime(t.due_at)<datetime('now','localtime') THEN 0 WHEN t.status NOT IN ('Resolved','Closed') AND t.due_at IS NOT NULL AND datetime(t.due_at)<=datetime('now','localtime','+4 hours') THEN 1 ELSE 2 END, datetime(COALESCE(t.due_at,'9999-12-31 23:59:59')), t.id DESC",params).fetchall()
    tickets=[]
    now_dt=datetime.now()
    for r in rows:
        item=dict(r)
        item['sla_state']=sla_state(r)
        item['sla_bucket']=item['sla_state']
        item['sla_remaining']=''
        if r['status'] not in ('Resolved','Closed') and r['due_at']:
            try:
                due_dt=datetime.strptime(r['due_at'], '%Y-%m-%d %H:%M:%S')
                delta=due_dt-now_dt
                total_seconds=int(delta.total_seconds())
                if total_seconds < 0:
                    mins=abs(total_seconds)//60
                    item['sla_bucket']='SLA Breached'
                    item['sla_remaining']=f'Overdue by {mins//60}h {mins%60}m'
                elif total_seconds <= 4*3600:
                    mins=total_seconds//60
                    item['sla_bucket']='Due Soon'
                    item['sla_remaining']=f'Due in {mins//60}h {mins%60}m'
                else:
                    item['sla_bucket']='Within SLA'
                    mins=total_seconds//60
                    item['sla_remaining']=f'{mins//60}h {mins%60}m remaining'
            except (ValueError, TypeError):
                item['sla_bucket']='Within SLA'
        elif r['status'] in ('Resolved','Closed'):
            item['sla_bucket']='Completed'
        tickets.append(item)
    stats={
      'total':conn.execute("SELECT COUNT(*) c FROM tickets").fetchone()['c'],
      'breached':conn.execute("SELECT COUNT(*) c FROM tickets WHERE status NOT IN ('Resolved','Closed') AND due_at IS NOT NULL AND datetime(due_at)<datetime('now','localtime')").fetchone()['c'],
      'due_soon':conn.execute("SELECT COUNT(*) c FROM tickets WHERE status NOT IN ('Resolved','Closed') AND due_at IS NOT NULL AND datetime(due_at)>=datetime('now','localtime') AND datetime(due_at)<=datetime('now','localtime','+4 hours')").fetchone()['c'],
      'within':conn.execute("SELECT COUNT(*) c FROM tickets WHERE status NOT IN ('Resolved','Closed') AND (due_at IS NULL OR datetime(due_at)>datetime('now','localtime','+4 hours'))").fetchone()['c'],
      'completed':conn.execute("SELECT COUNT(*) c FROM tickets WHERE status IN ('Resolved','Closed')").fetchone()['c']}
    by_priority=conn.execute("SELECT priority,COUNT(*) c FROM tickets WHERE status NOT IN ('Resolved','Closed') GROUP BY priority ORDER BY CASE priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END").fetchall()
    assignees=conn.execute("SELECT DISTINCT assigned_to FROM tickets WHERE assigned_to IS NOT NULL AND TRIM(assigned_to)<>'' ORDER BY assigned_to").fetchall()
    conn.close()
    return render_template('sla_center.html',tickets=tickets,stats=stats,by_priority=by_priority,q=q,team_filter=team,priority_filter=priority,state_filter=state,assigned_filter=assigned,assignees=assignees)

@app.route("/admin/dashboard-tickets/<filter_name>")
@login_required
@admin_required
def dashboard_tickets(filter_name):
    """Professional filtered ticket list represented by a dashboard statistic card."""
    labels = {
        "total": "Total Tickets", "today": "Today", "month": "This Month",
        "new": "New", "in-progress": "In Progress", "pending": "Pending",
        "resolved-closed": "Resolved / Closed", "sla-breached": "SLA Breached",
    }
    if filter_name not in labels:
        abort(404)
    q=request.args.get("q","").strip(); team=request.args.get("team","").strip().upper()
    priority=request.args.get("priority","").strip(); status=request.args.get("status","").strip()
    assigned=request.args.get("assigned","").strip(); sla_filter=request.args.get("sla","").strip()
    page=max(1, int(request.args.get("page",1) or 1)); per_page=15
    conditions=[]; params=[]
    if filter_name=="today": conditions.append("date(t.created_at)=date('now','localtime')")
    elif filter_name=="month": conditions.append("strftime('%Y-%m',t.created_at)=strftime('%Y-%m','now','localtime')")
    elif filter_name=="new": conditions.append("t.status='New'")
    elif filter_name=="in-progress": conditions.append("t.status='In Progress'")
    elif filter_name=="pending": conditions.append("t.status='Pending'")
    elif filter_name=="resolved-closed": conditions.append("t.status IN ('Resolved','Closed')")
    elif filter_name=="sla-breached": conditions += ["t.status NOT IN ('Resolved','Closed')","t.due_at IS NOT NULL","datetime(t.due_at)<datetime('now','localtime')"]
    if q:
        like=f"%{q}%"; conditions.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ? OR t.location LIKE ?)"); params += [like]*5
    if team in ('IT','ERP'): conditions.append("COALESCE(t.team,'IT')=?"); params.append(team)
    if status in ('New','Assigned','In Progress','Pending','Reopened','Resolved','Closed'): conditions.append("t.status=?"); params.append(status)
    if priority in ('Low','Medium','High','Critical'): conditions.append("t.priority=?"); params.append(priority)
    if assigned: conditions.append("t.assigned_to=?"); params.append(assigned)
    if sla_filter=='breached': conditions += ["t.status NOT IN ('Resolved','Closed')","t.due_at IS NOT NULL","datetime(t.due_at)<datetime('now','localtime')"]
    elif sla_filter=='completed': conditions.append("t.status IN ('Resolved','Closed')")
    elif sla_filter=='within': conditions += ["(t.status IN ('Resolved','Closed') OR t.due_at IS NULL OR datetime(t.due_at)>=datetime('now','localtime'))"]
    where=(" WHERE "+" AND ".join(conditions)) if conditions else ""
    conn=get_db()
    total=conn.execute(f"SELECT COUNT(*) c FROM tickets t JOIN users u ON t.user_id=u.id{where}",params).fetchone()['c']
    pages=max(1,(total+per_page-1)//per_page); page=min(page,pages); offset=(page-1)*per_page
    tickets=conn.execute(f"""SELECT t.*,u.full_name AS employee_name,u.department AS employee_department
        FROM tickets t JOIN users u ON t.user_id=u.id {where} ORDER BY t.id DESC LIMIT ? OFFSET ?""",params+[per_page,offset]).fetchall()
    tickets=[dict(t,sla_state=sla_state(t)) for t in tickets]
    assignees=conn.execute("SELECT DISTINCT assigned_to FROM tickets WHERE assigned_to IS NOT NULL AND TRIM(assigned_to)<>'' ORDER BY assigned_to").fetchall()
    conn.close()
    return render_template("dashboard_tickets.html",filter_title=labels[filter_name],tickets=tickets,total=total,page=page,pages=pages,per_page=per_page,q=q,team_filter=team,status_filter=status,priority_filter=priority,assigned_filter=assigned,sla_filter=sla_filter,assignees=assignees,filter_name=filter_name)

@app.route("/admin/technician/<path:technician_name>")
@login_required
@admin_required
def technician_tickets(technician_name):
    """Professional ticket history for a selected technician."""
    q=request.args.get("q","").strip(); priority=request.args.get("priority","").strip(); status=request.args.get("status","").strip(); team=request.args.get("team","").strip().upper(); sla_filter=request.args.get("sla","").strip()
    page=max(1,int(request.args.get("page",1) or 1)); per_page=15
    conditions=["t.assigned_to=?"]; params=[technician_name]
    if q:
        like=f"%{q}%"; conditions.append("(t.ticket_no LIKE ? OR t.subject LIKE ? OR u.full_name LIKE ? OR u.department LIKE ? OR t.location LIKE ?)"); params += [like]*5
    if team in ('IT','ERP'): conditions.append("COALESCE(t.team,'IT')=?"); params.append(team)
    if status in ('New','Assigned','In Progress','Pending','Reopened','Resolved','Closed'): conditions.append("t.status=?"); params.append(status)
    if priority in ('Low','Medium','High','Critical'): conditions.append("t.priority=?"); params.append(priority)
    if sla_filter=='breached': conditions += ["t.status NOT IN ('Resolved','Closed')","t.due_at IS NOT NULL","datetime(t.due_at)<datetime('now','localtime')"]
    elif sla_filter=='completed': conditions.append("t.status IN ('Resolved','Closed')")
    elif sla_filter=='within': conditions += ["(t.status IN ('Resolved','Closed') OR t.due_at IS NULL OR datetime(t.due_at)>=datetime('now','localtime'))"]
    where=" WHERE "+" AND ".join(conditions)
    conn=get_db()
    total=conn.execute(f"SELECT COUNT(*) c FROM tickets t JOIN users u ON t.user_id=u.id{where}",params).fetchone()['c']
    pages=max(1,(total+per_page-1)//per_page); page=min(page,max(1,pages)); offset=(page-1)*per_page
    tickets=conn.execute(f"""SELECT t.*,u.full_name AS employee_name,u.department AS employee_department
        FROM tickets t JOIN users u ON t.user_id=u.id {where} ORDER BY t.id DESC LIMIT ? OFFSET ?""",params+[per_page,offset]).fetchall()
    tickets=[dict(t,sla_state=sla_state(t)) for t in tickets]
    conn.close()
    return render_template("technician_tickets.html",technician_name=technician_name,tickets=tickets,total=total,page=page,pages=pages,per_page=per_page,q=q,team_filter=team,status_filter=status,priority_filter=priority,sla_filter=sla_filter)

@app.route("/ticket/<int:ticket_id>/assign-to-me", methods=["POST"])
@login_required
def assign_ticket_to_me(ticket_id):
    role=session.get("role")
    if role not in ("it_user","erp_user"): abort(403)
    conn=get_db(); t=conn.execute("SELECT id,ticket_no,team,assigned_to,status FROM tickets WHERE id=?",(ticket_id,)).fetchone()
    if not t: conn.close(); abort(404)
    team=(t["team"] or "IT").upper(); expected="IT" if role=="it_user" else "ERP"
    if team!=expected: conn.close(); abort(403)
    # Completed tickets must remain completed and cannot be self-assigned.
    if t["status"] in ("Resolved", "Closed"):
        conn.close(); flash(f"{t['ticket_no']} is already {t['status']} and cannot be assigned.", "error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    me=session.get("full_name","").strip(); current=now(); new_status="Assigned" if t["status"]=="New" else t["status"]
    conn.execute("UPDATE tickets SET assigned_to=?, status=?, updated_at=?, escalation_notified_at=NULL WHERE id=?",(me,new_status,current,ticket_id))
    conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],f"Self-assigned to {me}",current))
    conn.commit(); conn.close(); audit("Ticket self-assigned","ticket",ticket_id,f"Ticket: {t['ticket_no']} | Assigned To: {me}")
    ok,err=notify_assignment(ticket_id,me)
    if not ok: flash("Ticket assigned to you, but the assignment email could not be sent.","error")
    else: flash(f"{t['ticket_no']} is now assigned to you.","success")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

@app.route("/ticket/<int:ticket_id>/transfer", methods=["POST"])
@login_required
def transfer_ticket(ticket_id):
    role=session.get("role")
    # IT users can transfer IT tickets to another IT user or Main Admin.
    # ERP users retain their existing self-assignment workflow and cannot use this IT transfer action.
    if role != "it_user": abort(403)
    target=request.form.get("assigned_to","").strip()
    conn=get_db()
    t=conn.execute("SELECT id,ticket_no,team,assigned_to,status FROM tickets WHERE id=?",(ticket_id,)).fetchone()
    if not t: conn.close(); abort(404)
    if (t["team"] or "IT").upper() != "IT": conn.close(); abort(403)
    if t["status"] in ("Resolved", "Closed"):
        conn.close(); flash(f"{t['ticket_no']} is already {t['status']} and cannot be transferred.","error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    if not target:
        conn.close(); flash("Please select an IT User or Main Admin.","error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    target_row=conn.execute("""SELECT id,full_name,role FROM users
        WHERE active=1 AND full_name=? AND ((role='admin') OR (role='it_user' AND LOWER(TRIM(department))='it'))
    """,(target,)).fetchone()
    if not target_row:
        conn.close(); flash("Please select an active IT User or Main Admin.","error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    if target == (t["assigned_to"] or ""):
        conn.close(); flash(f"{t['ticket_no']} is already assigned to {target}.","error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    previous=t["assigned_to"] or "Not Assigned"
    current=now()
    conn.execute("UPDATE tickets SET assigned_to=?, updated_at=?, escalation_notified_at=NULL WHERE id=?",(target,current,ticket_id))
    conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],f"Ticket transferred from {previous} to {target}",current))
    conn.commit(); conn.close()
    audit("Ticket transferred","ticket",ticket_id,f"Ticket: {t['ticket_no']} | From: {previous} | To: {target}")
    ok,err=notify_assignment(ticket_id,target)
    if not ok: flash(f"Ticket transferred to {target}, but the assignment email could not be sent.","error")
    else: flash(f"{t['ticket_no']} transferred successfully to {target}.","success")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

@app.route("/ticket/<int:ticket_id>/update",methods=["POST"])
@login_required
def update_ticket(ticket_id):
    role=session.get("role")
    if role not in ("admin","it_user","erp_admin","erp_user") and not session.get("is_department_head"): abort(403)
    status=request.form.get("status","").strip(); assigned=request.form.get("assigned_to","").strip()
    allowed_statuses=("New","Assigned","In Progress","Pending","Reopened","Resolved","Closed")
    if status not in allowed_statuses:
        flash("Invalid ticket status selected.", "error")
        return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    conn=get_db(); old=conn.execute("SELECT status,assigned_to,team FROM tickets WHERE id=?",(ticket_id,)).fetchone()
    if not old:
        conn.close(); abort(404)
    team=(old["team"] or "IT").upper()
    if role=="it_user" and team!="IT":
        conn.close(); abort(403)
    if role=="erp_user" and team!="ERP":
        conn.close(); abort(403)
    if role=="erp_admin" and team!="ERP":
        conn.close(); abort(403)
    if session.get("is_department_head") and role!="admin":
        requester=conn.execute("SELECT department FROM tickets t JOIN users u ON t.user_id=u.id WHERE t.id=?",(ticket_id,)).fetchone()
        if not requester or str(requester["department"] or "").strip().lower()!=str(session.get("department") or "").strip().lower():
            conn.close(); abort(403)
        assigned=old["assigned_to"] or ""
    if role in ("it_user","erp_user"):
        # Team users may self-assign any ticket in their own team.
        assigned=assigned or old["assigned_to"] or session.get("full_name","")
    if assigned:
        if team=="ERP":
            technician=conn.execute("SELECT full_name FROM users WHERE active=1 AND role IN ('erp_admin','erp_user') AND LOWER(TRIM(department))='erp' AND full_name=?",(assigned,)).fetchone()
        else:
            technician=conn.execute("SELECT full_name FROM users WHERE active=1 AND role IN ('admin','it_user') AND LOWER(TRIM(department))='it' AND full_name=?",(assigned,)).fetchone()
        if not technician:
            conn.close(); flash(f"Please select an active {'ERP Team' if team=='ERP' else 'IT Team'} user from the Assigned To list.","error")
            return redirect(url_for("ticket_detail",ticket_id=ticket_id))
    current_time=now()
    if status == "Resolved" and old["status"] != "Resolved":
        conn.execute("UPDATE tickets SET status=?,assigned_to=?,updated_at=?,escalation_notified_at=NULL,resolved_by_user_id=?,resolved_by_name=?,resolved_at=? WHERE id=?",(status,assigned,current_time,None if not session.get("user_id") else session.get("user_id"),session.get("full_name") or assigned or "IT Support Team",current_time,ticket_id))
    elif status == "Reopened" and old["status"] != "Reopened":
        conn.execute("UPDATE tickets SET status=?,assigned_to=?,updated_at=?,escalation_notified_at=NULL WHERE id=?",(status,assigned,current_time,ticket_id))
    else:
        conn.execute("UPDATE tickets SET status=?,assigned_to=?,updated_at=?,escalation_notified_at=NULL WHERE id=?",(status,assigned,current_time,ticket_id))
    actions=[]
    if old["status"]!=status: actions.append(f"Status changed to {status}")
    if old["assigned_to"]!=assigned: actions.append(f"Assigned to {assigned or 'Unassigned'}")
    for a in actions: conn.execute("INSERT INTO ticket_history(ticket_id,user_id,action,created_at) VALUES(?,?,?,?)",(ticket_id,session["user_id"],a,now()))
    conn.commit(); conn.close()
    for a in actions: audit(a, "ticket", ticket_id, f"Ticket: {ticket_id}")
    if old["assigned_to"]!=assigned and assigned:
        ok,err=notify_assignment(ticket_id,assigned)
        if not ok: flash("Ticket updated, but assignment email could not be sent.","error")
    if old["status"]!=status and status=="Resolved":
        ok,err=notify_resolved(ticket_id, session.get("full_name"))
        if not ok: flash("Ticket resolved, but employee email could not be sent.","error")
    return redirect(url_for("ticket_detail",ticket_id=ticket_id))

@app.route("/admin/departments", methods=["GET","POST"])
@login_required
@admin_required
def department_management():
    conn=get_db()
    if request.method=="POST":
        name=request.form.get("name","").strip()
        head_id=request.form.get("head_user_id","").strip()
        if not name:
            flash("Department name is required.","error"); conn.close(); return redirect(url_for("department_management"))
        try:
            conn.execute("INSERT INTO departments(name,created_at) VALUES(?,?)",(name,now()))
            conn.commit(); audit("Department created","department",None,f"Department: {name}"); flash(f"Department {name} created successfully.","success")
        except sqlite3.IntegrityError:
            flash("Department already exists.","error")
        conn.close(); return redirect(url_for("department_management"))
    departments=conn.execute("SELECT d.*,u.full_name AS head_name,u.username AS head_username FROM departments d LEFT JOIN users u ON d.head_user_id=u.id ORDER BY d.name").fetchall()
    users=conn.execute("SELECT id,username,full_name,department,role FROM users WHERE active=1 AND role<>'admin' ORDER BY department,full_name").fetchall()
    conn.close(); return render_template("department_management.html",departments=departments,users=users)

@app.route("/admin/departments/<int:department_id>/head", methods=["POST"])
@login_required
@admin_required
def assign_department_head(department_id):
    head_id=request.form.get("head_user_id","").strip()
    conn=get_db(); dept=conn.execute("SELECT * FROM departments WHERE id=?",(department_id,)).fetchone()
    if not dept: conn.close(); abort(404)
    if head_id:
        user=conn.execute("SELECT * FROM users WHERE id=? AND active=1",(head_id,)).fetchone()
        if not user or str(user["department"]).strip().lower()!=str(dept["name"]).strip().lower() or user["role"]=="admin":
            conn.close(); flash("Department Head must be an active user from the same department.","error"); return redirect(url_for("department_management"))
        old_head=dept["head_user_id"]
        if old_head and old_head != user["id"]:
            conn.execute("UPDATE users SET is_department_head=0 WHERE id=?",(old_head,))
        # A user can be Head/Manager of only one department.
        conn.execute("UPDATE departments SET head_user_id=NULL WHERE head_user_id=? AND id<>?",(user["id"],department_id))
        conn.execute("UPDATE users SET is_department_head=0 WHERE id=?",(user["id"],))
        conn.execute("UPDATE departments SET head_user_id=? WHERE id=?",(user["id"],department_id))
        conn.execute("UPDATE users SET is_department_head=1 WHERE id=?",(user["id"],))
        conn.commit(); audit("Department Head assigned","department",department_id,f"Department: {dept['name']} | Head ID: {user['username']}"); flash(f"{user['full_name']} assigned as Head/Manager for {dept['name']}.","success")
    else:
        old=dept["head_user_id"]; conn.execute("UPDATE departments SET head_user_id=NULL WHERE id=?",(department_id,));
        if old: conn.execute("UPDATE users SET is_department_head=0 WHERE id=?",(old,))
        conn.commit(); audit("Department Head removed","department",department_id,f"Department: {dept['name']}"); flash("Department Head removed.","success")
    conn.close(); return redirect(url_for("department_management"))

@app.route("/admin/users")
@login_required
@admin_required
def user_management():
    q = request.args.get("q", "").strip()
    conn = get_db()
    if q:
        like = f"%{q}%"
        users = conn.execute("""
            SELECT id, username, full_name, department, designation, role, email, created_at, active, removed_at
            FROM users
            WHERE active=1
              AND (full_name LIKE ? OR username LIKE ? OR department LIKE ? OR designation LIKE ? OR email LIKE ? OR role LIKE ?)
            ORDER BY department, full_name
        """, (like, like, like, like, like, like)).fetchall()
    else:
        users = conn.execute("""
            SELECT id, username, full_name, department, designation, role, email, created_at, active, removed_at
            FROM users
            WHERE active=1
            ORDER BY department, full_name
        """).fetchall()
    departments=conn.execute("SELECT name FROM departments ORDER BY name").fetchall()
    conn.close()
    return render_template("user_management.html", users=users, search=q, departments=departments)

@app.route("/admin/users/new", methods=["GET", "POST"])
@login_required
@admin_required
def create_user():
    if request.method == "POST":
        username = request.form["username"].strip()
        full_name = request.form["full_name"].strip()
        department = request.form["department"].strip()
        email = request.form.get("email","").strip()
        designation = request.form.get("designation","").strip()
        role = request.form["role"].strip()
        password = request.form["password"]
        if not username or not full_name or not department or not password:
            flash("Username, name, department and password are required.", "error")
            return render_template("create_user.html")
        if role not in ("admin", "it_user", "erp_admin", "erp_user", "employee"):
            role = "employee"
        if role in ("erp_admin","erp_user"):
            department = "ERP"
        if len(password) < 6:
            flash("Password must be at least 6 characters.", "error")
            return render_template("create_user.html")
        conn = get_db()
        try:
            conn.execute("INSERT INTO users(username,full_name,department,designation,role,password_hash,created_at,active,email) VALUES(?,?,?,?,?,?,?,1,?)",
                         (username, full_name, department, designation, role, generate_password_hash(password), now(), email))
            conn.commit()
            audit("User created", "user", conn.execute("SELECT id FROM users WHERE username=?",(username,)).fetchone()["id"], f"Username: {username} | Role: {role}")
            flash(f"User {username} created successfully.", "success")
            return redirect(url_for("user_management"))
        except sqlite3.IntegrityError:
            flash("Username already exists. Please use another username.", "error")
        finally:
            conn.close()
    conn=get_db(); departments=conn.execute("SELECT name FROM departments ORDER BY name").fetchall(); conn.close()
    return render_template("create_user.html", departments=departments)

@app.route("/admin/users/<int:user_id>/edit", methods=["GET","POST"])
@login_required
@admin_required
def edit_user(user_id):
    conn=get_db(); user=conn.execute("SELECT * FROM users WHERE id=?",(user_id,)).fetchone()
    if not user:
        conn.close(); flash("User not found.","error"); return redirect(url_for("user_management"))
    if request.method=="POST":
        username=request.form["username"].strip(); full_name=request.form["full_name"].strip()
        department=request.form["department"].strip(); email=request.form.get("email","").strip()
        designation=request.form.get("designation","").strip()
        role=request.form["role"].strip(); new_password=request.form.get("password","").strip()
        if role not in ("admin","it_user","erp_admin","erp_user","employee"): role="employee"
        if role in ("erp_admin","erp_user"): department="ERP"
        if not username or not full_name or not department:
            flash("Username, full name and department are required.","error")
            conn.close(); return render_template("edit_user.html",user=user)
        if new_password and len(new_password)<6:
            flash("Password must be at least 6 characters.","error")
            conn.close(); return render_template("edit_user.html",user=user)
        if user_id==session.get("user_id") and role!="admin":
            flash("You cannot change your own role from Main Admin.","error")
            conn.close(); return render_template("edit_user.html",user=user)
        try:
            if new_password:
                conn.execute("UPDATE users SET username=?,full_name=?,department=?,designation=?,email=?,role=?,password_hash=? WHERE id=?",(username,full_name,department,designation,email or None,role,generate_password_hash(new_password),user_id))
            else:
                conn.execute("UPDATE users SET username=?,full_name=?,department=?,designation=?,email=?,role=? WHERE id=?",(username,full_name,department,designation,email or None,role,user_id))
            conn.commit(); audit("User updated", "user", user_id, f"Username: {username} | Role: {role} | Department: {department}"); flash(f"User {username} updated successfully.","success")
            return redirect(url_for("user_management"))
        except sqlite3.IntegrityError:
            flash("Username already exists. Please use another username.","error")
        finally:
            conn.close()
    else:
        conn.close()
    conn=get_db(); departments=conn.execute("SELECT name FROM departments ORDER BY name").fetchall(); conn.close()
    return render_template("edit_user.html",user=user,departments=departments)

@app.route("/admin/users/<int:user_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_user(user_id):
    if user_id == session.get("user_id"):
        flash("You cannot deactivate your own account.", "error")
        return redirect(url_for("user_management"))
    conn = get_db()
    row = conn.execute("SELECT active FROM users WHERE id=?", (user_id,)).fetchone()
    if row:
        new_active=0 if row["active"] else 1
        conn.execute("UPDATE users SET active=? WHERE id=?", (new_active, user_id))
        conn.commit(); audit("User activated" if new_active else "User deactivated", "user", user_id, "Account status changed")
    conn.close()
    return redirect(url_for("user_management"))

@app.route("/admin/users/<int:user_id>/email", methods=["POST"])
@login_required
@admin_required
def update_user_email(user_id):
    email=request.form.get("email","").strip()
    conn=get_db(); conn.execute("UPDATE users SET email=? WHERE id=?",(email or None,user_id)); conn.commit(); conn.close()
    audit("User email updated", "user", user_id, email or "Email cleared")
    flash("User email updated successfully.","success")
    return redirect(url_for("user_management"))

@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_user(user_id):
    if user_id == session.get("user_id"):
        flash("You cannot remove your own account.", "error")
        return redirect(url_for("user_management"))
    conn = get_db()
    row = conn.execute("SELECT id, role FROM users WHERE id=?", (user_id,)).fetchone()
    if not row:
        conn.close(); flash("User not found.", "error"); return redirect(url_for("user_management"))
    if row["role"] == "admin":
        count = conn.execute("SELECT COUNT(*) AS c FROM users WHERE role='admin' AND active=1").fetchone()["c"]
        if count <= 1:
            conn.close(); flash("You cannot remove the last active admin.", "error"); return redirect(url_for("user_management"))
    conn.execute("UPDATE users SET active=0, removed_at=datetime('now') WHERE id=?", (user_id,))
    conn.commit(); conn.close(); audit("User removed", "user", user_id, "User moved to Removed Users")
    flash("User removed and moved to Removed Users. Existing tickets, comments, reports and history are preserved.", "success")
    return redirect(url_for("user_management"))

@app.route("/admin/users/<int:user_id>/password", methods=["POST"])
@login_required
@admin_required
def reset_user_password(user_id):
    new_password = request.form.get("new_password", "").strip()
    if not new_password:
        flash("Password cannot be empty.", "error"); return redirect(url_for("user_management"))
    if len(new_password) < 6:
        flash("Password must be at least 6 characters.", "error"); return redirect(url_for("user_management"))
    conn = get_db()
    row = conn.execute("SELECT id, role FROM users WHERE id=? AND active=1", (user_id,)).fetchone()
    if not row:
        conn.close(); flash("Active user not found.", "error"); return redirect(url_for("user_management"))
    conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), user_id))
    conn.commit(); conn.close()
    flash("Password reset successfully.", "success")
    return redirect(url_for("user_management"))

@app.route("/admin/users/removed")
@login_required
@admin_required
def removed_users():
    q = request.args.get("q", "").strip()
    conn = get_db()
    if q:
        like = f"%{q}%"
        users = conn.execute("""
            SELECT id, username, full_name, department, designation, role, email, created_at, removed_at
            FROM users
            WHERE active=0 AND removed_at IS NOT NULL
              AND (full_name LIKE ? OR username LIKE ? OR department LIKE ? OR designation LIKE ? OR email LIKE ? OR role LIKE ?)
            ORDER BY removed_at DESC
        """, (like, like, like, like, like, like)).fetchall()
    else:
        users = conn.execute("""
            SELECT id, username, full_name, department, designation, role, email, created_at, removed_at
            FROM users WHERE active=0 AND removed_at IS NOT NULL ORDER BY removed_at DESC
        """).fetchall()
    conn.close()
    return render_template("removed_users.html", users=users, search=q)

@app.route("/admin/users/<int:user_id>/restore", methods=["POST"])
@login_required
@admin_required
def restore_user(user_id):
    conn = get_db()
    row = conn.execute("SELECT id, username FROM users WHERE id=? AND active=0", (user_id,)).fetchone()
    if not row:
        conn.close(); flash("Removed user not found.", "error"); return redirect(url_for("removed_users"))
    conn.execute("UPDATE users SET active=1, removed_at=NULL WHERE id=?", (user_id,))
    conn.commit(); conn.close(); audit("User restored", "user", user_id, f"Username: {row['username']}")
    flash(f"User {row['username']} restored successfully.", "success")
    return redirect(url_for("removed_users"))

@app.route("/admin/login-security")
@login_required
@admin_required
def login_security_view():
    conn=get_db()
    rows=conn.execute("""SELECT u.id,u.username,u.full_name,u.department,u.role,u.active,
                               COALESCE(ls.failed_attempts,0) AS failed_attempts,ls.locked_until,ls.last_failed_at
                        FROM users u LEFT JOIN login_security ls ON ls.username=u.username
                        ORDER BY u.full_name COLLATE NOCASE""").fetchall()
    conn.close()
    now_dt=datetime.now()
    active_locked=[]
    for r in rows:
        locked=False
        if r["active"] and r["locked_until"]:
            try: locked=now_dt < datetime.strptime(r["locked_until"], "%Y-%m-%d %H:%M:%S")
            except ValueError: locked=False
        active_locked.append(dict(r, locked=locked))
    return render_template("login_security.html", users=active_locked, max_attempts=MAX_LOGIN_ATTEMPTS, lock_minutes=LOGIN_LOCK_MINUTES)

@app.route("/admin/login-security/unlock/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def unlock_login_user(user_id):
    conn=get_db()
    user=conn.execute("SELECT id,username,full_name,active FROM users WHERE id=?",(user_id,)).fetchone()
    if not user:
        conn.close(); flash("User not found.","error"); return redirect(url_for("login_security_view"))
    conn.execute("DELETE FROM login_security WHERE username=?",(user["username"],))
    conn.commit(); conn.close()
    audit("Login lock reset by admin", "user", user_id, f"Username: {user['username']}")
    flash(f"Login security reset for {user['full_name']}.","success")
    return redirect(url_for("login_security_view"))

@app.route("/admin/audit-log")
@login_required
@admin_required
def audit_log_view():
    q=request.args.get("q","").strip()
    conn=get_db()
    if q:
        like=f"%{q}%"
        rows=conn.execute("""SELECT a.*,u.full_name,u.username FROM audit_log a LEFT JOIN users u ON a.user_id=u.id
            WHERE a.action LIKE ? OR a.details LIKE ? OR a.entity_type LIKE ? OR u.full_name LIKE ? OR u.username LIKE ?
            ORDER BY a.id DESC LIMIT 500""",(like,like,like,like,like)).fetchall()
    else:
        rows=conn.execute("SELECT a.*,u.full_name,u.username FROM audit_log a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.id DESC LIMIT 500").fetchall()
    conn.close()
    return render_template("audit_log.html",logs=rows,search=q)

def build_monthly_report(report_month):
    year, month = map(int, report_month.split("-"))
    last_day = calendar.monthrange(year, month)[1]
    data=build_report_data(report_month+"-01", f"{report_month}-{last_day:02d}")
    return report_text("MONTHLY TICKET REPORT",report_month,data)


@app.route("/admin/backups")
@login_required
@admin_required
def backup_management():
    os.makedirs(BACKUP_FOLDER, exist_ok=True)
    files = []
    for path in glob.glob(os.path.join(BACKUP_FOLDER, "ticketing_backup_*.db")):
        try:
            stat = os.stat(path)
            files.append({"name": os.path.basename(path), "size_mb": round(stat.st_size / (1024*1024), 2), "created": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")})
        except OSError:
            continue
    files.sort(key=lambda x: x["created"], reverse=True)
    return render_template("backups.html", backups=files, retention=BACKUP_RETENTION_DAYS)

@app.route("/admin/backups/create", methods=["POST"])
@login_required
@admin_required
def create_manual_backup():
    try:
        path = create_database_backup("manual")
        cleanup_old_backups()
        audit("Database backup created", "system", None, f"Manual backup: {os.path.basename(path)}")
        flash("Database backup created successfully.", "success")
    except Exception:
        logging.exception("Manual database backup failed")
        flash("Database backup could not be created. Please check the system log.", "error")
    return redirect(url_for("backup_management"))

def get_backup_path(filename):
    """Return a safe path only for an existing backup file in BACKUP_FOLDER."""
    safe_name = secure_filename(filename or "")
    if safe_name != filename or not safe_name.startswith("ticketing_backup_") or not safe_name.endswith(".db"):
        raise ValueError("Invalid backup file.")
    base = os.path.abspath(BACKUP_FOLDER)
    path = os.path.abspath(os.path.join(base, safe_name))
    if os.path.dirname(path) != base or not os.path.isfile(path):
        raise FileNotFoundError("Backup file not found.")
    return path

def verify_backup_file(path):
    """Verify SQLite integrity and required ticketing tables without modifying the backup."""
    required_tables = {"users", "tickets", "comments", "attachments", "ticket_history", "audit_log", "ticket_feedback"}
    conn = sqlite3.connect(path)
    try:
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        tables = {r[0] for r in rows}
        missing = sorted(required_tables - tables)
        if integrity.lower() != "ok":
            return {"ok": False, "message": f"SQLite integrity check failed: {integrity}", "users": 0, "tickets": 0, "missing": missing}
        counts = {}
        for table in ("users", "tickets"):
            counts[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] if table in tables else 0
        if missing:
            return {"ok": False, "message": "Backup is missing required tables: " + ", ".join(missing), "users": counts["users"], "tickets": counts["tickets"], "missing": missing}
        return {"ok": True, "message": "Backup passed SQLite integrity and required-table checks.", "users": counts["users"], "tickets": counts["tickets"], "missing": []}
    finally:
        conn.close()

@app.route("/admin/backups/verify/<path:filename>")
@login_required
@admin_required
def verify_backup(filename):
    try:
        path = get_backup_path(filename)
        result = verify_backup_file(path)
        if result["ok"]:
            flash(f"Backup verified successfully. Users: {result['users']}, Tickets: {result['tickets']}.", "success")
        else:
            flash("Backup verification failed: " + result["message"], "error")
        audit("Database backup verified", "system", None, f"Backup: {os.path.basename(path)} | Result: {result['message']}")
    except Exception as exc:
        logging.exception("Backup verification failed")
        flash(f"Backup verification could not be completed: {exc}", "error")
    return redirect(url_for("backup_management"))

@app.route("/admin/backups/restore", methods=["POST"])
@login_required
@admin_required
def restore_backup():
    filename = request.form.get("filename", "")
    confirmation = request.form.get("confirmation", "").strip()
    if confirmation != "RESTORE":
        flash("Restore cancelled. Type RESTORE exactly to confirm.", "error")
        return redirect(url_for("backup_management"))
    temp_path = None
    try:
        source_path = get_backup_path(filename)
        result = verify_backup_file(source_path)
        if not result["ok"]:
            raise ValueError("Selected backup failed verification and cannot be restored.")

        # Protect the current database before changing anything.
        pre_restore = create_database_backup("pre_restore")
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        temp_path = os.path.join(BACKUP_FOLDER, f"ticketing_restore_{stamp}.db")
        source = sqlite3.connect(source_path)
        destination = sqlite3.connect(temp_path)
        try:
            source.backup(destination)
        finally:
            destination.close()
            source.close()
        verify_restored = verify_backup_file(temp_path)
        if not verify_restored["ok"]:
            raise ValueError("Temporary restored database failed verification.")

        os.replace(temp_path, DB)
        temp_path = None
        cleanup_old_backups()
        logging.info("Database restored from %s; pre-restore backup: %s", source_path, pre_restore)
        # Audit is recorded in the restored database only if the restored schema accepts it.
        try:
            audit("Database restored", "system", None, f"Restored from: {os.path.basename(source_path)} | Pre-restore backup: {os.path.basename(pre_restore)}")
        except Exception:
            logging.exception("Could not write restore audit entry after database replacement")
        flash(f"Database restored successfully from {os.path.basename(source_path)}. A pre-restore backup was created.", "success")
    except Exception as exc:
        logging.exception("Database restore failed")
        if temp_path and os.path.exists(temp_path):
            try: os.remove(temp_path)
            except OSError: pass
        flash(f"Database restore failed: {exc}", "error")
    return redirect(url_for("backup_management"))

@app.route("/admin/reports-analytics")
@login_required
@admin_required
def reports_analytics():
    """Professional reporting dashboard with date-range analytics."""
    today = date.today()
    default_start = today - timedelta(days=29)
    start_date = request.args.get("start", default_start.isoformat()).strip()
    end_date = request.args.get("end", today.isoformat()).strip()
    try:
        start_obj = datetime.strptime(start_date, "%Y-%m-%d").date()
    except ValueError:
        start_obj = default_start
        start_date = start_obj.isoformat()
    try:
        end_obj = datetime.strptime(end_date, "%Y-%m-%d").date()
    except ValueError:
        end_obj = today
        end_date = end_obj.isoformat()
    if start_obj > end_obj:
        start_obj, end_obj = end_obj, start_obj
        start_date, end_date = start_obj.isoformat(), end_obj.isoformat()

    data = build_report_data(start_date, end_date)
    trend = []
    conn = get_db()
    trend_rows = conn.execute("""
        SELECT date(created_at) AS report_date, COUNT(*) AS c
        FROM tickets
        WHERE date(created_at) BETWEEN date(?) AND date(?)
        GROUP BY date(created_at)
        ORDER BY date(created_at)
    """, (start_date, end_date)).fetchall()
    trend_map = {r["report_date"]: r["c"] for r in trend_rows}
    cur = start_obj
    while cur <= end_obj:
        ds = cur.isoformat()
        trend.append({"date": ds, "c": trend_map.get(ds, 0)})
        cur += timedelta(days=1)

    now = datetime.now()
    due_soon_limit = now + timedelta(hours=4)
    active_rows = conn.execute("""
        SELECT due_at, status FROM tickets
        WHERE status NOT IN ('Resolved','Closed') AND due_at IS NOT NULL
    """).fetchall()
    active_breached = 0
    active_due_soon = 0
    active_within = 0
    for r in active_rows:
        try:
            due = datetime.strptime(r["due_at"], "%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError):
            active_within += 1
            continue
        if due < now:
            active_breached += 1
        elif due <= due_soon_limit:
            active_due_soon += 1
        else:
            active_within += 1
    open_count = conn.execute("SELECT COUNT(*) c FROM tickets WHERE status NOT IN ('Resolved','Closed')").fetchone()["c"]
    conn.close()
    max_daily = max([x["c"] for x in trend] or [1])
    return render_template(
        "reports_analytics.html",
        data=data,
        trend=trend,
        max_daily=max_daily,
        open_count=open_count,
        active_breached=active_breached,
        active_due_soon=active_due_soon,
        active_within=active_within,
        start_date=start_date,
        end_date=end_date,
    )

@app.route("/admin/reports-analytics/export-csv")
@login_required
@admin_required
def export_reports_csv():
    """Export ticket/report data for the selected date range as CSV."""
    today = date.today()
    start_date = request.args.get("start", (today - timedelta(days=29)).isoformat()).strip()
    end_date = request.args.get("end", today.isoformat()).strip()
    try:
        datetime.strptime(start_date, "%Y-%m-%d")
    except ValueError:
        start_date = (today - timedelta(days=29)).isoformat()
    try:
        datetime.strptime(end_date, "%Y-%m-%d")
    except ValueError:
        end_date = today.isoformat()
    if start_date > end_date:
        start_date, end_date = end_date, start_date
    data = build_report_data(start_date, end_date)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Ticket No","Employee","Department","Team","Subject","Priority","Status","SLA State","SLA Due","Assigned To","Created At","Updated At"])
    for r in data["rows"]:
        writer.writerow([
            r["ticket_no"], r["employee_name"], r["department"],
            "ERP Team" if r["team"] == "ERP" else "IT Team",
            r["subject"], r["priority"], r["status"], sla_state(r),
            r["due_at"] or "-", r["assigned_to"] or "Not Assigned",
            r["created_at"], r["updated_at"]
        ])
    filename = f"IT_Reports_{start_date}_to_{end_date}.csv"
    return app.response_class(
        output.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@app.route("/admin/reports/monthly")
@login_required
@admin_required
def monthly_report():
    report_month=request.args.get("month") or date.today().strftime("%Y-%m")
    try: datetime.strptime(report_month,"%Y-%m")
    except ValueError: report_month=date.today().strftime("%Y-%m")
    return render_template("monthly_report.html",report_month=report_month,report_text=build_monthly_report(report_month))

@app.route("/admin/reports/monthly/download")
@login_required
@admin_required
def download_monthly_report():
    report_month=request.args.get("month") or date.today().strftime("%Y-%m")
    try: datetime.strptime(report_month,"%Y-%m")
    except ValueError: report_month=date.today().strftime("%Y-%m")
    return app.response_class(build_monthly_report(report_month),mimetype="text/plain; charset=utf-8",headers={"Content-Disposition":f'attachment; filename="IT_Monthly_Report_{report_month}.txt"'})

@app.route("/it/daily-report", methods=["GET","POST"])
@login_required
def it_daily_report():
    if session.get("role")!="it_user": abort(403)
    report_date=request.form.get("report_date") or request.args.get("date") or date.today().isoformat()
    try: datetime.strptime(report_date,"%Y-%m-%d")
    except ValueError: report_date=date.today().isoformat()
    conn=get_db()
    if request.method=="POST":
        work_summary=request.form.get("work_summary","").strip(); tickets_worked=request.form.get("tickets_worked","").strip(); pending_work=request.form.get("pending_work","").strip(); issues=request.form.get("issues","").strip(); next_day_plan=request.form.get("next_day_plan","").strip()
        if not work_summary: flash("Please enter today's work summary.","error")
        else:
            current=now(); existing=conn.execute("SELECT id FROM daily_reports WHERE user_id=? AND report_date=?",(session["user_id"],report_date)).fetchone()
            if existing:
                conn.execute("UPDATE daily_reports SET work_summary=?,tickets_worked=?,pending_work=?,issues=?,next_day_plan=?,updated_at=? WHERE id=?",(work_summary,tickets_worked,pending_work,issues,next_day_plan,current,existing["id"])); action="Daily report updated"; report_id=existing["id"]
            else:
                cur=conn.execute("INSERT INTO daily_reports(user_id,report_date,work_summary,tickets_worked,pending_work,issues,next_day_plan,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(session["user_id"],report_date,work_summary,tickets_worked,pending_work,issues,next_day_plan,current,current)); action="Daily report submitted"; report_id=cur.lastrowid
            conn.commit(); audit(action,"daily_report",report_id,f"Report date: {report_date}"); flash("Daily report saved successfully.","success")
    report=conn.execute("SELECT * FROM daily_reports WHERE user_id=? AND report_date=?",(session["user_id"],report_date)).fetchone(); conn.close()
    return render_template("it_daily_report.html",report_date=report_date,report=report)

@app.route("/admin/it-daily-reports")
@login_required
@admin_required
def admin_it_daily_reports():
    report_date=request.args.get("date") or date.today().isoformat()
    selected_user=request.args.get("user_id","").strip()
    try: datetime.strptime(report_date,"%Y-%m-%d")
    except ValueError: report_date=date.today().isoformat()
    conn=get_db()
    users=conn.execute("SELECT id,full_name,username,designation FROM users WHERE active=1 AND role='it_user' ORDER BY full_name").fetchall()
    if selected_user.isdigit():
        # User-wise history view: one click loads every report for that IT User.
        reports=conn.execute("""SELECT u.id AS user_id,u.full_name,u.username,u.designation,
            dr.id,dr.report_date,dr.work_summary,dr.tickets_worked,dr.pending_work,dr.issues,
            dr.next_day_plan,dr.created_at,dr.updated_at
            FROM daily_reports dr JOIN users u ON u.id=dr.user_id
            WHERE u.role='it_user' AND u.active=1 AND u.id=?
            ORDER BY dr.report_date DESC, dr.id DESC""",(int(selected_user),)).fetchall()
    else:
        # Existing date-wise admin view remains unchanged when no user is selected.
        reports=conn.execute("""SELECT u.id AS user_id,u.full_name,u.username,u.designation,
            dr.id,dr.report_date,dr.work_summary,dr.tickets_worked,dr.pending_work,dr.issues,
            dr.next_day_plan,dr.created_at,dr.updated_at
            FROM users u LEFT JOIN daily_reports dr ON dr.user_id=u.id AND dr.report_date=?
            WHERE u.role='it_user' AND u.active=1 ORDER BY u.full_name""",(report_date,)).fetchall()
    conn.close()
    return render_template("admin_it_daily_reports.html",reports=reports,users=users,report_date=report_date,selected_user=selected_user,history_mode=selected_user.isdigit())

@app.route("/admin/reports/daily")
@login_required
@admin_required
def daily_report():
    report_date = request.args.get("date") or date.today().isoformat()
    try:
        datetime.strptime(report_date, "%Y-%m-%d")
    except ValueError:
        report_date = date.today().isoformat()
    report_text = build_daily_report(report_date)
    return render_template("daily_report.html", report_date=report_date, report_text=report_text)

@app.route("/admin/reports/daily/download")
@login_required
@admin_required
def download_daily_report():
    report_date = request.args.get("date") or date.today().isoformat()
    try:
        datetime.strptime(report_date, "%Y-%m-%d")
    except ValueError:
        report_date = date.today().isoformat()
    report_text = build_daily_report(report_date)
    filename = f"IT_Daily_Report_{report_date}.txt"
    return app.response_class(
        report_text,
        mimetype="text/plain; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

if __name__=="__main__":
    init_db(); app.run(host="0.0.0.0",port=5000,debug=False)
