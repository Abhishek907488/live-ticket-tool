MEETING CENTER - UPDATE
========================

Added to Live IT Service only:
- Ticket-level meeting request option.
- Automatic server-side meeting creation for Zoom, Microsoft Teams and Google Meet.
- Meeting date/time/title + multiple participants + CC.
- Saved contacts and saved groups.
- Reusable saved meeting links for recurring meetings.
- Automatic SMTP invitation using the existing Mail Configuration.
- Copy/Join/Resend actions in the ticket.
- Optional automatic ticket close after successful meeting creation and invitation (enabled by default).
- Admin Meeting Center with search and CSV/Excel-compatible export.
- Admin Meeting Integrations page with encrypted secrets and Test Connection.
- Server-side/LAN architecture: client PCs only use the browser; provider credentials stay on the server.

IMPORTANT:
Provider APIs require one-time administrator setup/consent. See MEETING_API_SETUP.md.
Existing ticketing database, SMTP, users, tickets, reports and current UI are preserved.
A backup of the pre-update app.py and key templates is stored in backups/meeting_feature_before_update/.
