"""Single-entry IT Service Desk + Inventory server.
Run only: python app.py
"""
import os
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from werkzeug.serving import run_simple

from ticket_app import app as ticket_app
from inventory_app.app import app as inventory_app, init_db as init_inventory_db

# Share the Ticket Center session signing key so Inventory opens without a second login.
inventory_app.secret_key = ticket_app.secret_key
inventory_app.config["SESSION_COOKIE_NAME"] = ticket_app.config.get("SESSION_COOKIE_NAME", "session")
inventory_app.config["SESSION_COOKIE_PATH"] = "/"

# Inventory is mounted below /inventory; its own templates/static files are namespaced.
# Explicitly expose Inventory static assets at the mounted LAN path.
# This keeps the original Inventory UI (CSS/images) intact when it is
# mounted below /inventory and avoids any static-path ambiguity.
application = DispatcherMiddleware(ticket_app, {"/inventory": inventory_app})

if __name__ == "__main__":
    # Both databases are initialized/migrated before the one LAN server starts.
    init_inventory_db()
    ticket_app.config["INVENTORY_PANEL_URL"] = "/inventory/dashboard"
    run_simple("0.0.0.0", int(os.environ.get("PORT", "5000")), application, use_reloader=False, use_debugger=False)
