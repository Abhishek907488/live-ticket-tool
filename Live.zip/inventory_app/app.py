from openpyxl import Workbook, load_workbook
try:
 from reportlab.lib.pagesizes import A4, landscape
 from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
 from reportlab.lib import colors
 from reportlab.lib.styles import getSampleStyleSheet
 REPORTLAB_AVAILABLE=True
except Exception:
 REPORTLAB_AVAILABLE=False
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os, re, json, ipaddress, socket, io
from io import BytesIO
from datetime import datetime

BASE_DIR=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE_DIR,"inventory.db")
# In the final one-server build both databases live under the same application root.
TICKETING_DB=os.path.normpath(os.path.join(BASE_DIR,"..","ticketing.db"))

def ticket_requester_name(ticket_no):
    """Read-only lookup of the employee/requester from the IT Ticket database."""
    if not ticket_no or not os.path.exists(TICKETING_DB):
        return ""
    try:
        tc=sqlite3.connect(TICKETING_DB)
        tc.row_factory=sqlite3.Row
        row=tc.execute("""SELECT COALESCE(u.full_name, u.username, '') AS requester
                          FROM tickets t LEFT JOIN users u ON u.id=t.user_id
                          WHERE t.ticket_no=? LIMIT 1""", (str(ticket_no).strip(),)).fetchone()
        tc.close()
        return (row["requester"] if row else "") or ""
    except Exception:
        return ""

def enrich_ticket_users(rows):
    """Add ticket_user_name to sqlite Row/dict-like rows without changing DB schema."""
    out=[]
    for r in rows:
        d=dict(r)
        d["ticket_user_name"]=ticket_requester_name(d.get("ticket_no",""))
        out.append(d)
    return out
BACKUP_DIR=os.path.join(BASE_DIR,"backups")
UPLOAD_DIR=os.path.join(BASE_DIR,"uploads")
os.makedirs(BACKUP_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)
app=Flask(__name__, template_folder="templates", static_folder="static")
app.config.update(MAX_CONTENT_LENGTH=16*1024*1024)
# Use an environment secret when provided; otherwise keep a local persistent secret
# so the Flask session is not protected by a predictable default key.
secret_file=os.path.join(BASE_DIR,".inventory_secret")
# Share the IT Service Desk session cookie so a logged-in ticket user can enter
# Inventory without a second login. The ticket role remains in session["inventory_role"];
# Inventory uses session["inventory_role"] so the two applications never overwrite
# each other's role value.
app.secret_key=os.getenv("APP_SECRET_KEY", "change-this-secret-key")
app.config.update(
    SESSION_COOKIE_NAME="session",
    SESSION_COOKIE_PATH="/",
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=False,  # LAN HTTP deployments use normal HTTP.
)

ROLES={
    "Admin":{"view":True,"edit":True,"delete":True,"new_entry":True,"user_management":True},
    "IT Admin":{"view":True,"edit":True,"delete":False,"new_entry":True,"user_management":False},
    "User":{"view":True,"edit":False,"delete":False,"new_entry":False,"user_management":False},
}


def db():
    c=sqlite3.connect(DB)
    c.row_factory=sqlite3.Row
    return c

def create_safety_backup(label):
    """Create a database snapshot before a destructive action."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    safe_label=re.sub(r"[^A-Za-z0-9_-]+", "_", str(label)).strip("_") or "delete"
    path=os.path.join(BACKUP_DIR, f"pre_delete_{safe_label}_{stamp}.db")
    if not os.path.exists(DB):
        raise FileNotFoundError("Inventory database was not found.")
    src=sqlite3.connect(DB)
    dst=sqlite3.connect(path)
    try:
        with dst:
            src.backup(dst)
    finally:
        dst.close(); src.close()
    return os.path.basename(path)

def audit_log(c, action, module, changed_by=None, target_type="", target_id="", details=""):
    user = changed_by or session.get("user") or "System"
    if isinstance(details, (dict, list)):
        details = json.dumps(details, ensure_ascii=False)
    c.execute(
        "INSERT INTO audit_log(action,module,target_type,target_id,details,changed_by) VALUES(?,?,?,?,?,?)",
        (action, module, str(target_type or ""), str(target_id or ""), str(details or ""), user)
    )

def init_db():
    c=db()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS dashboard_folders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        description TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS folder_fields(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        folder_id INTEGER NOT NULL,
        field_name TEXT NOT NULL,
        field_type TEXT NOT NULL DEFAULT 'text',
        required INTEGER NOT NULL DEFAULT 0,
        options TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(folder_id) REFERENCES dashboard_folders(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS inventory_entries(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        folder_id INTEGER NOT NULL,
        created_by TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'In Stock',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(folder_id) REFERENCES dashboard_folders(id) ON DELETE CASCADE
    )""")
    cols = [r["name"] for r in c.execute("PRAGMA table_info(inventory_entries)").fetchall()]
    if "status" not in cols:
        c.execute("ALTER TABLE inventory_entries ADD COLUMN status TEXT NOT NULL DEFAULT 'In Stock'")
    c.execute("""CREATE TABLE IF NOT EXISTS entry_values(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id INTEGER NOT NULL,
        field_id INTEGER NOT NULL,
        value TEXT DEFAULT '',
        FOREIGN KEY(entry_id) REFERENCES inventory_entries(id) ON DELETE CASCADE,
        FOREIGN KEY(field_id) REFERENCES folder_fields(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS entry_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id INTEGER NOT NULL,
        version_no INTEGER NOT NULL,
        action TEXT NOT NULL DEFAULT 'Created',
        changed_by TEXT NOT NULL,
        changed_at TEXT DEFAULT CURRENT_TIMESTAMP,
        snapshot_json TEXT NOT NULL,
        changes_json TEXT DEFAULT '[]',
        changed_ip TEXT DEFAULT '',
        changed_host TEXT DEFAULT '',
        FOREIGN KEY(entry_id) REFERENCES inventory_entries(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS asset_metadata(
        entry_id INTEGER PRIMARY KEY,
        purchase_date TEXT DEFAULT '',
        invoice_date TEXT DEFAULT '',
        warranty_start TEXT DEFAULT '',
        warranty_end TEXT DEFAULT '',
        amc_details TEXT DEFAULT '',
        FOREIGN KEY(entry_id) REFERENCES inventory_entries(id) ON DELETE CASCADE
    )""")
    md_cols = [r["name"] for r in c.execute("PRAGMA table_info(asset_metadata)").fetchall()]
    if "invoice_date" not in md_cols:
        c.execute("ALTER TABLE asset_metadata ADD COLUMN invoice_date TEXT DEFAULT ''")
    c.execute("""CREATE TABLE IF NOT EXISTS repair_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT, entry_id INTEGER NOT NULL,
        repair_date TEXT NOT NULL, issue TEXT DEFAULT '', action_taken TEXT DEFAULT '',
        vendor TEXT DEFAULT '', cost TEXT DEFAULT '', result TEXT DEFAULT 'Completed',
        remarks TEXT DEFAULT '', created_by TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        client_ip TEXT DEFAULT '', client_host TEXT DEFAULT '',
        FOREIGN KEY(entry_id) REFERENCES inventory_entries(id) ON DELETE CASCADE
    )""")
    history_cols = [r["name"] for r in c.execute("PRAGMA table_info(entry_history)").fetchall()]
    if "changed_ip" not in history_cols:
        c.execute("ALTER TABLE entry_history ADD COLUMN changed_ip TEXT DEFAULT ''")
    if "changed_host" not in history_cols:
        c.execute("ALTER TABLE entry_history ADD COLUMN changed_host TEXT DEFAULT ''")
    c.execute("""CREATE TABLE IF NOT EXISTS asset_assignments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id INTEGER NOT NULL,
        assigned_to TEXT DEFAULT '',
        department TEXT DEFAULT '',
        location TEXT DEFAULT '',
        action TEXT NOT NULL DEFAULT 'Assigned',
        notes TEXT DEFAULT '',
        changed_by TEXT NOT NULL,
        changed_at TEXT DEFAULT CURRENT_TIMESTAMP,
        changed_ip TEXT DEFAULT '',
        changed_host TEXT DEFAULT '',
        FOREIGN KEY(entry_id) REFERENCES inventory_entries(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS ewaste_records(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        original_entry_id INTEGER,
        source_folder_id INTEGER,
        auto_created INTEGER NOT NULL DEFAULT 0,
        disposal_date TEXT DEFAULT '',
        disposal_reason TEXT DEFAULT '',
        status TEXT DEFAULT 'E-Waste',
        created_by TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        data_json TEXT DEFAULT '{}',
        FOREIGN KEY(original_entry_id) REFERENCES inventory_entries(id) ON DELETE SET NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS ewaste_fields(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        field_name TEXT NOT NULL,
        field_type TEXT NOT NULL DEFAULT 'text',
        required INTEGER NOT NULL DEFAULT 0,
        options TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS ewaste_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ewaste_id INTEGER NOT NULL,
        version_no INTEGER NOT NULL,
        action TEXT NOT NULL,
        changed_by TEXT NOT NULL,
        changed_at TEXT DEFAULT CURRENT_TIMESTAMP,
        snapshot_json TEXT NOT NULL,
        changes_json TEXT DEFAULT '[]',
        changed_ip TEXT DEFAULT '',
        changed_host TEXT DEFAULT '',
        FOREIGN KEY(ewaste_id) REFERENCES ewaste_records(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS entry_attachments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id INTEGER,
        ewaste_id INTEGER,
        category TEXT NOT NULL,
        original_name TEXT NOT NULL,
        stored_name TEXT NOT NULL,
        uploaded_by TEXT NOT NULL,
        uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(entry_id) REFERENCES inventory_entries(id) ON DELETE CASCADE,
        FOREIGN KEY(ewaste_id) REFERENCES ewaste_records(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS pm_schedules(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id INTEGER NOT NULL UNIQUE,
        pm_type TEXT NOT NULL DEFAULT 'Normal PC',
        frequency_months INTEGER NOT NULL DEFAULT 6,
        last_pm_date TEXT DEFAULT '',
        next_due_date TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        created_by TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(entry_id) REFERENCES inventory_entries(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS pm_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        schedule_id INTEGER NOT NULL,
        pm_date TEXT NOT NULL,
        pm_type TEXT NOT NULL,
        result TEXT DEFAULT 'Completed',
        performed_by TEXT NOT NULL,
        remarks TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(schedule_id) REFERENCES pm_schedules(id) ON DELETE CASCADE
    )""")
    # PM execution audit context (safe migration for older databases)
    for _col, _typ in (("performed_ip", "TEXT DEFAULT ''"), ("performed_host", "TEXT DEFAULT ''")):
        try:
            c.execute(f"ALTER TABLE pm_history ADD COLUMN {_col} {_typ}")
        except sqlite3.OperationalError:
            pass

    c.execute("CREATE TABLE IF NOT EXISTS it_software(id INTEGER PRIMARY KEY AUTOINCREMENT, software_name TEXT NOT NULL, version TEXT DEFAULT '', vendor TEXT DEFAULT '', license_type TEXT DEFAULT 'Per Device', license_key TEXT DEFAULT '', purchase_date TEXT DEFAULT '', expiry_date TEXT DEFAULT '', quantity INTEGER NOT NULL DEFAULT 1, assigned_to TEXT DEFAULT '', department TEXT DEFAULT '', asset_reference TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'Active', remarks TEXT DEFAULT '', created_by TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    c.execute("""CREATE TABLE IF NOT EXISTS rental_printers(
        id INTEGER PRIMARY KEY AUTOINCREMENT, printer_id TEXT UNIQUE NOT NULL, printer_name TEXT DEFAULT '', model TEXT DEFAULT '', lan_ip TEXT DEFAULT '', location TEXT DEFAULT '', department TEXT DEFAULT '', vendor TEXT DEFAULT '', free_pages INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Active', remarks TEXT DEFAULT '', created_by TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS rental_printer_readings(
        id INTEGER PRIMARY KEY AUTOINCREMENT, printer_id INTEGER NOT NULL, reading_month TEXT NOT NULL, previous_reading INTEGER NOT NULL DEFAULT 0, current_reading INTEGER NOT NULL DEFAULT 0, total_pages INTEGER NOT NULL DEFAULT 0, free_pages INTEGER NOT NULL DEFAULT 0, extra_pages INTEGER NOT NULL DEFAULT 0, remarks TEXT DEFAULT '', created_by TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(printer_id, reading_month), FOREIGN KEY(printer_id) REFERENCES rental_printers(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS rental_printer_services(
        id INTEGER PRIMARY KEY AUTOINCREMENT, printer_id INTEGER NOT NULL, service_date TEXT NOT NULL, work TEXT DEFAULT '', vendor TEXT DEFAULT '', page_count INTEGER NOT NULL DEFAULT 0, cost TEXT DEFAULT '', result TEXT DEFAULT 'Completed', remarks TEXT DEFAULT '', created_by TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(printer_id) REFERENCES rental_printers(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS system_settings(
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS audit_log(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        module TEXT NOT NULL,
        target_type TEXT DEFAULT '',
        target_id TEXT DEFAULT '',
        details TEXT DEFAULT '',
        changed_by TEXT NOT NULL,
        changed_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""INSERT OR IGNORE INTO system_settings(key,value)
                 VALUES('lan_network','192.168.1.0/24')""")
    c.commit()
    # Ensure Computer folder has a PM Type field for the PM workflow.
    computer_folder = c.execute("SELECT id FROM dashboard_folders WHERE lower(name) LIKE '%computer%' LIMIT 1").fetchone()
    if computer_folder:
        pm_field = c.execute("SELECT id FROM folder_fields WHERE folder_id=? AND lower(replace(replace(replace(field_name,' ',''),'-',''),'_','')) IN ('preventivemaintenancetype','pmtype') LIMIT 1", (computer_folder['id'],)).fetchone()
        if not pm_field:
            c.execute("INSERT INTO folder_fields(folder_id,field_name,field_type,required,options) VALUES(?,?,?,?,?)",
                      (computer_folder['id'],'Preventive Maintenance Type','select',0,'Normal PC\nInstrument PC\nPrinter\nServer\nOther'))
    # No default/admin credentials are created. A fresh installation uses
    # the one-time first-run Admin setup screen instead.
    c.close()

@app.template_filter("from_json")
def from_json_filter(value):
    try:
        return json.loads(value or "{}")
    except Exception:
        return {}

@app.context_processor
def inject():
    role=session.get("inventory_role")
    return {"current_role":role,"permissions":ROLES.get(role,{}),"pm_state":pm_state}


LIFECYCLE_STATUSES = ["In Stock","Assigned/In Use","Under Repair","Returned","Retired","Disposed","In Used"]
WARRANTY_SOON_DAYS = 30
ALLOWED_UPLOAD_EXT = {"pdf","png","jpg","jpeg","doc","docx","xls","xlsx","txt"}

def normalized_status(status):
    return "Assigned/In Use" if status == "In Used" else status

def warranty_state(end_date):
    if not end_date:
        return "No Warranty Date"
    try:
        from datetime import date
        d=date.fromisoformat(str(end_date)[:10])
        today=date.today()
        if d < today: return "Expired"
        if (d-today).days <= WARRANTY_SOON_DAYS: return "Expiring Soon"
        return "Active"
    except Exception:
        return "Unknown"

def field_values(c, entry_id):
    rows=c.execute("""SELECT ff.field_name, ev.value, ff.id AS field_id
                      FROM entry_values ev JOIN folder_fields ff ON ff.id=ev.field_id
                      WHERE ev.entry_id=? ORDER BY ff.id""",(entry_id,)).fetchall()
    return [dict(r) for r in rows]

def entry_department(c, entry_id):
    rows=field_values(c,entry_id)
    for r in rows:
        if normalize_field_name(r["field_name"])=="department":
            return r["value"]
    return ""

def entry_user(c, entry_id):
    for r in field_values(c,entry_id):
        n=normalize_field_name(r["field_name"])
        if n in {"assignedto","assigneduser","employee","employeeid","username","user"}:
            return r["value"]
    return ""

def entry_location(c, entry_id):
    for r in field_values(c,entry_id):
        if normalize_field_name(r["field_name"]) in {"location","assetlocation"}:
            return r["value"]
    return ""

def metadata_row(c, entry_id):
    r=c.execute("SELECT * FROM asset_metadata WHERE entry_id=?",(entry_id,)).fetchone()
    return r or {"entry_id":entry_id,"purchase_date":"","invoice_date":"","warranty_start":"","warranty_end":"","amc_details":""}

def ensure_metadata(c, entry_id):
    c.execute("INSERT OR IGNORE INTO asset_metadata(entry_id) VALUES(?)",(entry_id,))

def ewaste_snapshot(c, eid):
    e=c.execute("SELECT * FROM ewaste_records WHERE id=?",(eid,)).fetchone()
    if not e: return {}
    return {"id":e["id"],"original_entry_id":e["original_entry_id"],"source_folder_id":e["source_folder_id"],
            "auto_created":e["auto_created"],"disposal_date":e["disposal_date"],"disposal_reason":e["disposal_reason"],
            "status":e["status"],"created_by":e["created_by"],"created_at":e["created_at"],"data":json.loads(e["data_json"] or "{}")}

def save_ewaste_history(c,eid,action,changes):
    v=c.execute("SELECT COALESCE(MAX(version_no),0)+1 FROM ewaste_history WHERE ewaste_id=?",(eid,)).fetchone()[0]
    ip,host=client_context()
    c.execute("""INSERT INTO ewaste_history(ewaste_id,version_no,action,changed_by,snapshot_json,changes_json,changed_ip,changed_host)
                 VALUES(?,?,?,?,?,?,?,?)""",(eid,v,action,session.get("user","System"),json.dumps(ewaste_snapshot(c,eid),ensure_ascii=False),
                 json.dumps(changes,ensure_ascii=False),ip,host))

def ensure_ewaste_for_disposed(c, entry_id, disposal_reason=""):
    e=c.execute("SELECT * FROM inventory_entries WHERE id=?",(entry_id,)).fetchone()
    if not e or normalized_status(e["status"])!="Disposed": return None
    existing=c.execute("SELECT id FROM ewaste_records WHERE original_entry_id=? AND auto_created=1",(entry_id,)).fetchone()
    if existing: return existing["id"]
    md=metadata_row(c,entry_id)
    data={"asset_fields":field_values(c,entry_id),"purchase_date":md["purchase_date"],"invoice_date":md["invoice_date"],"warranty_start":md["warranty_start"],
          "warranty_end":md["warranty_end"],"amc_details":md["amc_details"],"preserved_at":datetime.now().isoformat()}
    cur=c.execute("""INSERT INTO ewaste_records(original_entry_id,source_folder_id,auto_created,disposal_date,disposal_reason,created_by,data_json)
                     VALUES(?,?,?,?,?,?,?)""",(entry_id,e["folder_id"],1,datetime.now().strftime("%Y-%m-%d"),disposal_reason or "Asset status changed to Disposed",
                     session.get("user","System"),json.dumps(data,ensure_ascii=False)))
    eid=cur.lastrowid
    save_ewaste_history(c,eid,"Auto Created",[{"field":"Source","old":"","new":f"Inventory Entry #{entry_id}"}])
    audit_log(c,"Auto Create","E-Waste",target_type="E-Waste",target_id=eid,details={"original_entry_id":entry_id,"reason":disposal_reason})
    return eid

def attachment_ok(filename):
    return "." in filename and filename.rsplit(".",1)[1].lower() in ALLOWED_UPLOAD_EXT

def safe_upload(c, entry_id=None, ewaste_id=None, category="Other", field_name="attachment"):
    f=request.files.get(field_name)
    if not f or not f.filename: return None
    from werkzeug.utils import secure_filename
    if not attachment_ok(f.filename):
        flash("Unsupported attachment type.","error"); return None
    original=secure_filename(f.filename)
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    stored=f"{stamp}_{original}"
    path=os.path.join(UPLOAD_DIR,stored)
    f.save(path)
    cur=c.execute("""INSERT INTO entry_attachments(entry_id,ewaste_id,category,original_name,stored_name,uploaded_by)
                     VALUES(?,?,?,?,?,?)""",(entry_id,ewaste_id,category,original,stored,session.get("user","System")))
    audit_log(c,"Attachment Upload","Attachments",target_type="Entry" if entry_id else "E-Waste",
              target_id=entry_id or ewaste_id,details={"category":category,"file":original})
    return cur.lastrowid


def add_months(iso_date, months):
    from datetime import date
    d=date.fromisoformat(str(iso_date)[:10])
    month=d.month-1+int(months)
    year=d.year+month//12
    month=month%12+1
    import calendar
    day=min(d.day, calendar.monthrange(year,month)[1])
    return date(year,month,day).isoformat()

PM_FREQUENCY_MONTHS = {"Normal PC":6,"Instrument PC":3,"Printer":6,"Server":12,"Other":0}

def pm_frequency_label(pm_type):
    m=PM_FREQUENCY_MONTHS.get(pm_type,0)
    return {3:"4 times / year · 3 months",6:"2 times / year · 6 months",12:"1 time / year · 12 months",0:"No PM"}.get(m,"No PM")

def pm_state(next_due, pm_type=None):
    if pm_type == "Other": return "No PM"
    if not next_due:
        return "Not Scheduled"
    from datetime import date
    try:
        d=date.fromisoformat(str(next_due)[:10]); today=date.today()
        days=(d-today).days
        if days < 0: return "Overdue"
        if days <= 30: return "Due Soon"
        return "Scheduled"
    except Exception:
        return "Not Scheduled"

def computer_entries(c):
    folder=c.execute("SELECT id,name FROM dashboard_folders WHERE lower(name) IN ('computer','computers',\"computer's\",\"computers'\") OR lower(name) LIKE '%computer%'").fetchone()
    if not folder: return []
    return c.execute("SELECT id,folder_id,status,created_at FROM inventory_entries WHERE folder_id=? ORDER BY id DESC",(folder["id"],)).fetchall()



# ---- One-server bridge: reuse the logged-in IT Service Desk identity ----
INVENTORY_PERMISSION_COLUMNS = {
    "view": "inventory_view",
    "add": "inventory_add",
    "edit": "inventory_edit",
    "issue_return": "inventory_issue_return",
    "asset_profile": "inventory_asset_profile",
    "pm": "inventory_pm",
    "rental_printer": "inventory_rental_printer",
    "export": "inventory_export",
}

@app.before_request
def one_server_identity_bridge():
    # Static files and the inventory setup/login flow must remain reachable.
    if request.endpoint == "static" or request.path.rstrip("/") in ("", "/setup-admin"):
        return None
    # If the Ticket Center user is logged in, mirror only the inventory identity.
    # The Ticket Center's session["role"] is intentionally never changed.
    if session.get("user_id"):
        try:
            tc=sqlite3.connect(TICKETING_DB)
            tc.row_factory=sqlite3.Row
            u=tc.execute("SELECT * FROM users WHERE id=? AND active=1",(session.get("user_id"),)).fetchone()
            tc.close()
            if u:
                role_map={"admin":"Admin","it_user":"IT Admin","erp_admin":"User","erp_user":"User","employee":"User"}
                session["user"]=u["username"]
                session["inventory_role"]=role_map.get(u["role"],"User")
                session["inventory_ticket_user_id"]=u["id"]
                if u["role"]=="admin":
                    return None
                # Permission is controlled by the Ticket Center user record.
                # GET pages use View unless a more specific module is requested.
                path=request.path.rstrip("/")
                required="view"
                if path.startswith("/asset-profile") or path.startswith("/asset/"):
                    required="asset_profile"
                elif path.startswith("/preventive-maintenance"):
                    required="pm"
                elif path.startswith("/rental-printer"):
                    required="rental_printer"
                elif "/export" in path or path.startswith("/reports"):
                    required="export"
                elif request.method=="POST":
                    required="edit"
                    if any(x in path for x in ("/entry", "/create", "/folders/create", "/it-software/create")):
                        required="add"
                    if "inventory-store" in path:
                        required="issue_return"
                col=INVENTORY_PERMISSION_COLUMNS[required]
                if not bool(u[col] if col in u.keys() else False):
                    return render_template("access_denied.html", required_permission=required), 403
        except Exception:
            logging.exception("One-server identity bridge failed")
    return None

@app.route("/",methods=["GET","POST"])
def login():
    if session.get("user"): return redirect(url_for("home"))
    c=db()
    setup_required = c.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0] == 0
    if request.method=="POST":
        username=request.form.get("username", "").strip()
        password=request.form.get("password", "")
        # Role is determined from the user's account. The login form intentionally
        # does not ask the user to select Admin / IT Admin / User.
        u=c.execute("SELECT * FROM users WHERE (username=? OR lower(email)=lower(?)) AND active=1",(username,username)).fetchone()
        if u and check_password_hash(u["password_hash"],password):
            session["user"]=u["username"]; session["inventory_role"]=u["role"]
            audit_log(c, "Login", "Authentication", u["username"], "User", u["id"], {"role": u["role"]})
            c.commit(); c.close()
            return redirect(url_for("home"))
        audit_log(c, "Failed Login", "Authentication", username or "Unknown", target_type="User", target_id=username, details={"login_method": "username_or_email"})
        c.commit(); c.close()
        flash("Invalid User ID / Email or password.","error")
        return render_template("login.html", setup_required=setup_required)
    c.close()
    return render_template("login.html", setup_required=setup_required)

@app.route("/setup-admin", methods=["GET", "POST"])
def setup_admin():
    # One-time first-run setup. Once any active user exists, this route is locked.
    c=db()
    if c.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0] > 0:
        c.close()
        return redirect(url_for("login"))
    if request.method == "POST":
        username=request.form.get("username", "").strip()
        email=request.form.get("email", "").strip()
        password=request.form.get("password", "")
        confirm=request.form.get("confirm_password", "")
        if not username or not email or not password:
            flash("Please complete all fields.", "error")
        elif len(password) < 8:
            flash("Password must be at least 8 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        else:
            try:
                cur=c.execute("INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,?)",
                              (username,email,generate_password_hash(password),"Admin"))
                audit_log(c, "Create", "User Management", username, "User", cur.lastrowid,
                          {"username": username, "email": email, "role": "Admin", "method": "First-run setup"})
                c.commit(); c.close()
                flash("Admin account created successfully. You can now sign in.", "ok")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username or email already exists.", "error")
    c.close()
    return render_template("setup_admin.html")

@app.route("/dashboard")
def home():
    if not session.get("user"): return redirect(url_for("login"))
    c=db()

    folders = c.execute("""
        SELECT df.*,
               COUNT(ie.id) AS entry_count,
               COALESCE(SUM(CASE WHEN ie.status IN ('In Used','Assigned/In Use') THEN 1 ELSE 0 END),0) AS in_used,
               COALESCE(SUM(CASE WHEN ie.status='In Stock' THEN 1 ELSE 0 END),0) AS in_stock
        FROM dashboard_folders df
        LEFT JOIN inventory_entries ie ON ie.folder_id=df.id
        GROUP BY df.id
        ORDER BY df.name COLLATE NOCASE
    """).fetchall()

    total_entries = c.execute("SELECT COUNT(*) AS n FROM inventory_entries").fetchone()["n"]
    in_used = c.execute("SELECT COUNT(*) AS n FROM inventory_entries WHERE status IN ('In Used','Assigned/In Use')").fetchone()["n"]
    in_stock = c.execute("SELECT COUNT(*) AS n FROM inventory_entries WHERE status='In Stock'").fetchone()["n"]
    total_users = c.execute("SELECT COUNT(*) AS n FROM users WHERE active=1").fetchone()["n"]

    # Used/free IP summary across every inventory folder.
    used_ips=set()
    ip_fields=get_lan_ip_fields(c)
    for f in ip_fields:
        rows=c.execute("""
            SELECT value FROM entry_values
            WHERE field_id=? AND trim(value)<>''
        """,(f["id"],)).fetchall()
        for r in rows:
            try:
                used_ips.add(str(ipaddress.ip_address(r["value"].strip())))
            except ValueError:
                pass
    try:
        for r in c.execute("SELECT lan_ip FROM rental_printers WHERE trim(lan_ip)<>''").fetchall():
            try:
                used_ips.add(str(ipaddress.ip_address(r["lan_ip"].strip())))
            except ValueError:
                pass
    except sqlite3.OperationalError:
        pass

    network_text=get_lan_network(c)
    try:
        network=ipaddress.ip_network(network_text, strict=False)
        total_usable=max(network.num_addresses-2, 0) if network.version==4 else network.num_addresses
        used_in_network=sum(1 for ip in used_ips if ipaddress.ip_address(ip) in network)
        free_ips=max(total_usable-used_in_network,0)
    except ValueError:
        total_usable=0
        used_in_network=0
        free_ips=0

    # Department summary is intentionally limited to the Computer's inventory.
    # This keeps the dashboard focused on computer assets instead of mixing
    # departments from Mouse/Keyboard/Printer/etc. folders.
    computer_folder=c.execute("""
        SELECT id, name FROM dashboard_folders
        WHERE lower(replace(replace(replace(replace(name,' ',''),char(39),''),'-',''),'_',''))='computers'
        ORDER BY id LIMIT 1
    """).fetchone()
    computer_folder_id=computer_folder['id'] if computer_folder else None
    dept_rows=[]
    if computer_folder_id is not None:
        dept_rows=c.execute("""
            SELECT ev.value, COUNT(*) AS n
            FROM entry_values ev
            JOIN folder_fields ff ON ff.id=ev.field_id
            JOIN inventory_entries ie ON ie.id=ev.entry_id
            WHERE ie.folder_id=?
              AND lower(replace(replace(replace(ff.field_name,' ',''),'_',''),'-',''))='department'
              AND trim(ev.value)<>''
            GROUP BY ev.value COLLATE NOCASE
            ORDER BY n DESC, ev.value COLLATE NOCASE
            LIMIT 8
        """,(computer_folder_id,)).fetchall()

    # Recent activity, including create/import/edit history.
    recent=c.execute("""
        SELECT eh.action, eh.changed_by, eh.changed_at,
               df.name AS folder_name, eh.entry_id
        FROM entry_history eh
        JOIN inventory_entries ie ON ie.id=eh.entry_id
        JOIN dashboard_folders df ON df.id=ie.folder_id
        ORDER BY eh.changed_at DESC, eh.id DESC
        LIMIT 8
    """).fetchall()

    # Dashboard alerts / operational watchlist.
    warranty_expiring=0; warranty_expired=0
    for r in c.execute("SELECT warranty_end FROM asset_metadata WHERE warranty_end<>''").fetchall():
        st=warranty_state(r["warranty_end"])
        warranty_expiring += (st=="Expiring Soon")
        warranty_expired += (st=="Expired")
    under_repair=c.execute("SELECT COUNT(*) FROM inventory_entries WHERE status='Under Repair'").fetchone()[0]
    disposed_count=c.execute("SELECT COUNT(*) FROM inventory_entries WHERE status='Disposed'").fetchone()[0]
    ewaste_count=c.execute("SELECT COUNT(*) FROM ewaste_records").fetchone()[0]
    # PM operational alerts: only configured PM schedules are counted.
    pm_due_soon=0; pm_overdue=0
    for pr in c.execute("SELECT next_due_date, pm_type FROM pm_schedules").fetchall():
        ps=pm_state(pr["next_due_date"], pr["pm_type"])
        pm_due_soon += (ps=="Due Soon")
        pm_overdue += (ps=="Overdue")
    software_expiring=software_expired=0
    try:
        for sr in c.execute("SELECT expiry_date FROM it_software WHERE expiry_date<>''").fetchall():
            try:
                days=(datetime.fromisoformat(str(sr["expiry_date"])[:10]).date()-datetime.now().date()).days
                if days<0: software_expired+=1
                elif days<=30: software_expiring+=1
            except Exception: pass
    except sqlite3.OperationalError: pass

    duplicate_warnings=0
    identity_rows=c.execute("""SELECT ff.field_name, ev.value FROM entry_values ev JOIN folder_fields ff ON ff.id=ev.field_id WHERE trim(ev.value)<>''""").fetchall()
    buckets={}
    for rr in identity_rows:
        cat=identity_field_type(rr["field_name"])
        if cat: buckets.setdefault((cat,rr["value"].strip().casefold()),0); buckets[(cat,rr["value"].strip().casefold())]+=1
    duplicate_warnings=sum(1 for n in buckets.values() if n>1)
    unassigned=0
    for r in c.execute("SELECT id FROM inventory_entries WHERE status IN ('In Stock','Returned')").fetchall():
        if not entry_user(c,r["id"]): unassigned+=1
    consumable_count=c.execute("SELECT COUNT(*) FROM consumable_items WHERE active=1").fetchone()[0]
    consumable_units=c.execute("SELECT COALESCE(SUM(available_qty),0) FROM consumable_items WHERE active=1").fetchone()[0]
    low_stock_count=c.execute("SELECT COUNT(*) FROM consumable_items WHERE active=1 AND available_qty<=min_stock").fetchone()[0]
    issued_units=c.execute("SELECT COALESCE(SUM(qty),0) FROM consumable_transactions WHERE txn_type='Issue'").fetchone()[0]
    c.close()

    max_dept=max([r["n"] for r in dept_rows], default=1)
    now=datetime.now().strftime("%d %b %Y")

    return render_template(
        "dashboard.html",
        folders=folders,
        total_entries=total_entries,
        in_used=in_used,
        in_stock=in_stock,
        total_users=total_users,
        used_ips=used_in_network,
        free_ips=free_ips,
        total_usable_ips=total_usable,
        network_text=network_text,
        dept_rows=dept_rows,
        max_dept=max_dept,
        computer_folder_id=computer_folder_id,
        recent=recent,
        today=now,
        warranty_expiring=warranty_expiring,
        warranty_expired=warranty_expired,
        under_repair=under_repair,
        unassigned=unassigned,
        disposed_count=disposed_count,
        ewaste_count=ewaste_count,
        duplicate_warnings=duplicate_warnings,
        pm_due_soon=pm_due_soon,
        pm_overdue=pm_overdue,
        software_expiring=software_expiring,
        software_expired=software_expired,
        consumable_count=consumable_count,
        consumable_units=consumable_units,
        low_stock_count=low_stock_count,
        issued_units=issued_units
    )

@app.route("/users")
def users():
    if not session.get("user") or not permissions_for("user_management"): return redirect(url_for("home"))
    c=db(); rows=c.execute("SELECT id,username,email,role,active FROM users ORDER BY id DESC").fetchall(); c.close()
    return render_template("users.html",users=rows)

def permissions_for(key): return ROLES.get(session.get("inventory_role"),{}).get(key,False)

@app.route("/users/create",methods=["POST"])
def create_user():
    if not session.get("user") or not permissions_for("user_management"): return redirect(url_for("home"))
    username=request.form["username"].strip(); email=request.form["email"].strip()
    password=request.form["password"]; role=request.form["role"]
    if role not in ROLES: flash("Invalid role.","error"); return redirect(url_for("users"))
    try:
        c=db()
        cur=c.execute("INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,?)",
                  (username,email,generate_password_hash(password),role))
        audit_log(c, "Create", "User Management", target_type="User", target_id=cur.lastrowid, details={"username": username, "email": email, "role": role})
        c.commit(); c.close(); flash("User created successfully.","ok")
    except sqlite3.IntegrityError:
        flash("Username or email already exists.","error")
    return redirect(url_for("users"))

@app.route("/users/delete/<int:user_id>",methods=["POST"])
def delete_user(user_id):
    if not session.get("user") or not permissions_for("delete"): return redirect(url_for("home"))
    c=db(); target=c.execute("SELECT username,email,role FROM users WHERE id=?",(user_id,)).fetchone()
    if not target:
        c.close(); flash("User not found.","error"); return redirect(url_for("users"))
    if target["username"] == session["user"]:
        c.close(); flash("You cannot delete the currently logged-in user.","error"); return redirect(url_for("users"))
    c.close()
    try:
        safety=create_safety_backup(f"user_{user_id}")
        c=db()
        c.execute("DELETE FROM users WHERE id=? AND username!=?",(user_id,session["user"]))
        audit_log(c, "Delete", "User Management", target_type="User", target_id=user_id, details={"username": target["username"], "email": target["email"], "role": target["role"], "safety_backup": safety})
        c.commit(); c.close()
        flash(f"User deleted safely. Recovery backup created: {safety}","ok")
    except Exception as exc:
        flash(f"Delete cancelled because safety backup could not be created: {exc}","error")
    return redirect(url_for("users"))

@app.route("/data-management")
def data_management():
    if not session.get("user") or session.get("inventory_role") != "Admin":
        return redirect(url_for("home"))
    c=db()
    folders=c.execute("SELECT * FROM dashboard_folders ORDER BY name COLLATE NOCASE").fetchall()
    c.close()
    backups=[]
    for name in sorted(os.listdir(BACKUP_DIR), reverse=True):
        path=os.path.join(BACKUP_DIR,name)
        if os.path.isfile(path) and name.lower().endswith(".db"):
            backups.append({"name":name,"size":os.path.getsize(path),"created":datetime.fromtimestamp(os.path.getmtime(path)).strftime("%d %b %Y, %I:%M %p")})
    return render_template("data_management.html", folders=folders, backups=backups[:10])

@app.route("/backup/create", methods=["POST"])
def create_backup():
    if not session.get("user") or session.get("inventory_role") != "Admin":
        return redirect(url_for("home"))
    if not os.path.exists(DB):
        flash("Inventory database was not found.", "error")
        return redirect(url_for("data_management"))
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name=f"inventory_backup_{stamp}.db"
    backup_path=os.path.join(BACKUP_DIR, backup_name)
    try:
        src=sqlite3.connect(DB)
        dst=sqlite3.connect(backup_path)
        with dst:
            src.backup(dst)
        dst.close(); src.close()
        c=db(); audit_log(c, "Backup", "Backup & Restore", target_type="Backup", target_id=backup_name, details={"file": backup_name, "size": os.path.getsize(backup_path)}) ; c.commit(); c.close()
        flash(f"Backup created successfully: {backup_name}", "ok")
        return send_file(backup_path, as_attachment=True, download_name=backup_name, mimetype="application/octet-stream")
    except Exception as exc:
        for path in (backup_path,):
            try:
                if os.path.exists(path): os.remove(path)
            except OSError:
                pass
        flash(f"Backup failed: {exc}", "error")
        return redirect(url_for("data_management"))

@app.route("/backup/download/<path:filename>")
def download_backup(filename):
    if not session.get("user") or session.get("inventory_role") != "Admin":
        return redirect(url_for("home"))
    safe_name=os.path.basename(filename)
    if safe_name != filename or not safe_name.lower().endswith(".db"):
        return "Invalid backup file", 400
    path=os.path.join(BACKUP_DIR,safe_name)
    if not os.path.isfile(path):
        flash("Backup file not found.", "error")
        return redirect(url_for("data_management"))
    return send_file(path, as_attachment=True, download_name=safe_name, mimetype="application/octet-stream")

@app.route("/backup/restore", methods=["POST"])
def restore_backup():
    if not session.get("user") or session.get("inventory_role") != "Admin":
        return redirect(url_for("home"))
    uploaded=request.files.get("backup_file")
    if not uploaded or not uploaded.filename:
        flash("Please select a backup database file.", "error")
        return redirect(url_for("data_management"))
    if not uploaded.filename.lower().endswith(".db"):
        flash("Only .db backup files are supported.", "error")
        return redirect(url_for("data_management"))

    temp_path=os.path.join(BACKUP_DIR, f"restore_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.tmp")
    try:
        uploaded.save(temp_path)
        check=sqlite3.connect(temp_path)
        integrity=check.execute("PRAGMA integrity_check").fetchone()[0]
        required={r[0] for r in check.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        check.close()
        if integrity != "ok" or not {"users","dashboard_folders","inventory_entries","entry_values"}.issubset(required):
            raise ValueError("The selected file is not a valid Inventory Management backup.")

        # Keep a safety copy of the current database before replacing it.
        safety=os.path.join(BACKUP_DIR, f"pre_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
        src=sqlite3.connect(DB); dst=sqlite3.connect(safety)
        with dst:
            src.backup(dst)
        dst.close(); src.close()
        os.replace(temp_path, DB)
        init_db()
        c=db(); audit_log(c, "Restore", "Backup & Restore", target_type="Backup", target_id=uploaded.filename, details={"file": uploaded.filename, "safety_backup": os.path.basename(safety)}) ; c.commit(); c.close()
        flash("Database restored successfully. Please refresh the page.", "ok")
    except Exception as exc:
        try:
            if os.path.exists(temp_path): os.remove(temp_path)
        except OSError:
            pass
        flash(f"Restore failed: {exc}", "error")
    return redirect(url_for("data_management"))

@app.route("/folders/create",methods=["POST"])
def create_folder():
    if not session.get("user") or session.get("inventory_role") != "Admin": return redirect(url_for("home"))
    name=request.form["name"].strip()
    description=request.form.get("description","").strip()
    if not name:
        flash("Folder name is required.","error")
        return redirect(url_for("home"))
    try:
        c=db()
        cur=c.execute("INSERT INTO dashboard_folders(name,description) VALUES(?,?)",(name,description))
        audit_log(c, "Create", "Folder Management", target_type="Folder", target_id=cur.lastrowid, details={"name": name, "description": description})
        c.commit(); c.close()
        flash("Folder created successfully.","ok")
    except sqlite3.IntegrityError:
        flash("A folder with this name already exists.","error")
    return redirect(url_for("home"))

@app.route("/folders/delete/<int:folder_id>",methods=["POST"])
def delete_folder(folder_id):
    if not session.get("user") or session.get("inventory_role") != "Admin": return redirect(url_for("home"))
    c=db(); target=c.execute("SELECT name,description FROM dashboard_folders WHERE id=?",(folder_id,)).fetchone(); c.close()
    if not target:
        flash("Folder not found.","error"); return redirect(url_for("data_management"))
    try:
        safety=create_safety_backup(f"folder_{folder_id}")
        c=db()
        c.execute("DELETE FROM dashboard_folders WHERE id=?",(folder_id,))
        audit_log(c, "Delete", "Folder Management", target_type="Folder", target_id=folder_id, details={"name": target["name"], "description": target["description"], "safety_backup": safety})
        c.commit(); c.close()
        flash(f"Folder deleted safely. Recovery backup created: {safety}","ok")
    except Exception as exc:
        flash(f"Delete cancelled because safety backup could not be created: {exc}","error")
    return redirect(url_for("data_management"))

@app.route("/folders/edit/<int:folder_id>",methods=["POST"])
def edit_folder(folder_id):
    if not session.get("user") or session.get("inventory_role") != "Admin": return redirect(url_for("home"))
    name=request.form["name"].strip()
    description=request.form.get("description","").strip()
    try:
        c=db(); old_folder=c.execute("SELECT name,description FROM dashboard_folders WHERE id=?",(folder_id,)).fetchone()
        c.execute("UPDATE dashboard_folders SET name=?, description=? WHERE id=?",(name,description,folder_id))
        if old_folder:
            audit_log(c, "Edit", "Folder Management", target_type="Folder", target_id=folder_id, details={"old": {"name": old_folder["name"], "description": old_folder["description"]}, "new": {"name": name, "description": description}})
        c.commit(); c.close()
        flash("Folder updated.","ok")
    except sqlite3.IntegrityError:
        flash("A folder with this name already exists.","error")
    return redirect(url_for("home"))


@app.route("/folder/<int:folder_id>")
def folder_view(folder_id):
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    folder=c.execute("SELECT * FROM dashboard_folders WHERE id=?",(folder_id,)).fetchone()
    if not folder:
        c.close(); flash("Folder not found.","error"); return redirect(url_for("home"))
    fields=c.execute("SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id",(folder_id,)).fetchall()
    entries=c.execute("SELECT * FROM inventory_entries WHERE folder_id=? ORDER BY id DESC",(folder_id,)).fetchall()
    type_field=None
    for f in fields:
        n=normalize_field_name(f["field_name"])
        if n in {"assettype","type","category","assetcategory"}: type_field=f; break
    type_options=[]
    if type_field:
        type_options=sorted({str(r["value"]).strip() for r in c.execute("SELECT value FROM entry_values WHERE field_id=? AND trim(value)<>''",(type_field["id"],)).fetchall() if str(r["value"]).strip()}, key=str.casefold)
    entry_data=[]
    for e in entries:
        vals={r["field_id"]:r["value"] for r in c.execute("SELECT field_id,value FROM entry_values WHERE entry_id=?",(e["id"],)).fetchall()}
        entry_data.append({"entry":e,"vals":vals})
    in_stock=sum(1 for e in entries if str(e["status"] or "").strip().casefold()=="in stock")
    in_used=sum(1 for e in entries if str(e["status"] or "").strip().casefold() in {"in used","assigned/in use","in use"})
    selected_status=request.args.get("status","").strip()
    selected_type=request.args.get("type","").strip()
    # Normalize the two URL filters for the initial page state.  The client-side
    # filter remains available for instant search/filter changes without reload.
    if selected_status:
        wanted=selected_status.casefold()
        entry_data=[x for x in entry_data if str(x["entry"]["status"] or "").strip().casefold()==wanted or (wanted in {"in use","in used","assigned/in use"} and str(x["entry"]["status"] or "").strip().casefold() in {"in use","in used","assigned/in use"})]
    if selected_type and type_field:
        wanted=selected_type.strip().casefold()
        entry_data=[x for x in entry_data if str(x["vals"].get(type_field["id"],"")).strip().casefold()==wanted]
    c.close()
    return render_template("folder.html",folder=folder,fields=fields,entries=entry_data,in_stock=in_stock,in_used=in_used,total_entries=len(entries),type_field=type_field,type_options=type_options,selected_status=selected_status,selected_type=selected_type)

@app.route("/folder/<int:folder_id>/master",methods=["GET","POST"])
def folder_master(folder_id):
    if not session.get("user") or session.get("inventory_role") != "Admin": return redirect(url_for("home"))
    c=db()
    folder=c.execute("SELECT * FROM dashboard_folders WHERE id=?",(folder_id,)).fetchone()
    if not folder:
        c.close(); flash("Folder not found.","error"); return redirect(url_for("home"))
    if request.method=="POST":
        field_name=request.form.get("field_name","").strip()
        field_type=request.form.get("field_type","text")
        required=1 if request.form.get("required") else 0
        options=request.form.get("options","").strip()
        if not field_name:
            c.close(); flash("Field name is required.","error"); return redirect(url_for("folder_master",folder_id=folder_id))
        if field_type not in ("text","number","date","dropdown"):
            field_type="text"
        cur=c.execute("INSERT INTO folder_fields(folder_id,field_name,field_type,required,options) VALUES(?,?,?,?,?)",
                  (folder_id,field_name,field_type,required,options))
        audit_log(c, "Create", "Field Master", target_type="Field", target_id=cur.lastrowid, details={"folder_id": folder_id, "field_name": field_name, "field_type": field_type, "required": bool(required)})
        c.commit(); c.close()
        flash("Field added to the entry master.","ok")
        return redirect(url_for("folder_master",folder_id=folder_id))
    fields=c.execute("SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id",(folder_id,)).fetchall()
    c.close()
    return render_template("folder_master.html",folder=folder,fields=fields)

@app.route("/folder/<int:folder_id>/master/edit/<int:field_id>",methods=["POST"])
def edit_field(folder_id,field_id):
    if not session.get("user") or session.get("inventory_role") != "Admin": return redirect(url_for("home"))
    field_name=request.form.get("field_name","").strip()
    field_type=request.form.get("field_type","text")
    required=1 if request.form.get("required") else 0
    options=request.form.get("options","").strip()
    c=db()
    old_field=c.execute("SELECT field_name,field_type,required,options FROM folder_fields WHERE id=? AND folder_id=?",(field_id,folder_id)).fetchone()
    c.execute("UPDATE folder_fields SET field_name=?,field_type=?,required=?,options=? WHERE id=? AND folder_id=?",
              (field_name,field_type,required,options,field_id,folder_id))
    if old_field:
        audit_log(c, "Edit", "Field Master", target_type="Field", target_id=field_id, details={"folder_id": folder_id, "old": dict(old_field), "new": {"field_name": field_name, "field_type": field_type, "required": required, "options": options}})
    c.commit(); c.close()
    flash("Field updated.","ok")
    return redirect(url_for("folder_master",folder_id=folder_id))

@app.route("/folder/<int:folder_id>/master/delete/<int:field_id>",methods=["POST"])
def delete_field(folder_id,field_id):
    if not session.get("user") or session.get("inventory_role") != "Admin": return redirect(url_for("home"))
    c=db(); target=c.execute("SELECT field_name,field_type,required FROM folder_fields WHERE id=? AND folder_id=?",(field_id,folder_id)).fetchone(); c.close()
    if not target:
        flash("Field not found.","error"); return redirect(url_for("folder_master",folder_id=folder_id))
    try:
        safety=create_safety_backup(f"field_{field_id}")
        c=db()
        c.execute("DELETE FROM folder_fields WHERE id=? AND folder_id=?",(field_id,folder_id))
        audit_log(c, "Delete", "Field Master", target_type="Field", target_id=field_id, details={"folder_id": folder_id, "field_name": target["field_name"], "field_type": target["field_type"], "required": target["required"], "safety_backup": safety})
        c.commit(); c.close()
        flash(f"Field deleted safely. Recovery backup created: {safety}","ok")
    except Exception as exc:
        flash(f"Delete cancelled because safety backup could not be created: {exc}","error")
    return redirect(url_for("folder_master",folder_id=folder_id))


LAN_IP_FIELD_NAMES = {
    "lanip", "lanipaddress", "ipaddress", "ipv4", "ipv4address", "ip"
}

LAN_IP_HINTS = ("lanip", "ipaddress", "ipv4", "networkip")

def is_lan_ip_field(field_name):
    """Return True for LAN/IP field names regardless of spaces/case/punctuation.
    Also accepts practical variants such as "IP", "IP Address (LAN)" and
    "LAN IP Address" so the rule continues to work with imported/custom fields.
    """
    normalized = re.sub(r"[^a-z0-9]", "", (field_name or "").lower())
    if normalized in LAN_IP_FIELD_NAMES:
        return True
    if any(hint in normalized for hint in LAN_IP_HINTS):
        return True
    return normalized.startswith("lan") and "ip" in normalized

def get_lan_network(c):
    row = c.execute(
        "SELECT value FROM system_settings WHERE key='lan_network'"
    ).fetchone()
    # Inventory LAN/IP management is based on the normal 192.168.1.x LAN
    # unless the Admin explicitly changes the network in IP Management.
    # Older bundled databases may contain the previous 192.168.0.x default;
    # keep the current project default consistent with the actual inventory.
    value = (row["value"] or "").strip() if row else ""
    if not value:
        return "192.168.1.0/24"
    return value

# Common asset identity fields that should be unique across the inventory.
# Matching is case/space/punctuation insensitive so "Serial No" and
# "Serial Number" are treated as the same identity category.
ASSET_ID_FIELD_NAMES = {
    "assetid", "assetno", "assetnumber", "assettag", "assetcode",
    "inventoryid", "inventoryno", "inventorynumber",
    "serial", "serialno", "serialnumber",
    "servicetag", "serviceno", "servicenumber", "servicecode"
}

def normalize_field_name(field_name):
    return re.sub(r"[^a-z0-9]", "", (field_name or "").lower())

def identity_field_type(field_name):
    """Return the uniqueness category for asset identity fields."""
    n = normalize_field_name(field_name)
    if n in ASSET_ID_FIELD_NAMES:
        if n.startswith("serial"):
            return "Serial Number"
        if n.startswith("service"):
            return "Service Tag"
        return "Asset ID"
    return None

def validate_asset_identity_value(c, field_name, value, exclude_entry_id=None):
    """Prevent duplicate asset/serial/service identifiers across all folders."""
    value = (value or "").strip()
    category = identity_field_type(field_name)
    if not value or not category:
        return True, ""

    # Identity values are compared case-insensitively and with surrounding
    # whitespace ignored. This prevents duplicates such as "abc123" / "ABC123".
    normalized_value = value.casefold()
    rows = c.execute("""
        SELECT ev.entry_id, ev.value, ie.folder_id, df.name AS folder_name,
               ff.field_name
        FROM entry_values ev
        JOIN inventory_entries ie ON ie.id = ev.entry_id
        JOIN dashboard_folders df ON df.id = ie.folder_id
        JOIN folder_fields ff ON ff.id = ev.field_id
        WHERE trim(ev.value) <> ''
    """).fetchall()

    for r in rows:
        if exclude_entry_id is not None and int(r["entry_id"]) == int(exclude_entry_id):
            continue
        if identity_field_type(r["field_name"]) != category:
            continue
        if (r["value"] or "").strip().casefold() == normalized_value:
            return False, (
                f"Duplicate {category.lower()} '{value}' found in "
                f"'{r['folder_name']}' ({r['field_name']}, entry #{r['entry_id']}). "
                "Use a unique value."
            )
    return True, ""


def get_lan_ip_fields(c):
    """Find LAN/IP fields in every folder, not only the current folder."""
    rows = c.execute(
        "SELECT id, folder_id, field_name FROM folder_fields ORDER BY folder_id, id"
    ).fetchall()
    return [r for r in rows if is_lan_ip_field(r["field_name"])]

def validate_lan_ip_value(c, value, exclude_entry_id=None):
    """
    Validate an IP entered in any LAN/IP field and prevent duplicate
    assignment across the entire inventory, including different folders.
    Returns (ok, message).
    """
    value = (value or "").strip()
    if not value:
        return True, ""

    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        return False, f"Invalid IP address: {value}"

    if ip.version != 4:
        return False, "Only IPv4 LAN addresses are allowed."

    try:
        network = ipaddress.ip_network(get_lan_network(c), strict=False)
    except ValueError:
        network = ipaddress.ip_network("192.168.1.0/24")

    if ip not in network:
        return False, f"{value} is outside the configured LAN network {network}."

    # .0/network and .255/broadcast are not assignable for a normal IPv4 subnet.
    if ip == network.network_address or ip == network.broadcast_address:
        return False, f"{value} is a network/broadcast address and cannot be assigned."

    query = """
        SELECT ev.entry_id, ev.value, ie.folder_id, df.name AS folder_name,
               ff.field_name
        FROM entry_values ev
        JOIN inventory_entries ie ON ie.id = ev.entry_id
        JOIN dashboard_folders df ON df.id = ie.folder_id
        JOIN folder_fields ff ON ff.id = ev.field_id
        WHERE trim(ev.value) <> ''
    """
    rows = c.execute(query).fetchall()

    for r in rows:
        if exclude_entry_id is not None and int(r["entry_id"]) == int(exclude_entry_id):
            continue
        if not is_lan_ip_field(r["field_name"]):
            continue
        try:
            existing = ipaddress.ip_address((r["value"] or "").strip())
        except ValueError:
            continue
        if existing == ip:
            return False, (
                f"IP address {value} is already assigned to "
                f"'{r['folder_name']}' ({r['field_name']}, entry #{r['entry_id']})."
            )

    # Rental printers are also LAN devices. Their IPs must obey the same
    # network-range and duplicate rule as inventory assets.
    try:
        rental_rows = c.execute(
            "SELECT id, printer_id, printer_name, lan_ip FROM rental_printers WHERE trim(lan_ip)<>''"
        ).fetchall()
        for rp in rental_rows:
            try:
                existing = ipaddress.ip_address((rp["lan_ip"] or "").strip())
            except ValueError:
                continue
            if existing == ip:
                return False, (
                    f"IP address {value} is already assigned to rental printer "
                    f"'{rp['printer_id']}' ({rp['printer_name'] or 'Printer'})."
                )
    except sqlite3.OperationalError:
        # Older databases may not have rental printer tables yet.
        pass

    return True, ""


@app.route("/folder/<int:folder_id>/excel-template")
def excel_template(folder_id):
    if not session.get("user") or not permissions_for("new_entry"):
        return redirect(url_for("home"))

    c = db()
    try:
        folder = c.execute("SELECT * FROM dashboard_folders WHERE id=?", (folder_id,)).fetchone()
        fields = c.execute(
            "SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id", (folder_id,)
        ).fetchall()
        if not folder:
            flash("Folder not found.", "error")
            return redirect(url_for("home"))

        wb = Workbook()
        ws = wb.active
        ws.title = "Import Template"

        headers = [f["field_name"] for f in fields] + ["Status"]
        ws.append(headers)

        # Keep the template clean and easy to fill in.
        for cell in ws[1]:
            cell.font = cell.font.copy(bold=True)
            cell.alignment = cell.alignment.copy(horizontal="center")

        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for col in ws.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max(max_len + 3, 14), 35)

        # Add a simple instructions sheet so users know exactly what to enter.
        info = wb.create_sheet("Instructions")
        info.append(["Field", "Type", "Required", "Notes"])
        for cell in info[1]:
            cell.font = cell.font.copy(bold=True)
        for f in fields:
            note = "LAN/IP must be a valid, unused address in the configured LAN network." if is_lan_ip_field(f["field_name"]) else "Enter the value in the format expected for this field."
            info.append([f["field_name"], f["field_type"], "Yes" if f["required"] else "No", note])
        info.append(["Status", "system", "No", "Use: In Stock, Assigned/In Use, Under Repair, Returned, Retired, Disposed."])
        info.freeze_panes = "A2"
        info.column_dimensions["A"].width = 28
        info.column_dimensions["B"].width = 14
        info.column_dimensions["C"].width = 12
        info.column_dimensions["D"].width = 70

        from io import BytesIO
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        filename = re.sub(r"[^A-Za-z0-9_-]+", "_", folder["name"]).strip("_") or "Inventory"
        return send_file(output, as_attachment=True, download_name=f"{filename}_Import_Template.xlsx", mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    finally:
        c.close()

@app.route("/folder/<int:folder_id>/import-excel", methods=["POST"])
def import_excel(folder_id):
    if not session.get("user") or not permissions_for("new_entry"):
        return redirect(url_for("home"))

    upload = request.files.get("excel_file")
    if not upload or not upload.filename:
        flash("Please select an Excel file.", "error")
        return redirect(url_for("folder_view", folder_id=folder_id))

    if not upload.filename.lower().endswith((".xlsx", ".xlsm")):
        flash("Only .xlsx or .xlsm Excel files are supported.", "error")
        return redirect(url_for("folder_view", folder_id=folder_id))

    c = db()
    try:
        folder = c.execute("SELECT * FROM dashboard_folders WHERE id=?", (folder_id,)).fetchone()
        fields = c.execute(
            "SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id", (folder_id,)
        ).fetchall()

        if not folder:
            flash("Folder not found.", "error")
            return redirect(url_for("home"))
        if not fields:
            flash("Please configure the Field Master before importing Excel.", "error")
            return redirect(url_for("folder_view", folder_id=folder_id))

        wb = load_workbook(upload, data_only=True)
        ws = wb.active

        # Exported files have the field names in row 1. Matching is
        # case/space/punctuation insensitive.
        def norm(value):
            return re.sub(r"[^a-z0-9]", "", str(value or "").strip().lower())

        headers = {}
        for col in range(1, ws.max_column + 1):
            h = ws.cell(1, col).value
            if h is not None:
                headers[norm(h)] = col

        field_cols = {}
        for f in fields:
            col = headers.get(norm(f["field_name"]))
            if col:
                field_cols[f["id"]] = col

        if not field_cols:
            flash("No Field Master columns matched this Excel file. Please use the Export Excel format.", "error")
            return redirect(url_for("folder_view", folder_id=folder_id))

        # Status is a system field, not a normal Field Master field.
        status_col = headers.get(norm("Status"))

        imported = 0
        skipped = 0
        errors = []

        for row_no in range(2, ws.max_row + 1):
            vals = {}
            has_data = False

            for f in fields:
                col = field_cols.get(f["id"])
                raw = ws.cell(row_no, col).value if col else None
                if raw is None:
                    value = ""
                elif hasattr(raw, "strftime") and not isinstance(raw, str):
                    value = raw.strftime("%d/%m/%Y")
                else:
                    value = str(raw).strip()
                vals[f["id"]] = value
                if value:
                    has_data = True

            if not has_data:
                continue

            missing = [
                f["field_name"] for f in fields
                if f["required"] and not vals.get(f["id"], "")
            ]
            if missing:
                skipped += 1
                errors.append(f"Row {row_no}: required field missing - {', '.join(missing)}")
                continue

            # Same LAN/IP validation used by manual entry.
            invalid = False
            for f in fields:
                value = vals.get(f["id"], "")
                if is_lan_ip_field(f["field_name"]) and value:
                    ok, message = validate_lan_ip_value(c, value)
                    if not ok:
                        skipped += 1
                        errors.append(f"Row {row_no}: {message}")
                        invalid = True
                        break
            if invalid:
                continue

            # Prevent duplicate Asset ID / Serial Number / Service Tag values
            # across the complete inventory during Excel import.
            duplicate = False
            for f in fields:
                value = vals.get(f["id"], "")
                if value and identity_field_type(f["field_name"]):
                    ok, message = validate_asset_identity_value(c, f["field_name"], value)
                    if not ok:
                        skipped += 1
                        errors.append(f"Row {row_no}: {message}")
                        duplicate = True
                        break
            if duplicate:
                continue

            status = "In Stock"
            if status_col:
                raw_status = ws.cell(row_no, status_col).value
                if raw_status is not None and str(raw_status).strip() in LIFECYCLE_STATUSES:
                    status = str(raw_status).strip()

            cur = c.execute(
                "INSERT INTO inventory_entries(folder_id,created_by,status) VALUES(?,?,?)",
                (folder_id, session["user"], status)
            )
            entry_id = cur.lastrowid

            for f in fields:
                c.execute(
                    "INSERT INTO entry_values(entry_id,field_id,value) VALUES(?,?,?)",
                    (entry_id, f["id"], vals.get(f["id"], ""))
                )

            snapshot = entry_snapshot(c, entry_id, fields)
            save_history(c, entry_id, "Imported", session["user"], snapshot, [])
            ensure_metadata(c, entry_id)
            if status == "Disposed":
                ensure_ewaste_for_disposed(c, entry_id, request.form.get("disposal_reason", "").strip())
            imported += 1

        audit_log(c, "Import", "Excel Import", target_type="Folder", target_id=folder_id, details={"imported": imported, "skipped": skipped, "filename": upload.filename})
        c.commit()

        if errors:
            preview = " | ".join(errors[:5])
            extra = f" | +{len(errors)-5} more errors" if len(errors) > 5 else ""
            flash(f"Imported: {imported} | Skipped: {skipped} | {preview}{extra}",
                  "error" if skipped else "ok")
        else:
            flash(f"Excel import successful: {imported} record(s) added.", "ok")

        return redirect(url_for("folder_view", folder_id=folder_id))

    except Exception as exc:
        c.rollback()
        flash(f"Excel import failed: {exc}", "error")
        return redirect(url_for("folder_view", folder_id=folder_id))
    finally:
        c.close()

@app.route("/folder/<int:folder_id>/entry",methods=["POST"])
def create_entry(folder_id):
    if not session.get("user") or not permissions_for("new_entry"):
        return redirect(url_for("home"))

    c = db()
    folder = c.execute(
        "SELECT * FROM dashboard_folders WHERE id=?", (folder_id,)
    ).fetchone()
    fields = c.execute(
        "SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id", (folder_id,)
    ).fetchall()

    if not folder:
        c.close()
        flash("Folder not found.", "error")
        return redirect(url_for("home"))

    missing = []
    submitted = {}
    for f in fields:
        val = request.form.get("field_" + str(f["id"]), "").strip()
        submitted[f["id"]] = val
        if f["required"] and not val:
            missing.append(f["field_name"])

    if missing:
        c.close()
        flash("Please fill: " + ", ".join(missing), "error")
        return redirect(url_for("folder_view", folder_id=folder_id))

    # Validate every LAN/IP field before inserting anything.
    for f in fields:
        if is_lan_ip_field(f["field_name"]) and submitted[f["id"]]:
            ok, message = validate_lan_ip_value(c, submitted[f["id"]])
            if not ok:
                c.close()
                flash(message, "error")
                return redirect(url_for("folder_view", folder_id=folder_id))

    # Asset ID / Serial Number / Service Tag must be unique across all folders.
    for f in fields:
        value = submitted.get(f["id"], "")
        if value and identity_field_type(f["field_name"]):
            ok, message = validate_asset_identity_value(c, f["field_name"], value)
            if not ok:
                c.close()
                flash(message, "error")
                return redirect(url_for("folder_view", folder_id=folder_id))

    status = request.form.get("entry_status", "In Stock")
    if status not in LIFECYCLE_STATUSES:
        status = "In Stock"

    cur = c.execute(
        "INSERT INTO inventory_entries(folder_id,created_by,status) VALUES(?,?,?)",
        (folder_id, session["user"], status)
    )
    entry_id = cur.lastrowid

    for f in fields:
        c.execute(
            "INSERT INTO entry_values(entry_id,field_id,value) VALUES(?,?,?)",
            (entry_id, f["id"], submitted[f["id"]])
        )

    snapshot = entry_snapshot(c, entry_id, fields)
    save_history(c, entry_id, "Created", session["user"], snapshot, [])
    audit_log(c, "Create", "Inventory Entry", target_type="Entry", target_id=entry_id, details={"folder_id": folder_id, "status": status})
    ensure_metadata(c, entry_id)
    mdvals={k:request.form.get(k,"").strip() for k in ["purchase_date","invoice_date","warranty_start","warranty_end","amc_details"]}
    c.execute("UPDATE asset_metadata SET purchase_date=?,invoice_date=?,warranty_start=?,warranty_end=?,amc_details=? WHERE entry_id=?",(mdvals["purchase_date"],mdvals["invoice_date"],mdvals["warranty_start"],mdvals["warranty_end"],mdvals["amc_details"],entry_id))
    if status == "Disposed": ensure_ewaste_for_disposed(c, entry_id, request.form.get("disposal_reason","").strip())
    if request.files.get("invoice_attachment") and request.files.get("invoice_attachment").filename: safe_upload(c, entry_id=entry_id, category="Invoice", field_name="invoice_attachment")
    c.execute("""CREATE TABLE IF NOT EXISTS consumable_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, category TEXT DEFAULT '', unit TEXT DEFAULT 'pcs',
        total_qty INTEGER NOT NULL DEFAULT 0, available_qty INTEGER NOT NULL DEFAULT 0,
        min_stock INTEGER NOT NULL DEFAULT 0, vendor TEXT DEFAULT '',
        purchase_price REAL NOT NULL DEFAULT 0, location TEXT DEFAULT '',
        notes TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
        created_by TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS consumable_transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL,
        txn_type TEXT NOT NULL, qty INTEGER NOT NULL, issued_to TEXT DEFAULT '',
        department TEXT DEFAULT '', ticket_no TEXT DEFAULT '', reason TEXT DEFAULT '',
        condition TEXT DEFAULT '', remarks TEXT DEFAULT '', changed_by TEXT NOT NULL,
        changed_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(item_id) REFERENCES consumable_items(id) ON DELETE CASCADE
    )""")
    c.execute("CREATE INDEX IF NOT EXISTS idx_consumable_txn_item_date ON consumable_transactions(item_id, changed_at DESC)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_consumable_item_stock ON consumable_items(active, available_qty, min_stock)")
    c.commit()
    c.close()

    flash("New inventory entry created successfully.", "ok")
    return redirect(url_for("folder_view", folder_id=folder_id))

def entry_snapshot(c, entry_id, fields=None):
    e=c.execute("SELECT * FROM inventory_entries WHERE id=?",(entry_id,)).fetchone()
    if not e: return None
    fields=fields or c.execute("SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id",(e["folder_id"],)).fetchall()
    values={r["field_id"]:r["value"] for r in c.execute("SELECT field_id,value FROM entry_values WHERE entry_id=?",(entry_id,)).fetchall()}
    # Store field names and values together so every historical version remains
    # understandable even if the Field Master changes later.
    field_data=[]
    for f in fields:
        field_data.append({
            "field_id": f["id"],
            "field_name": f["field_name"],
            "value": values.get(f["id"], "")
        })
    return {
        "entry_id": e["id"],
        "folder_id": e["folder_id"],
        "status": e["status"],
        "created_by": e["created_by"],
        "created_at": e["created_at"],
        "fields": field_data
    }

def client_context():
    ip = request.remote_addr or "Unknown"
    host = "Not resolved"
    if ip and ip not in ("Unknown", "127.0.0.1", "::1"):
        try:
            host = socket.gethostbyaddr(ip)[0]
        except Exception:
            host = "Not resolved"
    elif ip in ("127.0.0.1", "::1"):
        host = "Localhost"
    return ip, host

def save_history(c, entry_id, action, changed_by, snapshot, changes):
    version=(c.execute("SELECT COALESCE(MAX(version_no),0)+1 FROM entry_history WHERE entry_id=?",(entry_id,)).fetchone()[0])
    changed_ip, changed_host = client_context()
    c.execute("""INSERT INTO entry_history(
        entry_id,version_no,action,changed_by,snapshot_json,changes_json,changed_ip,changed_host
    ) VALUES(?,?,?,?,?,?,?,?)""",
              (entry_id,version,action,changed_by,json.dumps(snapshot, ensure_ascii=False),
               json.dumps(changes, ensure_ascii=False),changed_ip,changed_host))

# Record creation as Version 1
# (insert this call in create_entry after values are inserted)

@app.route("/folder/<int:folder_id>/entry/<int:entry_id>/edit",methods=["GET","POST"])
def edit_entry(folder_id, entry_id):
    if not session.get("user") or not permissions_for("edit"):
        return redirect(url_for("home"))

    c = db()
    entry = c.execute(
        "SELECT * FROM inventory_entries WHERE id=? AND folder_id=?",
        (entry_id, folder_id)
    ).fetchone()
    fields = c.execute(
        "SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id", (folder_id,)
    ).fetchall()

    if not entry:
        c.close()
        flash("Entry not found.", "error")
        return redirect(url_for("folder_view", folder_id=folder_id))

    vals = {
        r["field_id"]: r["value"]
        for r in c.execute(
            "SELECT field_id,value FROM entry_values WHERE entry_id=?", (entry_id,)
        ).fetchall()
    }

    if request.method == "POST":
        # Validate LAN/IP values BEFORE changing the database.
        for f in fields:
            if is_lan_ip_field(f["field_name"]):
                newval = request.form.get("field_" + str(f["id"]), "").strip()
                if newval:
                    ok, message = validate_lan_ip_value(
                        c, newval, exclude_entry_id=entry_id
                    )
                    if not ok:
                        c.close()
                        flash(message, "error")
                        return redirect(
                            url_for("edit_entry", folder_id=folder_id, entry_id=entry_id)
                        )

        # Prevent an edited Asset ID / Serial Number / Service Tag from
        # colliding with another inventory entry. The current entry is ignored.
        for f in fields:
            newval = request.form.get("field_" + str(f["id"]), "").strip()
            if newval and identity_field_type(f["field_name"]):
                ok, message = validate_asset_identity_value(
                    c, f["field_name"], newval, exclude_entry_id=entry_id
                )
                if not ok:
                    c.close()
                    flash(message, "error")
                    return redirect(
                        url_for("edit_entry", folder_id=folder_id, entry_id=entry_id)
                    )

        old = entry_snapshot(c, entry_id, fields)
        ensure_metadata(c, entry_id)
        old_md = metadata_row(c, entry_id)
        mdvals = {k: request.form.get(k, "").strip() for k in ["purchase_date","invoice_date","warranty_start","warranty_end","amc_details"]}
        mdchanges = [{"field":k.replace("_"," ").title(),"old":old_md[k] or "","new":v} for k,v in mdvals.items() if (old_md[k] or "") != v]
        c.execute("UPDATE asset_metadata SET purchase_date=?,invoice_date=?,warranty_start=?,warranty_end=?,amc_details=? WHERE entry_id=?", (mdvals["purchase_date"],mdvals["invoice_date"],mdvals["warranty_start"],mdvals["warranty_end"],mdvals["amc_details"],entry_id))
        status = request.form.get("entry_status", entry["status"])
        if status not in LIFECYCLE_STATUSES:
            status = entry["status"]

        changes = []
        if old["status"] != status:
            changes.append({
                "field": "Stock Status",
                "old": old["status"],
                "new": status
            })

        c.execute(
            "UPDATE inventory_entries SET status=? WHERE id=?", (status, entry_id)
        )
        ensure_metadata(c, entry_id)
        if status == "Disposed" and entry["status"] != "Disposed":
            ensure_ewaste_for_disposed(c, entry_id, request.form.get("disposal_reason", "").strip())

        for f in fields:
            newval = request.form.get("field_" + str(f["id"]), "").strip()
            oldval = vals.get(f["id"], "")
            if newval != oldval:
                changes.append({
                    "field": f["field_name"],
                    "old": oldval,
                    "new": newval
                })
            c.execute(
                """UPDATE entry_values SET value=?
                   WHERE entry_id=? AND field_id=?""",
                (newval, entry_id, f["id"])
            )

        repair_issue=request.form.get("repair_issue","").strip()
        if request.form.get("save_repair")=="1" and repair_issue:
            ip,host=client_context()
            c.execute("INSERT INTO repair_history(entry_id,repair_date,issue,action_taken,vendor,cost,result,remarks,created_by,client_ip,client_host) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(entry_id,request.form.get("repair_date","").strip() or datetime.now().strftime("%Y-%m-%d"),repair_issue,request.form.get("repair_action","").strip(),request.form.get("repair_vendor","").strip(),request.form.get("repair_cost","").strip(),request.form.get("repair_result","Completed").strip(),request.form.get("repair_remarks","").strip(),session["user"],ip,host))
            audit_log(c,"Repair","Repair History",target_type="Entry",target_id=entry_id,details={"issue":repair_issue})
            if request.files.get("repair_attachment") and request.files.get("repair_attachment").filename: safe_upload(c, entry_id=entry_id, category="Repair Document", field_name="repair_attachment")
            changes.append({"field":"Repair Record","old":"","new":repair_issue})
        changes.extend(mdchanges)
        if changes:
            snapshot = entry_snapshot(c, entry_id, fields)
            save_history(
                c, entry_id, "Edited", session["user"], snapshot, changes
            )
            audit_log(c, "Edit", "Inventory Entry", target_type="Entry", target_id=entry_id, details={"folder_id": folder_id, "changes": changes})
            flash("Entry updated. Version history saved.", "ok")
        else:
            flash("No changes were made.", "ok")

        if request.files.get("invoice_attachment") and request.files.get("invoice_attachment").filename:
            safe_upload(c, entry_id=entry_id, category="Invoice", field_name="invoice_attachment")
        c.commit()
        c.close()
        return redirect(url_for("folder_view", folder_id=folder_id))

    # Keep the database connection open while building all template context.
    # The previous build closed `c` before metadata/repair/e-waste queries,
    # which caused sqlite3.ProgrammingError: Cannot operate on a closed database.
    metadata = metadata_row(c, entry_id)
    repairs = c.execute(
        "SELECT * FROM repair_history WHERE entry_id=? ORDER BY repair_date DESC,id DESC LIMIT 10",
        (entry_id,)
    ).fetchall()
    ewaste = c.execute(
        "SELECT * FROM ewaste_records WHERE original_entry_id=? ORDER BY id DESC",
        (entry_id,)
    ).fetchall()
    c.close()
    return render_template(
        "edit_entry.html",
        folder=entry and {"id": folder_id},
        entry=entry,
        fields=fields,
        vals=vals,
        metadata=metadata,
        repairs=repairs,
        ewaste=ewaste
    )

@app.route("/folder/<int:folder_id>/entry/<int:entry_id>/history")
def entry_history(folder_id,entry_id):
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    entry=c.execute("SELECT * FROM inventory_entries WHERE id=? AND folder_id=?",(entry_id,folder_id)).fetchone()
    if not entry:
        c.close(); flash("Entry not found.","error"); return redirect(url_for("folder_view",folder_id=folder_id))
    fields=c.execute("SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id",(folder_id,)).fetchall()
    rows=c.execute("SELECT * FROM entry_history WHERE entry_id=? ORDER BY version_no DESC",(entry_id,)).fetchall()
    history=[]
    for r in rows:
        changes=json.loads(r["changes_json"] or "[]")
        snapshot=json.loads(r["snapshot_json"] or "{}")
        # New snapshots contain complete field name/value pairs. For older
        # records, gracefully fall back to the Field Master names available now.
        snapshot_rows=[]
        raw_fields=snapshot.get("fields", []) if isinstance(snapshot, dict) else []
        if isinstance(raw_fields, dict):
            field_map={str(f["id"]):f["field_name"] for f in fields}
            snapshot_rows=[{"field_id":k,"field_name":field_map.get(str(k), "Field #"+str(k)),"value":v} for k,v in raw_fields.items()]
        else:
            snapshot_rows=raw_fields
        history.append({
            "version":r["version_no"],
            "action":r["action"],
            "changed_by":r["changed_by"],
            "changed_at":r["changed_at"],
            "changed_ip":r["changed_ip"] if "changed_ip" in r.keys() else "",
            "changed_host":r["changed_host"] if "changed_host" in r.keys() else "",
            "status":snapshot.get("status", entry["status"]) if isinstance(snapshot, dict) else entry["status"],
            "created_by":snapshot.get("created_by", entry["created_by"]) if isinstance(snapshot, dict) else entry["created_by"],
            "created_at":snapshot.get("created_at", entry["created_at"]) if isinstance(snapshot, dict) else entry["created_at"],
            "fields":snapshot_rows,
            "changes":changes
        })
    c.close()
    return render_template("entry_history.html",entry=entry,fields=fields,history=history,folder_id=folder_id)


def _asset_profile_context(c, entry_id):
    e=c.execute("""SELECT ie.*,df.name AS folder_name FROM inventory_entries ie
                   JOIN dashboard_folders df ON df.id=ie.folder_id WHERE ie.id=?""",(entry_id,)).fetchone()
    if not e:
        return None
    vals=field_values(c,entry_id); md=metadata_row(c,entry_id)
    assignments=c.execute("SELECT * FROM asset_assignments WHERE entry_id=? ORDER BY id DESC",(entry_id,)).fetchall()
    hist=c.execute("SELECT * FROM entry_history WHERE entry_id=? ORDER BY version_no DESC",(entry_id,)).fetchall()
    pm_schedule=c.execute("SELECT * FROM pm_schedules WHERE entry_id=?",(entry_id,)).fetchone()
    pm_history=c.execute("SELECT * FROM pm_history WHERE schedule_id=? ORDER BY id DESC LIMIT 5",(pm_schedule["id"],)).fetchall() if pm_schedule else []
    audits=c.execute("""SELECT * FROM audit_log WHERE target_type IN ('Entry','Asset') AND target_id=? ORDER BY id DESC LIMIT 50""",(entry_id,)).fetchall()
    attachments=c.execute("SELECT * FROM entry_attachments WHERE entry_id=? ORDER BY id DESC",(entry_id,)).fetchall()
    ew=c.execute("SELECT * FROM ewaste_records WHERE original_entry_id=? ORDER BY id DESC",(entry_id,)).fetchall()
    repairs=c.execute("SELECT * FROM repair_history WHERE entry_id=? ORDER BY repair_date DESC,id DESC",(entry_id,)).fetchall()
    norm={re.sub(r"[^a-z0-9]","",str(v["field_name"]).lower()): v["value"] for v in vals}
    def pick(*names):
        for name in names:
            key=re.sub(r"[^a-z0-9]","",name.lower())
            if norm.get(key): return norm[key]
        return ""
    current_assignment=assignments[0] if assignments else None
    profile={
        "itd_tag":pick("ITD TAG","Asset Tag","Asset ID","Asset No","Asset Number"),
        "computer_name":pick("Computer Name","Device Name","PC Name"),
        "hostname":pick("Host Name","Hostname"),
        "lan_ip":pick("LAN IP","LAN IP Address","IP Address","IPv4"),
        "serial":pick("Service Tag","Serial Number","Serial No","Serial"),
        "user":(current_assignment["assigned_to"] if current_assignment and current_assignment["assigned_to"] else pick("User Name","Assigned User","Employee","User")),
        "department":(current_assignment["department"] if current_assignment and current_assignment["department"] else pick("Department")),
        "location":(current_assignment["location"] if current_assignment and current_assignment["location"] else pick("Location")),
        "model":pick("Model"), "vendor":pick("Vendor"), "processor":pick("Processor"),
        "ram":pick("RAM"), "ram_speed":pick("RAM Speed"), "ram_slot":pick("RAM Slot"),
        "hard_disk":pick("Hard Disk"), "operating_system":pick("Installed Operating System","Operating System","OS"),
        "office":pick("Office"), "office_key":pick("Office Key"), "monitor_sn":pick("Monitor S/N","Monitor SN"),
        "notes":pick("Notes","Remarks","Remarks / Notes")
    }
    return dict(entry=e,fields=vals,metadata=md,assignments=assignments,history=hist,audits=audits,attachments=attachments,ewaste=ew,repairs=repairs,warranty_state=warranty_state(md["warranty_end"]),pm_schedule=pm_schedule,pm_history=pm_history,profile=profile)

@app.route("/asset-profile")
def asset_profile_index():
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    entries=c.execute("SELECT ie.*,df.name AS folder_name FROM inventory_entries ie JOIN dashboard_folders df ON df.id=ie.folder_id ORDER BY ie.id DESC").fetchall()
    selected_id=request.args.get("entry_id", type=int)
    if not selected_id and entries:
        selected_id=entries[0]["id"]
    context=_asset_profile_context(c, selected_id) if selected_id else None
    # Build a compact identity line for each asset in the selector without changing stored data.
    asset_list=[]
    for row in entries:
        vals=field_values(c,row["id"])
        norm={re.sub(r"[^a-z0-9]","",str(v["field_name"]).lower()): v["value"] for v in vals}
        identity=next((norm.get(k) for k in ("itdtag","assettag","assetid","assetno","assetnumber") if norm.get(k)),"")
        machine=next((norm.get(k) for k in ("computername","hostname","hostname","devicename","model") if norm.get(k)),"")
        hostname=next((norm.get(k) for k in ("hostname","hostname","host name") if norm.get(k)),"")
        assignments_for_asset=c.execute("SELECT assigned_to FROM asset_assignments WHERE entry_id=? ORDER BY id DESC LIMIT 1",(row["id"],)).fetchone()
        user_name=(assignments_for_asset["assigned_to"] if assignments_for_asset and assignments_for_asset["assigned_to"] else next((norm.get(k) for k in ("username","assigneduser","employee","user") if norm.get(k)),""))
        asset_list.append({"id":row["id"],"folder_name":row["folder_name"],"status":row["status"],"identity":identity or f"Asset #{row['id']}","machine":machine or row["folder_name"],"hostname":hostname,"user_name":user_name})
    in_use_count=sum(1 for a in asset_list if "use" in a["status"].lower())
    in_stock_count=sum(1 for a in asset_list if "stock" in a["status"].lower())
    c.close()
    if context:
        context["asset_list"]=asset_list
        context["selected_id"]=selected_id
        context["in_use_count"]=in_use_count
        context["in_stock_count"]=in_stock_count
    return render_template("asset_profile.html", **(context or {"entry":None,"fields":[],"metadata":{"purchase_date":"","warranty_start":"","warranty_end":"","amc_details":""},"assignments":[],"history":[],"audits":[],"attachments":[],"ewaste":[],"warranty_state":"Not Set","asset_list":asset_list,"selected_id":None}))

@app.route("/asset/<int:entry_id>/pm")
def asset_pm(entry_id):
    """Open Preventive Maintenance for this specific asset only.
    If PM is not configured, open setup for this asset; otherwise open Record PM.
    """
    if not session.get("user"):
        return redirect(url_for("login"))
    c = db()
    entry = c.execute("SELECT * FROM inventory_entries WHERE id=?", (entry_id,)).fetchone()
    if not entry:
        c.close()
        flash("Asset not found.", "error")
        return redirect(url_for("asset_profile_index"))
    sched = c.execute("SELECT id FROM pm_schedules WHERE entry_id=?", (entry_id,)).fetchone()
    c.close()
    if sched:
        return redirect(url_for("record_pm", schedule_id=sched["id"]))
    return redirect(url_for("setup_pm", entry_id=entry_id))

@app.route("/asset/<int:entry_id>")
def asset_profile(entry_id):
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    context=_asset_profile_context(c,entry_id)
    if not context:
        c.close(); flash("Asset not found.","error"); return redirect(url_for("asset_profile_index"))
    entries=c.execute("SELECT ie.*,df.name AS folder_name FROM inventory_entries ie JOIN dashboard_folders df ON df.id=ie.folder_id ORDER BY ie.id DESC").fetchall()
    asset_list=[]
    for row in entries:
        vals=field_values(c,row["id"])
        norm={re.sub(r"[^a-z0-9]","",str(v["field_name"]).lower()): v["value"] for v in vals}
        identity=next((norm.get(k) for k in ("itdtag","assettag","assetid","assetno","assetnumber") if norm.get(k)),"")
        machine=next((norm.get(k) for k in ("computername","hostname","devicename","model") if norm.get(k)),"")
        hostname=next((norm.get(k) for k in ("hostname","hostname","host name") if norm.get(k)),"")
        assignments_for_asset=c.execute("SELECT assigned_to FROM asset_assignments WHERE entry_id=? ORDER BY id DESC LIMIT 1",(row["id"],)).fetchone()
        user_name=(assignments_for_asset["assigned_to"] if assignments_for_asset and assignments_for_asset["assigned_to"] else next((norm.get(k) for k in ("username","assigneduser","employee","user") if norm.get(k)),""))
        asset_list.append({"id":row["id"],"folder_name":row["folder_name"],"status":row["status"],"identity":identity or f"Asset #{row['id']}","machine":machine or row["folder_name"],"hostname":hostname,"user_name":user_name})
    in_use_count=sum(1 for a in asset_list if "use" in a["status"].lower())
    in_stock_count=sum(1 for a in asset_list if "stock" in a["status"].lower())
    c.close()
    context["asset_list"]=asset_list; context["selected_id"]=entry_id; context["in_use_count"]=in_use_count; context["in_stock_count"]=in_stock_count
    return render_template("asset_profile.html",**context)

@app.route("/asset/<int:entry_id>/print")
def asset_profile_print(entry_id):
    """Dedicated print-only asset profile. It does not render the screen/sidebar DOM."""
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    context=_asset_profile_context(c,entry_id)
    if not context:
        c.close(); flash("Asset not found.","error"); return redirect(url_for("asset_profile_index"))
    c.close()
    return render_template("asset_profile_print.html", **context)

@app.route("/asset/<int:entry_id>/metadata",methods=["POST"])
def asset_metadata_update(entry_id):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db(); e=c.execute("SELECT folder_id FROM inventory_entries WHERE id=?",(entry_id,)).fetchone()
    if not e: c.close(); flash("Asset not found.","error"); return redirect(url_for("home"))
    old=metadata_row(c,entry_id)
    vals={k:request.form.get(k,"").strip() for k in ["purchase_date","invoice_date","warranty_start","warranty_end","amc_details"]}
    c.execute("""INSERT INTO asset_metadata(entry_id,purchase_date,invoice_date,warranty_start,warranty_end,amc_details)
                 VALUES(?,?,?,?,?,?) ON CONFLICT(entry_id) DO UPDATE SET purchase_date=excluded.purchase_date,invoice_date=excluded.invoice_date,warranty_start=excluded.warranty_start,warranty_end=excluded.warranty_end,amc_details=excluded.amc_details""",
              (entry_id,vals["purchase_date"],vals["invoice_date"],vals["warranty_start"],vals["warranty_end"],vals["amc_details"]))
    changes=[{"field":k,"old":old[k] or "","new":v} for k,v in vals.items() if (old[k] or "")!=v]
    if changes: audit_log(c,"Edit","Warranty / AMC",target_type="Entry",target_id=entry_id,details=changes)
    c.commit(); c.close(); flash("Warranty / AMC details updated.","ok"); return redirect(url_for("asset_profile",entry_id=entry_id))

@app.route("/asset/<int:entry_id>/assign",methods=["POST"])
def asset_assign(entry_id):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db(); e=c.execute("SELECT * FROM inventory_entries WHERE id=?",(entry_id,)).fetchone()
    if not e: c.close(); flash("Asset not found.","error"); return redirect(url_for("home"))
    assigned=request.form.get("assigned_to","").strip(); dept=request.form.get("department","").strip(); loc=request.form.get("location","").strip(); notes=request.form.get("notes","").strip()
    prev=c.execute("SELECT * FROM asset_assignments WHERE entry_id=? ORDER BY id DESC LIMIT 1",(entry_id,)).fetchone()
    action="Handover" if prev and (prev["assigned_to"]!=assigned or prev["department"]!=dept or prev["location"]!=loc) else "Assigned"
    ip,host=client_context()
    c.execute("""INSERT INTO asset_assignments(entry_id,assigned_to,department,location,action,notes,changed_by,changed_ip,changed_host)
                 VALUES(?,?,?,?,?,?,?,?,?)""",(entry_id,assigned,dept,loc,action,notes,session["user"],ip,host))
    audit_log(c,action,"Assignment / Handover",target_type="Entry",target_id=entry_id,
              details={"old_user":prev["assigned_to"] if prev else "","new_user":assigned,"old_department":prev["department"] if prev else "","new_department":dept,"old_location":prev["location"] if prev else "","new_location":loc,"notes":notes})
    if assigned:
        c.execute("UPDATE inventory_entries SET status='Assigned/In Use' WHERE id=? AND status NOT IN ('Disposed','Retired')",(entry_id,))
    c.commit(); c.close(); flash(("Handover" if action=="Handover" else "Assignment")+" saved.","ok"); return redirect(url_for("asset_profile",entry_id=entry_id))

@app.route("/asset/<int:entry_id>/attachment",methods=["POST"])
def asset_attachment(entry_id):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db(); e=c.execute("SELECT id FROM inventory_entries WHERE id=?",(entry_id,)).fetchone()
    if not e: c.close(); flash("Asset not found.","error"); return redirect(url_for("home"))
    category=request.form.get("category","Other")
    safe_upload(c,entry_id=entry_id,category=category); c.commit(); c.close()
    flash("Attachment uploaded.","ok"); return redirect(url_for("asset_profile",entry_id=entry_id))

@app.route("/attachment/<int:attachment_id>")
def download_attachment(attachment_id):
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); r=c.execute("SELECT * FROM entry_attachments WHERE id=?",(attachment_id,)).fetchone(); c.close()
    if not r or not os.path.isfile(os.path.join(UPLOAD_DIR,r["stored_name"])): return "Attachment not found",404
    return send_file(os.path.join(UPLOAD_DIR,r["stored_name"]),as_attachment=True,download_name=r["original_name"])


@app.route("/preventive-maintenance")
def preventive_maintenance():
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); rows=[]
    for e in computer_entries(c):
        vals=field_values(c,e["id"]); summary={r["field_name"]:r["value"] for r in vals if r["value"]}
        def pick(*names):
            wanted={re.sub(r"[^a-z0-9]","",n.lower()) for n in names}
            for k,v in summary.items():
                if re.sub(r"[^a-z0-9]","",k.lower()) in wanted and v: return v
            return ""
        label=pick("ITD TAG","Asset Tag","Computer Name","Hostname") or f"Asset #{e['id']}"
        sub=pick("Computer Name","HOST NAME","Hostname") or "Computer asset"
        itd_tag=pick("ITD TAG","Asset Tag","Asset ID","Asset No","Asset Number")
        hostname=pick("HOST NAME","Host Name","Hostname")
        user_name=pick("User Name","Assigned User","Employee","User")
        assigned=c.execute("SELECT assigned_to FROM asset_assignments WHERE entry_id=? ORDER BY id DESC LIMIT 1",(e["id"],)).fetchone()
        if assigned and assigned["assigned_to"]: user_name=assigned["assigned_to"]
        service_tag=pick("Service Tag","Serial Number","Serial No","Serial")
        ptype=pick("Preventive Maintenance Type","PM Type")
        sched=c.execute("SELECT * FROM pm_schedules WHERE entry_id=?",(e["id"],)).fetchone()
        if sched:
            d=dict(sched); ptype=d.get("pm_type") or ptype
            d.update(entry_id=e["id"],status=e["status"],label=label,sub=sub,itd_tag=itd_tag,hostname=hostname,user_name=user_name,service_tag=service_tag,pm_type=ptype,frequency_label=pm_frequency_label(ptype),state=pm_state(d.get("next_due_date"),ptype))
        else:
            d=dict(id=None,entry_id=e["id"],status=e["status"],label=label,sub=sub,itd_tag=itd_tag,hostname=hostname,user_name=user_name,service_tag=service_tag,pm_type=ptype,frequency_months=PM_FREQUENCY_MONTHS.get(ptype,0),frequency_label=pm_frequency_label(ptype),last_pm_date="",next_due_date="",notes="",state=(pm_state("",ptype) if ptype else "Not Set"))
        rows.append(d)
    due_soon=sum(r["state"]=="Due Soon" for r in rows); overdue=sum(r["state"]=="Overdue" for r in rows); scheduled=sum(r["state"]=="Scheduled" for r in rows)
    history_count=c.execute("SELECT COUNT(*) FROM pm_history").fetchone()[0]; c.close()
    return render_template("preventive_maintenance.html",schedules=rows,due_soon=due_soon,overdue=overdue,scheduled=scheduled,history_count=history_count,today=datetime.now().strftime("%Y-%m-%d"))

@app.route("/preventive-maintenance/setup/<int:entry_id>", methods=["GET"])
def setup_pm(entry_id):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db()
    e=c.execute("SELECT * FROM inventory_entries WHERE id=?",(entry_id,)).fetchone()
    if not e:
        c.close(); flash("Computer asset not found.","error"); return redirect(url_for("preventive_maintenance"))
    # Build a small asset profile for a clear PM setup screen.
    vals=c.execute("""SELECT ff.field_name, ev.value FROM entry_values ev
                      JOIN folder_fields ff ON ff.id=ev.field_id
                      WHERE ev.entry_id=? AND COALESCE(ev.value,'')<>''""",(entry_id,)).fetchall()
    summary={r["field_name"]:r["value"] for r in vals}
    def pick(*names):
        wanted={re.sub(r"[^a-z0-9]","",n.lower()) for n in names}
        for k,v in summary.items():
            if re.sub(r"[^a-z0-9]","",k.lower()) in wanted and v: return v
        return ""
    sched=c.execute("SELECT * FROM pm_schedules WHERE entry_id=?",(entry_id,)).fetchone()
    c.close()
    profile={
        "itd_tag":pick("ITD TAG","Asset Tag","Asset ID"),
        "computer_name":pick("Computer Name"),
        "hostname":pick("Host Name","Hostname"),
        "lan_ip":pick("LAN IP","IP Address","IPv4"),
        "serial":pick("Service Tag","Serial Number","Serial No","Serial"),
        "user":pick("User Name","Assigned User","Employee","User"),
        "department":pick("Department"),
        "location":pick("Location"),
    }
    return render_template("pm_setup.html", entry=e, profile=profile, schedule=sched,
                           pm_types=list(PM_FREQUENCY_MONTHS.keys()), today=datetime.now().strftime("%Y-%m-%d"))

@app.route("/preventive-maintenance/create", methods=["POST"])
def create_pm_schedule():
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    entry_id=request.form.get("entry_id",type=int); pm_type=request.form.get("pm_type","Other").strip()
    if pm_type not in PM_FREQUENCY_MONTHS: pm_type="Other"
    months=PM_FREQUENCY_MONTHS[pm_type]; last=request.form.get("last_pm_date","").strip(); next_due=""
    if months and last:
        try: next_due=add_months(last,months)
        except Exception: next_due=""
    if not entry_id: flash("Please select a computer asset.","error"); return redirect(url_for("preventive_maintenance"))
    c=db(); e=c.execute("SELECT id,folder_id FROM inventory_entries WHERE id=?",(entry_id,)).fetchone()
    if not e: c.close(); flash("Computer asset not found.","error"); return redirect(url_for("preventive_maintenance"))
    fields=c.execute("SELECT id,field_name FROM folder_fields WHERE folder_id=?",(e["folder_id"],)).fetchall()
    pm_field=next((f for f in fields if re.sub(r"[^a-z0-9]","",f["field_name"].lower()) in ("preventivemaintenancetype","pmtype")),None)
    if pm_field:
        c.execute("DELETE FROM entry_values WHERE entry_id=? AND field_id=?",(entry_id,pm_field["id"]))
        c.execute("INSERT INTO entry_values(entry_id,field_id,value) VALUES(?,?,?)",(entry_id,pm_field["id"],pm_type))
    c.execute("""INSERT INTO pm_schedules(entry_id,pm_type,frequency_months,last_pm_date,next_due_date,notes,created_by,updated_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                 ON CONFLICT(entry_id) DO UPDATE SET pm_type=excluded.pm_type,frequency_months=excluded.frequency_months,last_pm_date=excluded.last_pm_date,next_due_date=excluded.next_due_date,notes=excluded.notes,updated_at=CURRENT_TIMESTAMP""",(entry_id,pm_type,months,last,next_due,request.form.get("notes","").strip(),session["user"]))
    audit_log(c,"Create/Update","Preventive Maintenance",target_type="Entry",target_id=entry_id,details={"pm_type":pm_type,"frequency_months":months,"last_pm_date":last,"next_due_date":next_due})
    c.commit(); c.close(); flash("Preventive Maintenance settings saved.","ok"); return redirect(url_for("preventive_maintenance"))

@app.route("/preventive-maintenance/<int:schedule_id>/record", methods=["GET"])
def record_pm(schedule_id):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db()
    srow=c.execute("""SELECT p.*,ie.status,ie.folder_id,df.name AS folder_name
                      FROM pm_schedules p JOIN inventory_entries ie ON ie.id=p.entry_id
                      JOIN dashboard_folders df ON df.id=ie.folder_id WHERE p.id=?""",(schedule_id,)).fetchone()
    if not srow:
        c.close(); flash("PM schedule not found.","error"); return redirect(url_for("preventive_maintenance"))
    vals=c.execute("""SELECT ff.field_name, ev.value FROM entry_values ev
                     JOIN folder_fields ff ON ff.id=ev.field_id WHERE ev.entry_id=? AND COALESCE(ev.value,'')<>''""",(srow["entry_id"],)).fetchall()
    summary={r["field_name"]:r["value"] for r in vals}
    def pick(*names):
        wanted={re.sub(r"[^a-z0-9]","",n.lower()) for n in names}
        for k,v in summary.items():
            if re.sub(r"[^a-z0-9]","",k.lower()) in wanted and v: return v
        return ""
    profile={"itd_tag":pick("ITD TAG","Asset Tag","Asset ID"),"computer_name":pick("Computer Name"),
             "hostname":pick("Host Name","Hostname"),"lan_ip":pick("LAN IP","IP Address","IPv4"),
             "serial":pick("Service Tag","Serial Number","Serial No","Serial"),"user":pick("User Name","Assigned User","Employee","User"),
             "department":pick("Department"),"location":pick("Location")}
    c.close()
    return render_template("pm_record.html", schedule=srow, profile=profile, today=datetime.now().strftime("%Y-%m-%d"))

@app.route("/preventive-maintenance/<int:schedule_id>/complete", methods=["POST"])
def complete_pm(schedule_id):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    pm_date=request.form.get("pm_date","").strip() or datetime.now().strftime("%Y-%m-%d")
    if pm_date > datetime.now().strftime("%Y-%m-%d"):
        flash("PM Date cannot be in the future.","error"); return redirect(url_for("preventive_maintenance"))
    result=request.form.get("result","Completed").strip() or "Completed"
    remarks=request.form.get("remarks","").strip()
    c=db(); srow=c.execute("SELECT * FROM pm_schedules WHERE id=?",(schedule_id,)).fetchone()
    if not srow:
        c.close(); flash("PM schedule not found.","error"); return redirect(url_for("preventive_maintenance"))
    try: next_due=add_months(pm_date,srow["frequency_months"])
    except Exception: next_due=""
    c.execute("UPDATE pm_schedules SET last_pm_date=?,next_due_date=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(pm_date,next_due,schedule_id))
    pm_ip, pm_host = client_context()
    c.execute("""INSERT INTO pm_history(schedule_id,pm_date,pm_type,result,performed_by,remarks,performed_ip,performed_host)
                 VALUES(?,?,?,?,?,?,?,?)""",(schedule_id,pm_date,srow["pm_type"],result,session["user"],remarks,pm_ip,pm_host))
    audit_log(c,"PM Completed","Preventive Maintenance",target_type="Entry",target_id=srow["entry_id"],
              details={"schedule_id":schedule_id,"pm_date":pm_date,"result":result,"next_due_date":next_due,"remarks":remarks})
    c.commit(); c.close(); flash(f"PM completed. Next PM due: {next_due or 'Not set'}.","ok")
    return redirect(url_for("preventive_maintenance"))

@app.route("/preventive-maintenance/<int:schedule_id>/history")
def pm_history(schedule_id):
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    srow=c.execute("""SELECT p.*,ie.status,ie.folder_id,df.name AS folder_name
                      FROM pm_schedules p
                      JOIN inventory_entries ie ON ie.id=p.entry_id
                      JOIN dashboard_folders df ON df.id=ie.folder_id
                      WHERE p.id=?""",(schedule_id,)).fetchone()
    if not srow:
        c.close(); flash("PM schedule not found.","error"); return redirect(url_for("preventive_maintenance"))
    vals=field_values(c,srow["entry_id"])
    summary={r["field_name"]:r["value"] for r in vals if r["value"]}
    def pick(*names):
        wanted={re.sub(r"[^a-z0-9]","",n.lower()) for n in names}
        for k,v in summary.items():
            if re.sub(r"[^a-z0-9]","",k.lower()) in wanted and v: return v
        return ""
    profile={
        "itd_tag":pick("ITD TAG","Asset Tag","Asset ID","Asset Number"),
        "computer_name":pick("Computer Name","Computer"),
        "hostname":pick("Host Name","Hostname","Host"),
        "lan_ip":pick("LAN IP","LAN IP Address","IP Address","IPv4","IPv4 Address"),
        "serial":pick("Serial Number","Serial No","Serial","Service Tag","Service Tags"),
        "user":pick("User Name","Assigned User","Assigned To","Employee","User"),
        "department":pick("Department"),
        "location":pick("Location","Asset Location"),
        "model":pick("Model"),
        "vendor":pick("Vendor","Manufacturer"),
    }
    assignment=c.execute("SELECT * FROM asset_assignments WHERE entry_id=? ORDER BY id DESC LIMIT 1",(srow["entry_id"],)).fetchone()
    if assignment:
        profile["user"]=profile["user"] or assignment["assigned_to"]
        profile["department"]=profile["department"] or assignment["department"]
        profile["location"]=profile["location"] or assignment["location"]
    audits=c.execute("SELECT * FROM audit_log WHERE target_id=? AND target_type IN ('Entry','Asset') AND module='Preventive Maintenance' ORDER BY id DESC LIMIT 50",(srow["entry_id"],)).fetchall()
    hist=c.execute("SELECT * FROM pm_history WHERE schedule_id=? ORDER BY pm_date DESC,id DESC",(schedule_id,)).fetchall()
    c.close()
    return render_template("pm_history.html",schedule=srow,history=hist,pm_state=pm_state(srow["next_due_date"],srow["pm_type"]),profile=profile,audits=audits)

@app.route("/ewaste")
def ewaste_list():
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); rows=c.execute("""SELECT er.*,df.name AS folder_name FROM ewaste_records er
                             LEFT JOIN dashboard_folders df ON df.id=er.source_folder_id ORDER BY er.id DESC""").fetchall()
    fields=c.execute("SELECT * FROM ewaste_fields ORDER BY id").fetchall()
    c.close(); return render_template("ewaste.html",records=rows,fields=fields)

@app.route("/ewaste/create",methods=["POST"])
def ewaste_create():
    if not session.get("user") or not permissions_for("new_entry"): return redirect(url_for("home"))
    c=db(); fields=c.execute("SELECT * FROM ewaste_fields ORDER BY id").fetchall()
    data={}
    missing=[]
    for f in fields:
        v=request.form.get("field_"+str(f["id"]),"").strip(); data[f["field_name"]]=v
        if f["required"] and not v: missing.append(f["field_name"])
    if missing: c.close(); flash("Please fill: "+", ".join(missing),"error"); return redirect(url_for("ewaste_list"))
    cur=c.execute("""INSERT INTO ewaste_records(original_entry_id,source_folder_id,auto_created,disposal_date,disposal_reason,created_by,data_json)
                     VALUES(NULL,NULL,0,?,?,?,?)""",(request.form.get("disposal_date","").strip(),request.form.get("disposal_reason","").strip(),session["user"],json.dumps(data,ensure_ascii=False)))
    eid=cur.lastrowid; save_ewaste_history(c,eid,"Created",[]); audit_log(c,"Create","E-Waste",target_type="E-Waste",target_id=eid,details={"manual":True})
    c.commit(); c.close(); flash("Manual E-Waste record created.","ok"); return redirect(url_for("ewaste_list"))

@app.route("/ewaste/export/excel")
def ewaste_export_excel():
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); rows=c.execute("SELECT er.*,df.name AS folder_name FROM ewaste_records er LEFT JOIN dashboard_folders df ON df.id=er.source_folder_id ORDER BY er.id DESC").fetchall(); wb=Workbook(); ws=wb.active; ws.title="E-Waste Register"; ws.append(["ID","Type","Original Asset","Source Folder","Disposal Date","Reason","Created By","Created At"])
    for r in rows: ws.append([r["id"],"Automatic" if r["auto_created"] else "Manual",r["original_entry_id"] or "",r["folder_name"] or "Manual",r["disposal_date"],r["disposal_reason"],r["created_by"],r["created_at"]])
    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
    from io import BytesIO
    out=BytesIO(); wb.save(out); out.seek(0); c.close(); return send_file(out,as_attachment=True,download_name="E_Waste_Register.xlsx",mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@app.route("/ewaste/export/pdf")
def ewaste_export_pdf():
    if not session.get("user"): return redirect(url_for("login"))
    if not REPORTLAB_AVAILABLE: flash("Install reportlab from requirements.txt for PDF export.","error"); return redirect(url_for("ewaste_list"))
    c=db(); rows=c.execute("SELECT er.*,df.name AS folder_name FROM ewaste_records er LEFT JOIN dashboard_folders df ON df.id=er.source_folder_id ORDER BY er.id DESC").fetchall(); c.close()
    from io import BytesIO
    out=BytesIO(); doc=SimpleDocTemplate(out,pagesize=landscape(A4),rightMargin=18,leftMargin=18,topMargin=18,bottomMargin=18); styles=getSampleStyleSheet(); story=[Paragraph("E-Waste / Disposal Register",styles["Title"]),Spacer(1,8)]
    data=[["ID","Type","Asset","Source","Disposal Date","Reason","Created By"]]+[[str(r["id"]),"Automatic" if r["auto_created"] else "Manual",str(r["original_entry_id"] or "—"),str(r["folder_name"] or "Manual"),str(r["disposal_date"] or "—"),str(r["disposal_reason"] or "—"),str(r["created_by"] or "—")] for r in rows]
    tbl=Table(data,repeatRows=1,colWidths=[35,65,65,110,75,300,80]); tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#163b68")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),7),("GRID",(0,0),(-1,-1),.3,colors.HexColor("#d8e0ea")),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story.append(tbl); doc.build(story); out.seek(0); return send_file(out,as_attachment=True,download_name="E_Waste_Register.pdf",mimetype="application/pdf")

@app.route("/ewaste/<int:eid>")
def ewaste_detail(eid):
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); e=c.execute("SELECT * FROM ewaste_records WHERE id=?",(eid,)).fetchone()
    if not e: c.close(); flash("E-Waste record not found.","error"); return redirect(url_for("ewaste_list"))
    hist=c.execute("SELECT * FROM ewaste_history WHERE ewaste_id=? ORDER BY version_no DESC",(eid,)).fetchall()
    atts=c.execute("SELECT * FROM entry_attachments WHERE ewaste_id=? ORDER BY id DESC",(eid,)).fetchall()
    source=c.execute("SELECT df.name FROM inventory_entries ie JOIN dashboard_folders df ON df.id=ie.folder_id WHERE ie.id=?",(e["original_entry_id"],)).fetchone() if e["original_entry_id"] else None
    c.close(); return render_template("ewaste_detail.html",record=e,history=hist,attachments=atts,source_folder=source["name"] if source else "Manual")

@app.route("/ewaste/<int:eid>/edit",methods=["POST"])
def ewaste_edit(eid):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db(); old=c.execute("SELECT * FROM ewaste_records WHERE id=?",(eid,)).fetchone()
    if not old: c.close(); flash("E-Waste record not found.","error"); return redirect(url_for("ewaste_list"))
    data=json.loads(old["data_json"] or "{}")
    fields=c.execute("SELECT * FROM ewaste_fields ORDER BY id").fetchall()
    changes=[]
    for key in list(data.keys()):
        if "data__"+key in request.form:
            nv=request.form.get("data__"+key,"").strip()
            if nv != data.get(key,""): changes.append({"field":key,"old":data.get(key,""),"new":nv})
            data[key]=nv
    for f in fields:
        v=request.form.get("field_"+str(f["id"]),data.get(f["field_name"],"")).strip()
        if v!=data.get(f["field_name"],""): changes.append({"field":f["field_name"],"old":data.get(f["field_name"],""),"new":v})
        data[f["field_name"]]=v
    disposal_date=request.form.get("disposal_date",old["disposal_date"]).strip()
    reason=request.form.get("disposal_reason",old["disposal_reason"]).strip()
    if disposal_date!=old["disposal_date"]: changes.append({"field":"Disposal Date","old":old["disposal_date"],"new":disposal_date})
    if reason!=old["disposal_reason"]: changes.append({"field":"Disposal Reason","old":old["disposal_reason"],"new":reason})
    c.execute("UPDATE ewaste_records SET disposal_date=?,disposal_reason=?,data_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(disposal_date,reason,json.dumps(data,ensure_ascii=False),eid))
    if changes: save_ewaste_history(c,eid,"Edited",changes); audit_log(c,"Edit","E-Waste",target_type="E-Waste",target_id=eid,details=changes)
    c.commit(); c.close(); flash("E-Waste updated; original inventory record remains safe.","ok"); return redirect(url_for("ewaste_detail",eid=eid))

@app.route("/ewaste/<int:eid>/attachment",methods=["POST"])
def ewaste_attachment(eid):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db(); safe_upload(c,ewaste_id=eid,category=request.form.get("category","Other")); c.commit(); c.close()
    flash("E-Waste attachment uploaded.","ok"); return redirect(url_for("ewaste_detail",eid=eid))

@app.route("/ewaste/master",methods=["GET","POST"])
def ewaste_master():
    if not session.get("user") or session.get("inventory_role")!="Admin": return redirect(url_for("home"))
    c=db()
    if request.method=="POST":
        name=request.form.get("field_name","").strip(); typ=request.form.get("field_type","text"); req=1 if request.form.get("required") else 0; opts=request.form.get("options","").strip()
        if not name: c.close(); flash("Field name is required.","error"); return redirect(url_for("ewaste_master"))
        cur=c.execute("INSERT INTO ewaste_fields(field_name,field_type,required,options) VALUES(?,?,?,?)",(name,typ,req,opts))
        audit_log(c,"Create","E-Waste Field Master",target_type="Field",target_id=cur.lastrowid,details={"field_name":name})
        c.commit()
    fields=c.execute("SELECT * FROM ewaste_fields ORDER BY id").fetchall(); c.close(); return render_template("ewaste_master.html",fields=fields)


@app.route("/inventory-store/reports")
def inventory_store_reports():
    if not session.get("user") or session.get("inventory_role") not in ["Admin","IT Admin"]:
        flash("Access denied.","error"); return redirect(url_for("inventory_store"))
    c=db(); item_filter=(request.args.get("item") or "").strip(); user_filter=(request.args.get("user") or "").strip()
    items=c.execute("SELECT * FROM consumable_items WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
    where=[]; params=[]
    if item_filter:
        where.append("t.item_id=?"); params.append(int(item_filter))
    if user_filter:
        where.append("t.issued_to LIKE ?"); params.append("%"+user_filter+"%")
    q="SELECT t.*,i.name item_name,i.category,i.unit FROM consumable_transactions t JOIN consumable_items i ON i.id=t.item_id"
    if where: q += " WHERE " + " AND ".join(where)
    q += " ORDER BY t.changed_at DESC,t.id DESC"
    tx=enrich_ticket_users(c.execute(q,params).fetchall())
    grouped=c.execute("SELECT t.item_id,t.issued_to,i.name,i.category,i.unit,SUM(CASE WHEN t.txn_type IN ('Issue','Stock Out') THEN t.qty ELSE 0 END)-SUM(CASE WHEN t.txn_type='Return' THEN t.qty ELSE 0 END) qty FROM consumable_transactions t JOIN consumable_items i ON i.id=t.item_id WHERE t.issued_to<>'' GROUP BY t.item_id,t.issued_to HAVING qty>0 ORDER BY t.issued_to,i.name").fetchall()
    nw=enrich_ticket_users(c.execute("SELECT t.*,i.name item_name,i.category,i.unit FROM consumable_transactions t JOIN consumable_items i ON i.id=t.item_id WHERE t.txn_type='Return' AND lower(trim(t.condition)) IN ('not working','damaged') ORDER BY t.changed_at DESC,t.id DESC").fetchall())
    c.close(); return render_template('inventory_reports.html',items=items,tx=tx,current=grouped,not_working=nw,item_filter=item_filter,user_filter=user_filter,current_role=session.get('role',''))

@app.route("/inventory-store/reports/export")
def inventory_store_reports_export():
    if not session.get("user") or session.get("inventory_role") not in ["Admin","IT Admin"]:
        flash("Access denied.","error"); return redirect(url_for("inventory_store"))
    c=db(); mode=request.args.get('mode','history'); item_filter=(request.args.get('item') or '').strip(); user_filter=(request.args.get('user') or '').strip()
    wb=Workbook(); ws=wb.active
    if mode=='current':
        ws.title='Issued To Users'; ws.append(['Item','Category','User','Quantity','Unit'])
        rows=c.execute("SELECT t.item_id,t.issued_to,i.name,i.category,i.unit,SUM(CASE WHEN t.txn_type IN ('Issue','Stock Out') THEN t.qty ELSE 0 END)-SUM(CASE WHEN t.txn_type='Return' THEN t.qty ELSE 0 END) qty FROM consumable_transactions t JOIN consumable_items i ON i.id=t.item_id WHERE t.issued_to<>'' GROUP BY t.item_id,t.issued_to HAVING qty>0 ORDER BY t.issued_to,i.name").fetchall()
        for r in rows: ws.append([r['name'],r['category'],r['issued_to'],r['qty'],r['unit']])
    elif mode=='not-working':
        ws.title='Not Working Parts'; ws.append(['Date','Item','Category','Qty','User','Department','Ticket','Ticket User','Condition','Reason','Remarks','Recorded By'])
        rows=c.execute("SELECT t.*,i.name item_name,i.category FROM consumable_transactions t JOIN consumable_items i ON i.id=t.item_id WHERE t.txn_type='Return' AND lower(trim(t.condition)) IN ('not working','damaged') ORDER BY t.changed_at DESC,t.id DESC").fetchall()
        for r in rows:
            ws.append([r['changed_at'],r['item_name'],r['category'],r['qty'],r['issued_to'],r['department'],r['ticket_no'],ticket_requester_name(r['ticket_no']),r['condition'],r['reason'],r['remarks'],r['changed_by']])
    else:
        ws.title='Inventory History'; ws.append(['Date','Item','Category','Action','Qty','User','Department','Ticket','Ticket User','Condition','Reason','Remarks','Recorded By'])
        where=[]; params=[]
        if item_filter: where.append('t.item_id=?'); params.append(int(item_filter))
        if user_filter: where.append('t.issued_to LIKE ?'); params.append('%'+user_filter+'%')
        q='SELECT t.*,i.name item_name,i.category FROM consumable_transactions t JOIN consumable_items i ON i.id=t.item_id'
        if where:q+=' WHERE '+' AND '.join(where)
        q+=' ORDER BY t.changed_at DESC,t.id DESC'
        for r in c.execute(q,params).fetchall():
            ws.append([r['changed_at'],r['item_name'],r['category'],r['txn_type'],r['qty'],r['issued_to'],r['department'],r['ticket_no'],ticket_requester_name(r['ticket_no']),r['condition'],r['reason'],r['remarks'],r['changed_by']])
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=min(max(max(len(str(x.value or '')) for x in col)+2,12),35)
    c.close(); bio=io.BytesIO(); wb.save(bio); bio.seek(0); return send_file(bio,as_attachment=True,download_name=f'IT_Store_{mode}_Report.xlsx',mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

@app.route("/inventory-store")
def inventory_store():
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    items=c.execute("SELECT * FROM consumable_items WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
    low=[r for r in items if int(r["available_qty"] or 0)<=int(r["min_stock"] or 0)]
    recent=c.execute("""SELECT t.*, i.name AS item_name, i.unit FROM consumable_transactions t
                       JOIN consumable_items i ON i.id=t.item_id
                       ORDER BY t.changed_at DESC, t.id DESC LIMIT 20""").fetchall()
    c.close()
    return render_template("inventory_store.html", items=items, low=low, recent=recent,
                           low_count=len(low), current_role=session.get("role",""))

@app.route("/inventory-store/item", methods=["POST"])
def inventory_store_item():
    if not session.get("user") or session.get("inventory_role") not in ["Admin","IT Admin"]:
        flash("Access denied.","error"); return redirect(url_for("inventory_store"))
    name=(request.form.get("name") or "").strip(); category=(request.form.get("category") or "").strip()
    unit=(request.form.get("unit") or "pcs").strip() or "pcs"
    try:
        qty=max(0,int(request.form.get("qty") or 0)); minimum=max(0,int(request.form.get("min_stock") or 0)); price=max(0,float(request.form.get("purchase_price") or 0))
    except ValueError:
        flash("Quantity, minimum stock and price must be valid numbers.","error"); return redirect(url_for("inventory_store"))
    if not name: flash("Item name is required.","error"); return redirect(url_for("inventory_store"))
    c=db()
    # Replenishing an existing consumable should increase its stock instead of
    # creating a duplicate line. Match active items by name + category + unit.
    existing=c.execute("""SELECT * FROM consumable_items
                          WHERE active=1 AND lower(trim(name))=lower(trim(?))
                            AND lower(trim(COALESCE(category,'')))=lower(trim(?))
                            AND lower(trim(COALESCE(unit,'pcs')))=lower(trim(?))
                          ORDER BY id LIMIT 1""",(name,category,unit)).fetchone()
    if existing:
        new_total=int(existing["total_qty"] or 0)+qty
        new_available=int(existing["available_qty"] or 0)+qty
        # Keep the existing master values unless the new entry provides a higher
        # minimum stock/vendor/location/price, so replenishment does not erase data.
        new_min=max(int(existing["min_stock"] or 0),minimum)
        vendor=(request.form.get("vendor") or "").strip() or existing["vendor"]
        location=(request.form.get("location") or "").strip() or existing["location"]
        notes=(request.form.get("notes") or "").strip() or existing["notes"]
        purchase_price=price if price else existing["purchase_price"]
        c.execute("""UPDATE consumable_items SET total_qty=?,available_qty=?,min_stock=?,vendor=?,purchase_price=?,location=?,notes=? WHERE id=?""",
                  (new_total,new_available,new_min,vendor,purchase_price,location,notes,existing["id"]))
        if qty:
            c.execute("""INSERT INTO consumable_transactions(item_id,txn_type,qty,issued_to,department,ticket_no,reason,condition,remarks,changed_by)
                         VALUES(?,?,?,?,?,?,?,?,?,?)""",(existing["id"],"Stock In",qty,"","","","Replenishment","New",
                         (request.form.get("notes") or "Stock replenishment").strip(),session.get("user")))
        audit_log(c,"Stock In","Inventory Store",target_type="Consumable",target_id=existing["id"],details={"name":name,"quantity_added":qty,"available_after":new_available})
        c.commit(); c.close(); flash(f"{name}: stock increased by {qty}. Available stock is now {new_available} {unit}.","ok"); return redirect(url_for("inventory_store"))
    c.execute("""INSERT INTO consumable_items(name,category,unit,total_qty,available_qty,min_stock,vendor,purchase_price,location,notes,created_by)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(name,category,unit,qty,qty,minimum,(request.form.get("vendor") or "").strip(),price,(request.form.get("location") or "").strip(),(request.form.get("notes") or "").strip(),session.get("user")))
    item_id=c.execute("SELECT last_insert_rowid()").fetchone()[0]
    if qty:
        c.execute("""INSERT INTO consumable_transactions(item_id,txn_type,qty,issued_to,department,ticket_no,reason,condition,remarks,changed_by)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",(item_id,"Stock In",qty,"","","","Opening Stock","New",
                     (request.form.get("notes") or "Opening stock").strip(),session.get("user")))
    audit_log(c,"Created","Inventory Store",target_type="Consumable",target_id=item_id,details={"name":name,"quantity":qty})
    c.commit(); c.close(); flash(f"{name} added to IT inventory.","ok"); return redirect(url_for("inventory_store"))

@app.route("/inventory-store/<int:item_id>/transaction", methods=["POST"])
def inventory_store_transaction(item_id):
    if not session.get("user") or session.get("inventory_role") not in ["Admin","IT Admin"]:
        flash("Access denied.","error"); return redirect(url_for("inventory_store"))
    c=db(); item=c.execute("SELECT * FROM consumable_items WHERE id=? AND active=1",(item_id,)).fetchone()
    if not item: c.close(); flash("Inventory item not found.","error"); return redirect(url_for("inventory_store"))
    typ=request.form.get("txn_type","Issue"); typ="Return" if typ=="Return" else ("Stock In" if typ=="Stock In" else "Issue")
    try: qty=max(1,int(request.form.get("qty") or 0))
    except ValueError: qty=0
    if qty<=0: c.close(); flash("Enter a valid quantity.","error"); return redirect(url_for("inventory_store"))
    available=int(item["available_qty"] or 0)
    if typ=="Issue" and qty>available:
        c.close(); flash(f"Only {available} {item['unit']} available.","error"); return redirect(url_for("inventory_store"))
    condition=(request.form.get("condition") or "").strip()
    if typ=="Issue": new_avail=available-qty
    elif typ=="Stock In": new_avail=available+qty
    else: new_avail=available + (qty if condition.lower()=="working" else 0)
    total=int(item["total_qty"] or 0)
    if typ=="Stock In": total += qty
    if typ=="Return": total=max(total, new_avail)
    c.execute("UPDATE consumable_items SET available_qty=?, total_qty=? WHERE id=?",(new_avail,total,item_id))
    c.execute("""INSERT INTO consumable_transactions(item_id,txn_type,qty,issued_to,department,ticket_no,reason,condition,remarks,changed_by)
                 VALUES(?,?,?,?,?,?,?,?,?,?)""",(item_id,typ,qty,(request.form.get("issued_to") or "").strip(),(request.form.get("department") or "").strip(),(request.form.get("ticket_no") or "").strip(),(request.form.get("reason") or "").strip(),(request.form.get("condition") or "").strip(),(request.form.get("remarks") or "").strip(),session.get("user")))
    audit_log(c,typ,"Inventory Store",target_type="Consumable",target_id=item_id,details={"item":item["name"],"qty":qty,"available_after":new_avail,"ticket_no":request.form.get("ticket_no","" )})
    c.commit(); c.close(); flash(f"{typ} recorded for {item['name']}.","ok"); return redirect(url_for("inventory_store"))

@app.route("/inventory-store/<int:item_id>/deactivate", methods=["POST"])
def inventory_store_deactivate(item_id):
    if not session.get("user") or session.get("inventory_role")!="Admin":
        flash("Only Admin can remove inventory items.","error"); return redirect(url_for("inventory_store"))
    c=db(); item=c.execute("SELECT * FROM consumable_items WHERE id=?",(item_id,)).fetchone()
    if item:
        c.execute("UPDATE consumable_items SET active=0 WHERE id=?",(item_id,)); audit_log(c,"Archived","Inventory Store",target_type="Consumable",target_id=item_id,details={"name":item["name"]}); c.commit(); flash("Item archived. Historical transactions are preserved.","ok")
    c.close(); return redirect(url_for("inventory_store"))

@app.route("/reports")
def reports():
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    department=request.args.get("department","").strip(); status=request.args.get("status","").strip(); user=request.args.get("user","").strip(); asset_type=request.args.get("asset_type","").strip(); warranty_filter=request.args.get("warranty","").strip().lower(); pm_filter=request.args.get("pm","").strip().lower()
    where=[]; params=[]
    if status: where.append("ie.status=?"); params.append(status)
    # Warranty alert links must show only the matching warranty records.
    # Filtering is done after loading metadata so the date logic stays in one place.
    if department: where.append("EXISTS(SELECT 1 FROM entry_values dv JOIN folder_fields dfv ON dfv.id=dv.field_id WHERE dv.entry_id=ie.id AND lower(replace(replace(dfv.field_name,' ',''),'-',''))='department' AND lower(trim(dv.value))=lower(trim(?)))"); params.append(department)
    if user: where.append("""(ie.created_by LIKE ? OR EXISTS(SELECT 1 FROM asset_assignments au WHERE au.entry_id=ie.id AND au.assigned_to LIKE ?))"""); params.extend(["%"+user+"%","%"+user+"%"])
    if asset_type: where.append("df.name LIKE ?"); params.append("%"+asset_type+"%")
    sql="SELECT ie.*,df.name AS folder_name FROM inventory_entries ie JOIN dashboard_folders df ON df.id=ie.folder_id"+(" WHERE "+" AND ".join(where) if where else "")+" ORDER BY ie.id DESC"
    raw_entries=c.execute(sql,params).fetchall()
    entries=[]
    for er in raw_entries:
        d=dict(er); md=metadata_row(c,er["id"]); d["asset_user"]=entry_user(c,er["id"]); d["department_name"]=entry_department(c,er["id"]); d["warranty_state"]=warranty_state(md["warranty_end"])
        if warranty_filter in ("expired", "expiring"):
            wanted = "Expired" if warranty_filter == "expired" else "Expiring Soon"
            if d["warranty_state"] != wanted:
                continue
        if pm_filter in ("overdue", "due"):
            ps=c.execute("SELECT next_due_date,pm_type FROM pm_schedules WHERE entry_id=?",(er["id"],)).fetchone()
            state=pm_state(ps["next_due_date"],ps["pm_type"]) if ps else "Not Scheduled"
            wanted="Overdue" if pm_filter=="overdue" else "Due Soon"
            if state != wanted:
                continue
        entries.append(d)
    depts=[r[0] for r in c.execute("SELECT DISTINCT ev.value FROM entry_values ev JOIN folder_fields ff ON ff.id=ev.field_id WHERE lower(replace(replace(ff.field_name,' ',''),'-',''))='department' AND trim(ev.value)<>'' ORDER BY ev.value").fetchall()]
    users=sorted({r[0] for r in c.execute("SELECT DISTINCT created_by FROM inventory_entries WHERE trim(created_by)<>''").fetchall()} | {r[0] for r in c.execute("SELECT DISTINCT assigned_to FROM asset_assignments WHERE trim(assigned_to)<>''").fetchall()})
    statuses=LIFECYCLE_STATUSES
    soon=expired=0
    for r in c.execute("SELECT warranty_end FROM asset_metadata WHERE warranty_end<>''").fetchall():
        st=warranty_state(r["warranty_end"]); soon+=st=="Expiring Soon"; expired+=st=="Expired"
    ewcount=c.execute("SELECT COUNT(*) FROM ewaste_records").fetchone()[0]
    ipcount=len([r for r in get_lan_ip_fields(c)])
    used_ip_values=set()
    for ff in get_lan_ip_fields(c):
        for rr in c.execute("SELECT value FROM entry_values WHERE field_id=? AND trim(value)<>''",(ff["id"],)).fetchall():
            try: used_ip_values.add(str(ipaddress.ip_address(rr["value"].strip())))
            except Exception: pass
    try:
        net=ipaddress.ip_network(get_lan_network(c),strict=False)
        ip_used=len([x for x in used_ip_values if ipaddress.ip_address(x) in net])
        ip_free=max(max(net.num_addresses-2,0)-ip_used,0)
    except Exception:
        ip_used=ip_free=0
    pm_due_soon=pm_overdue=0
    for pr in c.execute("SELECT next_due_date,pm_type FROM pm_schedules").fetchall():
        ps=pm_state(pr["next_due_date"],pr["pm_type"]); pm_due_soon += ps=="Due Soon"; pm_overdue += ps=="Overdue"
    c.close()
    return render_template("reports.html",entries=entries,depts=depts,users=users,statuses=statuses,department=department,status=status,user=user,asset_type=asset_type,warranty_soon=soon,warranty_expired=expired,ewaste_count=ewcount,ip_field_count=ipcount,ip_used=ip_used,ip_free=ip_free,pm_due_soon=pm_due_soon,pm_overdue=pm_overdue,pm_filter=pm_filter)

@app.route("/reports/export")
def reports_export():
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); entries=c.execute("""SELECT ie.*,df.name AS folder_name FROM inventory_entries ie JOIN dashboard_folders df ON df.id=ie.folder_id ORDER BY ie.id""").fetchall()
    wb=Workbook(); ws=wb.active; ws.title="Inventory Report"
    ws.append(["Entry ID","Folder","Status","Created By","Created","Purchase Date","Warranty Start","Warranty End","Warranty State","User","Department","Location"])
    for e in entries:
        md=metadata_row(c,e["id"]); ws.append([e["id"],e["folder_name"],e["status"],e["created_by"],e["created_at"],md["purchase_date"],md["warranty_start"],md["warranty_end"],warranty_state(md["warranty_end"]),entry_user(c,e["id"]),entry_department(c,e["id"]),entry_location(c,e["id"])])
    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
    ew=wb.create_sheet("E-Waste Report")
    ew.append(["E-Waste ID","Type","Original Asset","Source Folder","Disposal Date","Reason","Created By","Created"])
    for r in c.execute("""SELECT er.*,df.name AS folder_name FROM ewaste_records er LEFT JOIN dashboard_folders df ON df.id=er.source_folder_id ORDER BY er.id""").fetchall():
        ew.append([r["id"],"Automatic" if r["auto_created"] else "Manual",r["original_entry_id"] or "",r["folder_name"] or "Manual",r["disposal_date"],r["disposal_reason"],r["created_by"],r["created_at"]])
    ew.freeze_panes="A2"; ew.auto_filter.ref=ew.dimensions
    ipws=wb.create_sheet("IP Utilization")
    ipws.append(["LAN Network","Used IPs","Free IPs"])
    used=set()
    for ff in get_lan_ip_fields(c):
        for rr in c.execute("SELECT value FROM entry_values WHERE field_id=? AND trim(value)<>''",(ff["id"],)).fetchall():
            try: used.add(str(ipaddress.ip_address(rr["value"].strip())))
            except Exception: pass
    net=ipaddress.ip_network(get_lan_network(c),strict=False)
    used_n=len([x for x in used if ipaddress.ip_address(x) in net])
    ipws.append([str(net),used_n,max(net.num_addresses-2-used_n,0)])
    pmws=wb.create_sheet("Preventive Maintenance")
    pmws.append(["Entry ID","Asset","PM Type","Frequency Months","Last PM","Next Due","PM State"])
    for r in c.execute("SELECT p.*,df.name AS folder_name FROM pm_schedules p JOIN inventory_entries ie ON ie.id=p.entry_id JOIN dashboard_folders df ON df.id=ie.folder_id ORDER BY p.next_due_date").fetchall():
        pmws.append([r["entry_id"],r["folder_name"],r["pm_type"],r["frequency_months"],r["last_pm_date"],r["next_due_date"],pm_state(r["next_due_date"],r["pm_type"])])
    pmws.freeze_panes="A2"; pmws.auto_filter.ref=pmws.dimensions
    phws=wb.create_sheet("PM History")
    phws.append(["Entry ID","PM Date","PM Type","Result","Performed By","IP","Computer/Host","Remarks","Recorded"])
    for r in c.execute("SELECT p.entry_id,h.pm_date,h.pm_type,h.result,h.performed_by,h.performed_ip,h.performed_host,h.remarks,h.created_at FROM pm_history h JOIN pm_schedules p ON p.id=h.schedule_id ORDER BY h.pm_date DESC,h.id DESC").fetchall():
        phws.append(list(r))
    phws.freeze_panes="A2"; phws.auto_filter.ref=phws.dimensions
    try:
        rw=wb.create_sheet("Repair History")
        rw.append(["Entry ID","Repair Date","Issue","Action Taken","Vendor","Cost","Result","Remarks","Created By","Created","IP","Computer/Host"])
        for r in c.execute("SELECT entry_id,repair_date,issue,action_taken,vendor,cost,result,remarks,created_by,created_at,client_ip,client_host FROM repair_history ORDER BY repair_date DESC,id DESC").fetchall(): rw.append(list(r))
        rw.freeze_panes="A2"; rw.auto_filter.ref=rw.dimensions
    except sqlite3.OperationalError:
        pass
    from io import BytesIO
    out=BytesIO(); wb.save(out); out.seek(0); c.close()
    auditc=db(); audit_log(auditc,"Export","Reports",target_type="Report",target_id="inventory",details={"rows":len(entries)}); auditc.commit(); auditc.close()
    return send_file(out,as_attachment=True,download_name="Inventory_Report.xlsx",mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/it-software")
def it_software():
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); rows=c.execute("SELECT * FROM it_software ORDER BY CASE WHEN expiry_date='' THEN 1 ELSE 0 END, expiry_date ASC, id DESC").fetchall(); c.close(); today=datetime.now().date(); out=[]
    for r in rows:
        d=dict(r); exp=r["expiry_date"] or ""; d["days_left"]=""; state="No Expiry"
        if exp:
            try:
                d["days_left"]=(datetime.fromisoformat(exp[:10]).date()-today).days; state="Expired" if d["days_left"]<0 else ("Expiring Soon" if d["days_left"]<=30 else "Active")
            except Exception: state="Invalid Date"
        d["expiry_state"]=state; out.append(d)
    return render_template("it_software.html",software=out,today=today.isoformat())

@app.route("/it-software/create",methods=["POST"])
def it_software_create():
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db(); name=request.form.get("software_name","").strip()
    if not name: c.close(); flash("Software Name is required.","error"); return redirect(url_for("it_software"))
    q=max(request.form.get("quantity",type=int) or 1,1)
    cur=c.execute("INSERT INTO it_software(software_name,version,vendor,license_type,license_key,purchase_date,expiry_date,quantity,assigned_to,department,asset_reference,status,remarks,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(name,request.form.get("version","").strip(),request.form.get("vendor","").strip(),request.form.get("license_type","Per Device"),request.form.get("license_key","").strip(),request.form.get("purchase_date","").strip(),request.form.get("expiry_date","").strip(),q,request.form.get("assigned_to","").strip(),request.form.get("department","").strip(),request.form.get("asset_reference","").strip(),request.form.get("status","Active"),request.form.get("remarks","").strip(),session["user"]))
    audit_log(c,"Create","IT Software",target_type="Software",target_id=cur.lastrowid,details={"software":name}); c.commit(); c.close(); flash("IT Software added.","ok"); return redirect(url_for("it_software"))

@app.route("/it-software/<int:software_id>/edit",methods=["POST"])
def it_software_edit(software_id):
    if not session.get("user") or not permissions_for("edit"): return redirect(url_for("home"))
    c=db(); r=c.execute("SELECT id FROM it_software WHERE id=?",(software_id,)).fetchone()
    if not r: c.close(); flash("Software record not found.","error"); return redirect(url_for("it_software"))
    vals=[request.form.get(k,"").strip() for k in ["software_name","version","vendor","license_type","license_key","purchase_date","expiry_date"]]; q=max(request.form.get("quantity",type=int) or 1,1)
    c.execute("UPDATE it_software SET software_name=?,version=?,vendor=?,license_type=?,license_key=?,purchase_date=?,expiry_date=?,quantity=?,assigned_to=?,department=?,asset_reference=?,status=?,remarks=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(*vals,q,request.form.get("assigned_to","").strip(),request.form.get("department","").strip(),request.form.get("asset_reference","").strip(),request.form.get("status","Active"),request.form.get("remarks","").strip(),software_id)); audit_log(c,"Edit","IT Software",target_type="Software",target_id=software_id,details="Software record updated"); c.commit(); c.close(); return redirect(url_for("it_software"))

@app.route("/it-software/export")
def it_software_export():
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); rows=c.execute("SELECT * FROM it_software ORDER BY expiry_date,id").fetchall(); wb=Workbook(); ws=wb.active; ws.title="IT Software"; ws.append(["ID","Software Name","Version","Vendor","License Type","License Key","Purchase Date","Expiry Date","Quantity","Assigned To","Department","Asset Reference","Status","Remarks","Created By","Created"])
    for r in rows: ws.append([r["id"],r["software_name"],r["version"],r["vendor"],r["license_type"],r["license_key"],r["purchase_date"],r["expiry_date"],r["quantity"],r["assigned_to"],r["department"],r["asset_reference"],r["status"],r["remarks"],r["created_by"],r["created_at"]])
    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
    from io import BytesIO
    out=BytesIO(); wb.save(out); out.seek(0); c.close(); return send_file(out,as_attachment=True,download_name="IT_Software_Register.xlsx",mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@app.route("/ip-management",methods=["GET","POST"])
def ip_management():
    if not session.get("user"): return redirect(url_for("login"))
    c=db()
    if request.method=="POST":
        if session.get("inventory_role") != "Admin":
            c.close(); flash("Only Admin can change the LAN network range.","error"); return redirect(url_for("ip_management"))
        raw=request.form.get("lan_network","").strip()
        try:
            net=ipaddress.ip_network(raw, strict=False)
            if net.version != 4 or net.prefixlen > 30: raise ValueError
        except ValueError:
            c.close(); flash("Invalid IPv4 network. Example: 192.168.1.0/24","error"); return redirect(url_for("ip_management"))
        old_network=get_lan_network(c)
        c.execute("INSERT INTO system_settings(key,value) VALUES('lan_network',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(str(net),))
        audit_log(c, "Edit", "IP Management", target_type="Setting", target_id="lan_network", details={"old": old_network, "new": str(net)})
        c.commit(); flash(f"LAN network updated to {net}.","ok")
    network=get_lan_network(c)
    net=ipaddress.ip_network(network,strict=False)
    ip_fields=get_lan_ip_fields(c)
    used=[]; seen=set()
    duplicate_ips=set()
    all_ip_rows=[]
    for f in ip_fields:
        rows=c.execute("""SELECT ev.value, ie.id AS entry_id, ie.folder_id, df.name AS folder_name
                         FROM entry_values ev JOIN inventory_entries ie ON ie.id=ev.entry_id
                         JOIN dashboard_folders df ON df.id=ie.folder_id
                         WHERE ev.field_id=? AND trim(ev.value)<>'' ORDER BY ev.value""",(f["id"],)).fetchall()
        for r in rows:
            val=r["value"].strip()
            try: ip=ipaddress.ip_address(val)
            except ValueError: continue
            all_ip_rows.append((ip, r))
            if ip in seen:
                duplicate_ips.add(ip)
            else:
                seen.add(ip)
            used.append({"ip":val,"entry_id":r["entry_id"],"folder_id":r["folder_id"],"folder_name":r["folder_name"],"field_name":f["field_name"]})

    # Rental printers are LAN devices too. Their IPs must appear in Used IPs
    # and therefore must never remain visible in the Free IP list.
    try:
        rental_rows = c.execute("SELECT id, printer_id, printer_name, lan_ip, department FROM rental_printers WHERE trim(lan_ip)<>''").fetchall()
        for rp in rental_rows:
            try:
                ip = ipaddress.ip_address((rp["lan_ip"] or "").strip())
            except ValueError:
                continue
            if ip.version != 4 or ip not in net:
                continue
            if ip in seen:
                duplicate_ips.add(ip)
            else:
                seen.add(ip)
            used.append({"ip":str(ip),"entry_id":"", "folder_id":"", "folder_name":"Rental Printers", "field_name":f"{rp['printer_id']} - {rp['printer_name'] or 'Printer'}"})
    except sqlite3.OperationalError:
        pass

    used.sort(key=lambda x: ipaddress.ip_address(x["ip"]))
    free=[str(ip) for ip in net.hosts() if ip not in seen]
    c.close()
    return render_template("ip_management.html",network=str(net),used=used,free=free,ip_field_count=len(ip_fields),duplicate_ips=[str(x) for x in sorted(duplicate_ips)])

@app.route("/ip-management/entry/<int:entry_id>")
def ip_entry_details(entry_id):
    if not session.get("user"):
        return redirect(url_for("login"))
    c=db()
    entry=c.execute("SELECT ie.*, df.name AS folder_name FROM inventory_entries ie JOIN dashboard_folders df ON df.id=ie.folder_id WHERE ie.id=?",(entry_id,)).fetchone()
    if not entry:
        c.close(); flash("Inventory entry not found.","error"); return redirect(url_for("ip_management"))
    fields=c.execute("SELECT id,field_name FROM folder_fields WHERE folder_id=? ORDER BY id",(entry["folder_id"],)).fetchall()
    values={r["field_id"]:r["value"] for r in c.execute("SELECT field_id,value FROM entry_values WHERE entry_id=?",(entry_id,)).fetchall()}
    history_count=c.execute("SELECT COUNT(*) FROM entry_history WHERE entry_id=?",(entry_id,)).fetchone()[0]
    details=[]
    for f in fields:
        value=(values.get(f["id"]) or "").strip()
        if value:
            details.append({"field_name":f["field_name"],"value":value})
    c.close()
    return render_template("ip_entry_details.html",entry=entry,details=details,history_count=history_count)


@app.route("/global-search")
def global_search():
    if not session.get("user"):
        return redirect(url_for("login"))
    search=request.args.get("q","").strip()
    department=request.args.get("department","").strip()
    folder_id=request.args.get("folder_id","").strip()
    results=[]
    c=db()
    if search or department:
        like=f"%{search}%"
        dept_value=department
        dept_clause = ""
        dept_params=[]
        if department:
            dept_clause += " AND EXISTS (SELECT 1 FROM entry_values evd JOIN folder_fields ffd ON ffd.id=evd.field_id WHERE evd.entry_id=ie.id AND lower(replace(replace(trim(ffd.field_name),' ',''),'-',''))='department' AND lower(trim(evd.value))=lower(trim(?)))"
            dept_params.append(department)
        if folder_id.isdigit():
            dept_clause += " AND ie.folder_id=?"
            dept_params.append(int(folder_id))
        # Search across entry metadata, folder names, field names and every stored field value.
        sql=f"""
            SELECT ie.id AS entry_id, ie.folder_id, ie.created_by, ie.status, ie.created_at,
                   df.name AS folder_name
            FROM inventory_entries ie
            JOIN dashboard_folders df ON df.id=ie.folder_id
            WHERE (ie.id LIKE ? OR ie.created_by LIKE ? OR ie.status LIKE ?
               OR ie.created_at LIKE ? OR df.name LIKE ? OR df.description LIKE ?
               OR EXISTS (
                   SELECT 1 FROM entry_values ev
                   JOIN folder_fields ff ON ff.id=ev.field_id
                   WHERE ev.entry_id=ie.id AND (ev.value LIKE ? OR ff.field_name LIKE ?)
               ))
               {dept_clause}
            ORDER BY ie.id DESC
        """
        params=(like,like,like,like,like,like,like,like) + tuple(dept_params)
        rows=c.execute(sql, params).fetchall()
        for e in rows:
            fields=c.execute("""SELECT ff.field_name, ev.value
                              FROM entry_values ev
                              JOIN folder_fields ff ON ff.id=ev.field_id
                              WHERE ev.entry_id=? ORDER BY ff.id""",(e["entry_id"],)).fetchall()
            results.append({
                "entry_id":e["entry_id"],"folder_id":e["folder_id"],
                "folder_name":e["folder_name"],"created_by":e["created_by"],
                "status":e["status"],"created_at":e["created_at"],
                "fields":[{"field_name":f["field_name"],"value":f["value"]} for f in fields]
            })
    c.close()
    return render_template("global_search.html",search=search,department=department,folder_id=folder_id,results=results)


@app.route("/audit-log")
def audit_log_view():
    if not session.get("user") or session.get("inventory_role") != "Admin":
        return redirect(url_for("home"))
    action=request.args.get("action","").strip()
    module=request.args.get("module","").strip()
    user=request.args.get("user","").strip()
    search=request.args.get("q","").strip()
    c=db()
    where=[]; params=[]
    if action:
        where.append("action=?"); params.append(action)
    if module:
        where.append("module=?"); params.append(module)
    if user:
        where.append("changed_by=?"); params.append(user)
    if search:
        where.append("(action LIKE ? OR module LIKE ? OR target_type LIKE ? OR target_id LIKE ? OR details LIKE ? OR changed_by LIKE ?)")
        like=f"%{search}%"; params.extend([like]*6)
    sql="SELECT * FROM audit_log" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY id DESC LIMIT 500"
    rows=c.execute(sql,params).fetchall()
    actions=[r["action"] for r in c.execute("SELECT DISTINCT action FROM audit_log ORDER BY action").fetchall()]
    modules=[r["module"] for r in c.execute("SELECT DISTINCT module FROM audit_log ORDER BY module").fetchall()]
    users_list=[r["changed_by"] for r in c.execute("SELECT DISTINCT changed_by FROM audit_log ORDER BY changed_by").fetchall()]
    c.close()
    return render_template("audit_log.html",logs=rows,actions=actions,modules=modules,users_list=users_list,selected_action=action,selected_module=module,selected_user=user,search=search)

@app.route("/rental-printers")
def rental_printers():
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); printers=c.execute("SELECT * FROM rental_printers ORDER BY printer_name COLLATE NOCASE, id DESC").fetchall()
    stats={"total":len(printers),"active":sum(1 for r in printers if r["status"]=="Active"),"inactive":sum(1 for r in printers if r["status"]!="Active")}
    c.close()
    now=datetime.now()
    current_fy_start=now.year if now.month >= 4 else now.year-1
    fy_years=list(range(current_fy_start-3,current_fy_start+4))
    calendar_years=list(range(now.year-3,now.year+4))
    return render_template("rental_printers.html",printers=printers,stats=stats,fy_years=fy_years,calendar_years=calendar_years,current_fy_start=current_fy_start,current_calendar_year=now.year)

@app.route("/rental-printers/create",methods=["POST"])
def rental_printer_create():
    if not session.get("user") or not permissions_for("new_entry"): return redirect(url_for("rental_printers"))
    vals={k:request.form.get(k,"").strip() for k in ["printer_id","printer_name","model","lan_ip","location","department","vendor","remarks"]}
    try: free=max(int(request.form.get("free_pages",0) or 0),0)
    except ValueError: free=0
    status=request.form.get("status","Active").strip() or "Active"
    if not vals["printer_id"]: flash("Printer ID is required.","error"); return redirect(url_for("rental_printers"))
    c=db()
    if vals["lan_ip"]:
        ok, message = validate_lan_ip_value(c, vals["lan_ip"])
        if not ok:
            c.close()
            flash(message, "error")
            return redirect(url_for("rental_printers"))
    try:
        cur=c.execute("INSERT INTO rental_printers(printer_id,printer_name,model,lan_ip,location,department,vendor,free_pages,status,remarks,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(vals["printer_id"],vals["printer_name"],vals["model"],vals["lan_ip"],vals["location"],vals["department"],vals["vendor"],free,status,vals["remarks"],session["user"]))
        audit_log(c,"Create","Rental Printers",target_type="Printer",target_id=cur.lastrowid,details={"printer_id":vals["printer_id"],"name":vals["printer_name"]}); c.commit(); flash("Rental printer added successfully.","ok")
    except sqlite3.IntegrityError: c.rollback(); flash("Printer ID already exists.","error")
    finally: c.close()
    return redirect(url_for("rental_printers"))

@app.route("/rental-printer/<int:printer_id>/edit",methods=["POST"])
def rental_printer_edit(printer_id):
    # Admin and IT Admin may fully edit rental-printer master data.
    if not session.get("user") or not permissions_for("edit"):
        return redirect(url_for("rental_printer_profile", printer_id=printer_id))
    vals={k:request.form.get(k,"").strip() for k in ["printer_id","printer_name","model","lan_ip","location","department","vendor","remarks"]}
    try:
        free=max(int(request.form.get("free_pages",0) or 0),0)
    except ValueError:
        free=0
    status=request.form.get("status","Active").strip() or "Active"
    if not vals["printer_id"]:
        flash("Printer ID is required.","error")
        return redirect(url_for("rental_printer_profile", printer_id=printer_id))
    c=db()
    printer=c.execute("SELECT * FROM rental_printers WHERE id=?",(printer_id,)).fetchone()
    if not printer:
        c.close(); flash("Rental printer not found.","error")
        return redirect(url_for("rental_printers"))
    if vals["lan_ip"]:
        ok,message=validate_lan_ip_value(c, vals["lan_ip"], exclude_entry_id=None) if False else (True,"")
        # Keep the existing LAN/IP validation behavior without changing unrelated inventory logic.
        try:
            ok,message=validate_lan_ip_value(c, vals["lan_ip"])
            if not ok:
                # Allow the printer to keep its own existing IP while rejecting a collision with another device.
                same=c.execute("SELECT id FROM rental_printers WHERE lan_ip=? AND id=?",(vals["lan_ip"],printer_id)).fetchone()
                if not same:
                    c.close(); flash(message,"error")
                    return redirect(url_for("rental_printer_profile", printer_id=printer_id))
        except Exception:
            pass
    try:
        dup=c.execute("SELECT id FROM rental_printers WHERE printer_id=? AND id<>?",(vals["printer_id"],printer_id)).fetchone()
        if dup:
            c.close(); flash("Printer ID already exists.","error")
            return redirect(url_for("rental_printer_profile", printer_id=printer_id))
        c.execute("UPDATE rental_printers SET printer_id=?,printer_name=?,model=?,lan_ip=?,location=?,department=?,vendor=?,free_pages=?,status=?,remarks=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(vals["printer_id"],vals["printer_name"],vals["model"],vals["lan_ip"],vals["location"],vals["department"],vals["vendor"],free,status,vals["remarks"],printer_id))
        audit_log(c,"Update","Rental Printers",target_type="Printer",target_id=printer_id,details={"printer_id":vals["printer_id"],"name":vals["printer_name"]})
        c.commit(); flash("Rental printer updated successfully.","ok")
    except Exception as e:
        c.rollback(); flash(f"Unable to update rental printer: {e}","error")
    finally:
        c.close()
    return redirect(url_for("rental_printer_profile", printer_id=printer_id))

@app.route("/rental-printer/<int:printer_id>")
def rental_printer_profile(printer_id):
    if not session.get("user"): return redirect(url_for("login"))
    c=db(); printer=c.execute("SELECT * FROM rental_printers WHERE id=?",(printer_id,)).fetchone()
    if not printer: c.close(); flash("Rental printer not found.","error"); return redirect(url_for("rental_printers"))
    readings=c.execute("SELECT * FROM rental_printer_readings WHERE printer_id=? ORDER BY reading_month DESC, id DESC",(printer_id,)).fetchall(); services=c.execute("SELECT * FROM rental_printer_services WHERE printer_id=? ORDER BY service_date DESC, id DESC",(printer_id,)).fetchall(); c.close()
    return render_template("rental_printer_profile.html",printer=printer,readings=readings,services=services)

@app.route("/rental-printer/<int:printer_id>/reading",methods=["POST"])
def rental_printer_reading(printer_id):
    if not session.get("user") or not permissions_for("new_entry"): return redirect(url_for("rental_printer_profile",printer_id=printer_id))
    month=request.form.get("reading_month","").strip(); remarks=request.form.get("remarks","").strip()
    try: current=max(int(request.form.get("current_reading",0) or 0),0)
    except ValueError: current=0
    c=db(); printer=c.execute("SELECT * FROM rental_printers WHERE id=?",(printer_id,)).fetchone()
    if not printer: c.close(); return redirect(url_for("rental_printers"))
    if not month: c.close(); flash("Reading month is required.","error"); return redirect(url_for("rental_printer_profile",printer_id=printer_id))
    prev=c.execute("SELECT reading_month,current_reading FROM rental_printer_readings WHERE printer_id=? ORDER BY reading_month DESC, id DESC LIMIT 1",(printer_id,)).fetchone()
    # The first/starting reading may be entered manually only for January.
    # After January, the previous reading is always taken automatically from the latest saved month.
    if not prev:
        if not month.endswith("-01"):
            c.close(); flash("The first reading must be entered for January, with a Previous Reading.","error"); return redirect(url_for("rental_printer_profile",printer_id=printer_id))
        try:
            previous=max(int(request.form.get("previous_reading",0) or 0),0)
        except ValueError:
            previous=0
    else:
        previous=int(prev["current_reading"])
    if prev and month <= str(prev["reading_month"]):
        c.close(); flash(f"Reading month must be after the latest saved month ({prev['reading_month']}).","error"); return redirect(url_for("rental_printer_profile",printer_id=printer_id))
    if current<previous: c.close(); flash(f"Current reading cannot be less than previous reading ({previous}).","error"); return redirect(url_for("rental_printer_profile",printer_id=printer_id))
    total=current-previous; free=int(printer["free_pages"] or 0); extra=total-free
    try:
        c.execute("INSERT INTO rental_printer_readings(printer_id,reading_month,previous_reading,current_reading,total_pages,free_pages,extra_pages,remarks,created_by) VALUES(?,?,?,?,?,?,?,?,?)",(printer_id,month,previous,current,total,free,extra,remarks,session["user"]))
        audit_log(c,"Create","Rental Printer Reading",target_type="Printer",target_id=printer_id,details={"month":month,"total":total,"extra":extra}); c.commit(); flash("Monthly reading saved.","ok")
    except sqlite3.IntegrityError: c.rollback(); flash("This month already has a reading for this printer.","error")
    finally: c.close()
    return redirect(url_for("rental_printer_profile",printer_id=printer_id))

@app.route("/rental-printer/<int:printer_id>/service",methods=["POST"])
def rental_printer_service(printer_id):
    if not session.get("user") or not permissions_for("new_entry"): return redirect(url_for("rental_printer_profile",printer_id=printer_id))
    c=db(); exists=c.execute("SELECT id FROM rental_printers WHERE id=?",(printer_id,)).fetchone()
    if not exists: c.close(); return redirect(url_for("rental_printers"))
    try: pages=max(int(request.form.get("page_count",0) or 0),0)
    except ValueError: pages=0
    c.execute("INSERT INTO rental_printer_services(printer_id,service_date,work,vendor,page_count,cost,result,remarks,created_by) VALUES(?,?,?,?,?,?,?,?,?)",(printer_id,request.form.get("service_date","").strip() or datetime.now().strftime("%Y-%m-%d"),request.form.get("work","").strip(),request.form.get("vendor","").strip(),pages,request.form.get("cost","").strip(),request.form.get("result","Completed").strip(),request.form.get("remarks","").strip(),session["user"]))
    audit_log(c,"Create","Rental Printer Service",target_type="Printer",target_id=printer_id,details={"work":request.form.get("work","").strip()}); c.commit(); c.close(); flash("Service history saved.","ok"); return redirect(url_for("rental_printer_profile",printer_id=printer_id))

@app.route("/rental-printers/export")
def rental_printer_export():
    if not session.get("user"):
        return redirect(url_for("login"))

    # Report selection:
    #   mode=fy       -> April to March
    #   mode=calendar  -> January to December
    # If no selection is supplied, keep the old all-history export behaviour.
    mode=(request.args.get("mode") or "").strip().lower()
    year_text=(request.args.get("year") or "").strip()
    try:
        selected_year=int(year_text) if year_text else None
    except ValueError:
        selected_year=None

    c=db()
    printers=c.execute("SELECT * FROM rental_printers ORDER BY printer_id").fetchall()

    if mode in ("fy", "calendar") and selected_year is not None:
        if mode == "fy":
            months=[(selected_year, m) for m in range(4,13)] + [(selected_year+1, m) for m in range(1,4)]
            report_label=f"FY {selected_year}-{str(selected_year+1)[-2:]}"
        else:
            months=[(selected_year, m) for m in range(1,13)]
            report_label=str(selected_year)

        month_keys=[f"{y:04d}-{m:02d}" for y,m in months]
        placeholders=','.join('?' for _ in month_keys)
        rows=c.execute(f"""SELECT rp.printer_id,rp.printer_name,rp.model,rp.location,
                                  r.reading_month,r.previous_reading,r.current_reading,r.total_pages,
                                  r.free_pages,r.extra_pages,r.remarks,r.created_by
                           FROM rental_printer_readings r
                           JOIN rental_printers rp ON rp.id=r.printer_id
                           WHERE r.reading_month IN ({placeholders})
                           ORDER BY rp.printer_id,r.reading_month""", month_keys).fetchall()

        readings_by_printer={}
        for r in rows:
            readings_by_printer.setdefault(str(r[0]), {})[str(r[4])] = r

        wb=Workbook()
        ws=wb.active
        ws.title="12 Month Report"
        ws.append([f"RENTAL PRINTER REPORT - {report_label}"])
        ws.append(["Period", "April-March" if mode=="fy" else "January-December"])
        ws.append([])
        ws.append(["Printer ID","Printer Name","Model","Location","Month",
                   "Previous Reading","Current Reading","Total Pages","Free Pages",
                   "Extra / Due","Remarks","Recorded By"])

        for p in printers:
            pid=str(p["printer_id"])
            p_readings=readings_by_printer.get(pid,{})
            for y,m in months:
                key=f"{y:04d}-{m:02d}"
                r=p_readings.get(key)
                month_label=datetime(y,m,1).strftime("%B-%Y")
                if r:
                    vals=[r[5],r[6],r[7],r[8],r[9],r[10] or "",r[11] or ""]
                else:
                    vals=["","","","","","Not Entered",""]
                ws.append([p["printer_id"],p["printer_name"] or "",p["model"] or "",p["location"] or "",
                           month_label,*vals])

        # Per-printer 12-month totals make the export useful for management review.
        summary=wb.create_sheet("Year Summary")
        summary.append([f"RENTAL PRINTER SUMMARY - {report_label}"])
        summary.append(["Printer ID","Printer Name","Model","Location","Total Pages","Months Entered","Months Pending"])
        for p in printers:
            pid=str(p["printer_id"])
            p_readings=readings_by_printer.get(pid,{})
            totals=sum(int((p_readings[k][7] if p_readings.get(k) and p_readings[k][7] is not None else 0) or 0) for k in month_keys)
            entered=sum(1 for k in month_keys if p_readings.get(k))
            summary.append([p["printer_id"],p["printer_name"] or "",p["model"] or "",p["location"] or "",totals,entered,12-entered])

        for sheet in (ws,summary):
            sheet.freeze_panes="A5" if sheet is ws else "A3"
            for cell in sheet[1]:
                cell.font=__import__('openpyxl').styles.Font(bold=True,size=14)
            for col in sheet.columns:
                letter=col[0].column_letter
                max_len=max(len(str(cell.value or "")) for cell in col)
                sheet.column_dimensions[letter].width=min(max(max_len+2,12),32)

        out=BytesIO(); wb.save(out); out.seek(0); c.close()
        safe_label=re.sub(r'[^A-Za-z0-9_-]+','_',report_label).strip('_')
        return send_file(out,as_attachment=True,
                         download_name=f"Rental_Printers_{safe_label}_Report.xlsx",
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

    # Existing complete-history export is preserved when no period is selected.
    readings=c.execute("SELECT rp.printer_id,rp.printer_name,r.reading_month,r.previous_reading,r.current_reading,r.total_pages,r.free_pages,r.extra_pages,r.remarks FROM rental_printer_readings r JOIN rental_printers rp ON rp.id=r.printer_id ORDER BY r.reading_month DESC").fetchall()
    services=c.execute("SELECT rp.printer_id,rp.printer_name,s.service_date,s.work,s.vendor,s.page_count,s.cost,s.result,s.remarks FROM rental_printer_services s JOIN rental_printers rp ON rp.id=s.printer_id ORDER BY s.service_date DESC").fetchall()
    wb=Workbook(); ws=wb.active; ws.title="Printers"; ws.append(["Printer ID","Printer Name","Model","LAN IP","Location","Department","Vendor","Free Pages","Status","Remarks"])
    for r in printers: ws.append([r[k] for k in ["printer_id","printer_name","model","lan_ip","location","department","vendor","free_pages","status","remarks"]])
    wr=wb.create_sheet("Monthly Readings")
    wr.append(["Printer ID","Printer Name","Month","Previous","Current","Total Pages","Free Pages","Extra/Due","Remarks"])
    for r in sorted(readings, key=lambda x: (str(x[0]).casefold(), str(x[2]))): wr.append(list(r))
    ws2=wb.create_sheet("Service History"); ws2.append(["Printer ID","Printer Name","Date","Work","Vendor","Page Count","Cost","Result","Remarks"])
    for r in services: ws2.append(list(r))
    out=BytesIO(); wb.save(out); out.seek(0); c.close(); return send_file(out,as_attachment=True,download_name="Rental_Printers_Report.xlsx",mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@app.route("/rental-printer/<int:printer_id>/export/excel")
def rental_printer_profile_excel(printer_id):
    if not session.get("user"):
        return redirect(url_for("login"))
    c=db()
    printer=c.execute("SELECT * FROM rental_printers WHERE id=?",(printer_id,)).fetchone()
    if not printer:
        c.close(); return "Rental printer not found",404
    readings=c.execute("SELECT * FROM rental_printer_readings WHERE printer_id=? ORDER BY reading_month ASC, id ASC",(printer_id,)).fetchall()
    services=c.execute("SELECT * FROM rental_printer_services WHERE printer_id=? ORDER BY service_date ASC, id ASC",(printer_id,)).fetchall()
    wb=Workbook()
    ws=wb.active; ws.title="Monthly Readings"
    ws.append(["RENTAL PRINTER MONTHLY REPORT"])
    ws.append(["Printer ID",printer["printer_id"],"Printer Name",printer["printer_name"] or ""])
    ws.append(["Model",printer["model"] or "","LAN IP",printer["lan_ip"] or ""])
    ws.append(["Location",printer["location"] or "","Department",printer["department"] or ""])
    ws.append(["Vendor",printer["vendor"] or "","Free Pages / Month",printer["free_pages"] or 0])
    ws.append([])
    ws.append(["Month","Previous Reading","Current Reading","Total Pages","Free Pages","Extra / Due","Remarks","Recorded By","Recorded At"])
    for r in readings:
        ws.append([r["reading_month"],r["previous_reading"],r["current_reading"],r["total_pages"],r["free_pages"],r["extra_pages"],r["remarks"] or "",r["created_by"],r["created_at"]])
    ws.freeze_panes="A8"
    ws.auto_filter.ref=f"A7:I{max(ws.max_row,7)}"
    for cell in ws[1]: cell.font=__import__('openpyxl').styles.Font(bold=True,size=14)
    for col in ws.columns:
        letter=col[0].column_letter
        max_len=max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[letter].width=min(max(max_len+2,12),30)
    sv=wb.create_sheet("Service History")
    sv.append(["Date","Work","Vendor","Page Count","Cost","Result","Remarks","Recorded By","Recorded At"])
    for r in services:
        sv.append([r["service_date"],r["work"],r["vendor"] or "",r["page_count"],r["cost"] or "",r["result"],r["remarks"] or "",r["created_by"],r["created_at"]])
    for col in sv.columns:
        letter=col[0].column_letter
        max_len=max(len(str(cell.value or "")) for cell in col)
        sv.column_dimensions[letter].width=min(max(max_len+2,12),30)
    from io import BytesIO
    out=BytesIO(); wb.save(out); out.seek(0); c.close()
    safe=re.sub(r'[^A-Za-z0-9_-]+','_',str(printer["printer_id"])).strip('_') or 'printer'
    return send_file(out,as_attachment=True,download_name=f"{safe}_Monthly_Readings.xlsx",mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@app.route("/rental-printer/<int:printer_id>/export/pdf")
def rental_printer_profile_pdf(printer_id):
    if not session.get("user"):
        return redirect(url_for("login"))
    c=db()
    printer=c.execute("SELECT * FROM rental_printers WHERE id=?",(printer_id,)).fetchone()
    if not printer:
        c.close(); return "Rental printer not found",404
    readings=c.execute("SELECT * FROM rental_printer_readings WHERE printer_id=? ORDER BY reading_month ASC, id ASC",(printer_id,)).fetchall()
    services=c.execute("SELECT * FROM rental_printer_services WHERE printer_id=? ORDER BY service_date ASC, id ASC",(printer_id,)).fetchall()
    c.close()
    from io import BytesIO
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
    out=BytesIO(); doc=SimpleDocTemplate(out,pagesize=landscape(A4),rightMargin=10*mm,leftMargin=10*mm,topMargin=10*mm,bottomMargin=10*mm)
    styles=getSampleStyleSheet(); title=styles['Title']; title.fontSize=18; title.leading=22
    small=ParagraphStyle('small',parent=styles['BodyText'],fontSize=8,leading=10)
    story=[Paragraph(f"Rental Printer Monthly Report — {printer['printer_id']}",title),Spacer(1,5)]
    info=[["Printer ID",printer['printer_id'] or '—',"Printer Name",printer['printer_name'] or '—'],["Model",printer['model'] or '—',"LAN IP",printer['lan_ip'] or '—'],["Location",printer['location'] or '—',"Department",printer['department'] or '—'],["Vendor",printer['vendor'] or '—',"Free Pages / Month",str(printer['free_pages'] or 0)]]
    it=Table(info,colWidths=[28*mm,70*mm,34*mm,70*mm]); it.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),colors.HexColor('#eef3f8')),('BACKGROUND',(2,0),(2,-1),colors.HexColor('#eef3f8')),('FONTNAME',(0,0),(-1,-1),'Helvetica'),('FONTSIZE',(0,0),(-1,-1),8),('GRID',(0,0),(-1,-1),0.4,colors.HexColor('#d7e0ea')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5)])); story += [it,Spacer(1,8),Paragraph("Monthly Readings",styles['Heading2'])]
    data=[["Month","Previous","Current","Total Pages","Free Pages","Extra / Due","Remarks","Recorded By"]]
    for r in readings:
        data.append([r['reading_month'],str(r['previous_reading']),str(r['current_reading']),str(r['total_pages']),str(r['free_pages']),str(r['extra_pages']),Paragraph(str(r['remarks'] or '—'),small),str(r['created_by'])])
    if len(data)==1: data.append(["No monthly readings yet.","","","","","","",""])
    mt=Table(data,colWidths=[25*mm,24*mm,24*mm,28*mm,24*mm,26*mm,80*mm,30*mm],repeatRows=1)
    mt.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#173f6b')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),7.5),('GRID',(0,0),(-1,-1),0.35,colors.HexColor('#d7e0ea')),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f8fafc')]),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)])); story += [mt]
    if services:
        story += [Spacer(1,10),Paragraph("Service / Repair History",styles['Heading2'])]
        sd=[["Date","Work","Vendor","Pages","Cost","Result","Remarks","By"]]
        for r in services: sd.append([r['service_date'],r['work'] or '—',r['vendor'] or '—',str(r['page_count']),r['cost'] or '—',r['result'],Paragraph(str(r['remarks'] or '—'),small),r['created_by']])
        st=Table(sd,colWidths=[24*mm,70*mm,35*mm,20*mm,25*mm,25*mm,70*mm,25*mm],repeatRows=1); st.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#173f6b')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),7),('GRID',(0,0),(-1,-1),0.35,colors.HexColor('#d7e0ea')),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f8fafc')])])); story += [st]
    doc.build(story); out.seek(0)
    safe=re.sub(r'[^A-Za-z0-9_-]+','_',str(printer["printer_id"])).strip('_') or 'printer'
    return send_file(out,as_attachment=True,download_name=f"{safe}_Monthly_Readings.pdf",mimetype="application/pdf")

@app.route("/logout")
def logout():
    if session.get("user"):
        c=db(); audit_log(c, "Logout", "Authentication", session.get("user")); c.commit(); c.close()
    session.clear(); return redirect(url_for("login"))

@app.route("/folder/<int:folder_id>/export")
def export_folder_excel(folder_id):
    if not session.get("user"):
        return redirect(url_for("login"))
    c=db()
    folder=c.execute("SELECT * FROM dashboard_folders WHERE id=?",(folder_id,)).fetchone()
    if not folder:
        c.close()
        return "Folder not found",404
    fields=c.execute("SELECT * FROM folder_fields WHERE folder_id=? ORDER BY id",(folder_id,)).fetchall()
    entries=c.execute("SELECT * FROM inventory_entries WHERE folder_id=? ORDER BY id",(folder_id,)).fetchall()

    wb=Workbook()
    ws=wb.active
    ws.title=(folder["name"][:31] or "Inventory")
    ws.append(["Sr.No"]+[f["field_name"] for f in fields]+["Status","Created By","Created"])
    for idx,e in enumerate(entries,1):
        row=[idx]
        for f in fields:
            val=c.execute("SELECT value FROM entry_values WHERE entry_id=? AND field_id=?",
                          (e["id"],f["id"])).fetchone()
            row.append(val["value"] if val else "")
        row.extend([e["status"],e["created_by"],e["created_at"][:10]])
        ws.append(row)
    ws.freeze_panes="A2"
    ws.auto_filter.ref=ws.dimensions
    for col in ws.columns:
        letter=col[0].column_letter
        max_len=max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[letter].width=min(max(max_len+2,10),28)
    from io import BytesIO
    output=BytesIO()
    wb.save(output)
    output.seek(0)
    filename=re.sub(r'[^A-Za-z0-9_-]+','_',folder["name"]).strip("_") or "inventory"
    c.close()
    return send_file(output,as_attachment=True,
                     download_name=f"{filename}_inventory.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


