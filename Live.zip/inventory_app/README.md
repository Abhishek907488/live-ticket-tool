# Inventory Management - LAN Ready

## Run
1. Install Python 3.11+.
2. `py -m pip install -r requirements.txt`
3. `py app.py`
4. Server PC: http://127.0.0.1:5000
5. Other LAN PCs: http://SERVER-IP:5000

## Login
- Sign in with User ID/username or registered email and password.
- The account role (Admin / IT Admin / User) is detected automatically after authentication.
- On a fresh database, use the first-run Admin setup screen to create the initial Admin account.

## Current structure
- User Management is the first sidebar item.
- Dashboard shows folders without Edit/Delete buttons.
- Data Management is Admin-only and contains folder Create/Edit/Delete controls.
- Dashboard folders remain stored in SQLite and persist after restart.

Before production, change the default admin password and secret key and add backups/audit logging.

## Folder workflow
1. Admin creates a folder in Dashboard/Data Management (for example, Computer).
2. Open the folder from Dashboard.
3. Use **Field Master** to define the details to collect (Asset Tag, Brand, Model, Serial Number, RAM, etc.).
4. Click **Create New Entry** and fill those master-defined fields.
5. Saved records appear inside that folder as an inventory table.


STEP8 SECURITY HARDENING
- Role permissions enforced server-side on management, delete, restore, import, edit and audit routes.
- User Management and Audit Log navigation is hidden for roles without access.
- Predictable Flask secret fallback removed; a persistent local secret is generated on first run (or INVENTORY_SECRET may be supplied).
- Session cookie HttpOnly and SameSite=Lax are enabled.
- Existing inventory features and dashboard layout were not intentionally changed.


## Consolidated Asset Management Features
- Asset Profile with complete fields, lifecycle, assignment, warranty/AMC, history and audit activity.
- Assignment / Handover history with old user -> new user, department, location, computer/IP.
- Lifecycle: In Stock, Assigned/In Use, Under Repair, Returned, Retired, Disposed.
- Disposed assets automatically create one preserved E-Waste record without deleting the original asset.
- Manual E-Waste records with Admin-defined E-Waste fields, history and audit trail.
- Warranty / AMC tracking with Active, Expiring Soon (30 days), and Expired indicators.
- Invoice, warranty, repair and disposal document attachments (max request size 16 MB).
- Reports with department/status/user/asset type filters and Excel export including E-Waste and IP utilization sheets.
- Dashboard alerts for warranty, repair, unassigned, disposed, E-Waste and duplicate warnings.
- QR Code intentionally excluded as requested.
