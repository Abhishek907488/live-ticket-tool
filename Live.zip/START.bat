@echo off
setlocal
cd /d "%~dp0"
echo Starting IT Service Desk + Inventory...
python "%~dp0app.py"
if errorlevel 1 (
  echo.
  echo Server failed to start. Check the error above.
)
pause
