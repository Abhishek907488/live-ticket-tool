# Meeting Automation Setup

This update keeps the IT Service Desk, ticket database, SMTP and existing UI intact. Meeting automation runs server-side so client PCs on the LAN do not need separate API credentials.

## 1. Zoom
- Create a Zoom Server-to-Server OAuth app in the company Zoom account.
- Copy Account ID, Client ID and Client Secret into Admin > Meeting Integrations > Zoom.
- Set Organizer Email to the Zoom user whose meetings should be created.
- Enable the integration and use Test Connection.
- The app creates a new scheduled meeting automatically and stores the join URL in the ticket.

## 2. Microsoft Teams
- Register an Entra ID application in the company Microsoft 365 tenant.
- Give the application the required Microsoft Graph application permission for online meeting creation (for example OnlineMeetings.ReadWrite.All) and obtain tenant-wide admin consent.
- If your tenant uses an application access policy for online meetings, allow the app to act for the selected organizer.
- Enter Tenant ID, Client ID, Client Secret and Organizer Email in Admin > Meeting Integrations > Microsoft Teams.
- Enable and Test Connection.

## 3. Google Meet
- Create a Google Cloud OAuth client for the company Google Workspace account.
- Authorize Calendar access for the meeting organizer and obtain a refresh token. The account should have permission to create Calendar events/conference data.
- Enter Client ID, Client Secret, Refresh Token and Calendar Owner in Admin > Meeting Integrations > Google Meet.
- Enable and Test Connection.
- Google Calendar creates the event and Meet conference; attendees can receive the calendar invitation, and the IT Service Desk also sends its normal SMTP invitation.

## LAN behavior
Only the server needs the provider credentials/tokens. An IT User on another LAN PC opens the normal Ticket Center, selects Create Meeting, enters date/time and participants, and the server creates the meeting.

## Saved links
Admin > Meeting Integrations can store recurring Zoom/Teams/Meet links. IT Users can choose a saved link instead of creating a new provider meeting.

## Security
Client secrets and Google refresh tokens are encrypted using the application's secret key. Do not copy the database or application secret to unmanaged PCs.
