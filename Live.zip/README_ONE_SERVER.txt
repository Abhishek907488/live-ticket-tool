ONE SERVER - IT SERVICE DESK + INVENTORY
=========================================

Run only START.bat or: python app.py

LAN URL: http://SERVER-PC-IP:5000
Inventory: http://SERVER-PC-IP:5000/inventory/

No second Inventory server/port is required.

Existing ticketing.db and inventory.db are preserved. Automatic backups remain in their respective backup folders.

The Inventory app is mounted under /inventory and its templates/static assets are namespaced to prevent route and CSS conflicts.

Existing source backups are in backups/one_server_source_backup/.

Important: if an old separate Inventory server is running on port 5001, stop it. Only this app.py should be started.
