import os, sys, importlib.util
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from werkzeug.wrappers import Response

BASE=os.path.dirname(os.path.abspath(__file__))
IT_DIR=os.path.join(BASE,'Live IT Service')
INV_DIR=os.path.join(BASE,'Project_Inventry_live')

def load(name,path):
    if path not in sys.path: sys.path.insert(0,path)
    spec=importlib.util.spec_from_file_location(name,os.path.join(path,'app.py'))
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

it_mod=load('it_service_app',IT_DIR)
inv_mod=load('inventory_app',INV_DIR)
it_app=it_mod.app; inv_app=inv_mod.app

# One shared Flask session secret so Inventory can use the already-authenticated IT Service Desk user.
inv_app.secret_key=it_app.secret_key
try:
    it_mod.init_db()
except Exception:
    pass
try:
    inv_mod.init_db()
except Exception:
    pass

# Bridge the IT Service Desk identity into the existing Inventory app without a second login.
from flask import session, redirect, abort, request, g
_original_permissions=inv_mod.permissions_for

def unified_permissions(key):
    role=getattr(g, 'it_role', session.get('it_role', session.get('role')))
    if role=='admin': return True
    if key=='view': return bool(session.get('inventory_view'))
    if key in ('edit','new_entry','delete','user_management'):
        return bool(session.get('inventory_edit'))
    return _original_permissions(key)
inv_mod.permissions_for=unified_permissions

@inv_app.before_request
def unified_inventory_auth():
    if request.endpoint=='static': return None
    if not session.get('user_id'):
        return redirect('/login')
    # Map the IT Service Desk identity to Inventory's existing role model.
    role=session.get('role')
    g.it_role=role
    g.restore_role=role
    session['user']=session.get('username') or session.get('full_name') or str(session.get('user_id'))
    if role=='admin': session['role']='Admin'
    elif role=='it_user': session['role']='IT Admin'
    else: session['role']='User'
    if role!='admin' and not session.get('inventory_view'):
        abort(403)
    return None

@inv_app.after_request
def restore_it_role(response):
    original=getattr(g,'restore_role',None)
    if original:
        session['role']=original
    return response

application=DispatcherMiddleware(it_app, {'/inventory': inv_app})

if __name__=='__main__':
    from werkzeug.serving import run_simple
    run_simple('0.0.0.0',5000,application,use_reloader=False)
