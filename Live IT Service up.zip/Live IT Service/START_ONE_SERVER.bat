@echo off
cd /d "%~dp0"
python unified_server.py
pause
